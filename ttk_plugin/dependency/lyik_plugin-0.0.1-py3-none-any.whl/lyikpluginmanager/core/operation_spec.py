import apluggy as pluggy
from abc import ABC, abstractmethod
from ..models import (
    ContextModel,
)
from ._config import getProjectName
from typing import Dict
from typing_extensions import Doc, Annotated

from ..models.operation_response import OperationResponseModel
from ..models.generic_form_record import GenericFormRecordModel

_spec = pluggy.HookspecMarker(getProjectName())


class OperationPluginSpec(ABC):
    """
    This is the single specification for all the plugin which will implement operation.
    """

    @abstractmethod
    @_spec
    async def process_operation(
        self,
        context: ContextModel,
        record_id: Annotated[int, Doc('record id of the form record')],
        status: Annotated[str, Doc('status of the form record')],
        form_record: Annotated[GenericFormRecordModel, Doc('form record')],
        params: Annotated[dict | None, Doc('additonal parameters require for the operation')],
    ) -> Annotated[OperationResponseModel, Doc('Returns the operation response')]:
        """
        This function is to process operation
        """
        pass
