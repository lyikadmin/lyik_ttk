def getProjectName():
    return "LYIK"
