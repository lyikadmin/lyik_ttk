import apluggy as pluggy
from abc import ABC, abstractmethod
from ..models import (
    ContextModel,
    IAMUserMetadata,
    IAMUserIdentifiers,
    IAMUserRelationshipInfo,
    RoleInfoModel,
)
from ._config import getProjectName
from typing import Dict, Any, List, Annotated
from typing_extensions import Doc

_spec = pluggy.HookspecMarker(getProjectName())


class IAMSpec(ABC):
    @abstractmethod
    @_spec
    async def getIAMInfo(
        self,
        context: ContextModel | None,
        user_identifiers: Annotated[
            IAMUserIdentifiers | None, Doc("user identifier - phone, email or userid")
        ],
    ) -> Annotated[
        IAMUserMetadata,
        Doc("User metadata containing user info, roles, permissions, etc."),
    ]:
        """
        This function is to return the permissions given a user_id.
        """
        pass

    @abstractmethod
    @_spec
    async def getRoleInformation(
        self,
        context: Annotated[
            ContextModel | None,
            Doc("Optional ContextModel carrying metadata such as correlation IDs and request timestamps."),
        ],
        roles: Annotated[
            List[str],
            Doc("List of external role identifiers for which to fetch persona and weight data."),
        ],
    ) -> Annotated[
        RoleInfoModel,
        Doc("Model mapping each role to its persona name and numeric weight."),
    ]:
        """
        Retrieve persona and weight metadata for the given roles.

        :param context: Optional context containing request metadata (e.g. correlation ID).
        :param roles: Roles assigned to a user as defined by the external IdP.
        :returns: A RoleInfoModel where each entry includes:
            - `persona`: List of strings representing persona names
            - `weight`: numerical weight or priority
        """
        pass


    @abstractmethod
    @_spec
    async def registerUsers(
        self,
        context: ContextModel | None,
        users_file: Annotated[bytes | None, Doc("file containing user information")],
        relationship_file: Annotated[
            bytes | None, Doc("file containing relationship mapping among users")
        ],
        roles_file: Annotated[
            bytes | None,
            Doc("file containing roles mapping to persmisions information"),
        ],
        personas_file: Annotated[
            bytes | None,
            Doc("file containing persona holding roles mapping information"),
        ],
        content_type: Annotated[
            str | None, Doc("content type of the file. Supports only csv now.")
        ],
    ) -> Annotated[
        str,
        Doc(
            "A message indicating the result of the operation (e.g., number of users updated or relationships added).e"
        ),
    ]:
        """
        This function is to register users and their permissions.
        """
        pass

    @abstractmethod
    @_spec
    async def getRelationshipInfoforUser(
        self,
        context: ContextModel | None,
        user_id: Annotated[
            str | Any,
            Doc("user id for which relationship information is to be fetched"),
        ],
    ) -> Annotated[
        IAMUserRelationshipInfo,
        Doc(
            "relationship information for a user having 'parents' - A list of all ancestor IDs, 'children' - A list of all descendant IDs."
        ),
    ]:
        """
        This function is to get relationship information for a user
        """
        pass

    @abstractmethod
    @_spec
    async def deleteUsers(
        self,
        context: ContextModel | None,
        users_list: Annotated[List[str], Doc("list of users to be deleted")],
    ) -> Annotated[str, Doc("response message indicating number of users deleted.")]:
        """
        This function is to delete the list of users from IAM.
        """
        pass
