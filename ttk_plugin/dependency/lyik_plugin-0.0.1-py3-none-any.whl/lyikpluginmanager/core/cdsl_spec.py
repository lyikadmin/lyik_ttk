import apluggy as pluggy
from abc import ABC, abstractmethod

from ..models import ContextModel, GenericFormRecordModel

from ._config import getProjectName
from typing import Dict, Any, List, Annotated
from typing_extensions import Doc

_spec = pluggy.HookspecMarker(getProjectName())

RESPONSE = dict


class CDSLPluginSpec(ABC):

    @abstractmethod
    @_spec
    async def upload_bo_setup(
        self,
        context: ContextModel,
        form_record: Annotated[
            GenericFormRecordModel,
            Doc("The form record for which the data has to be submitted"),
        ],
    ) -> RESPONSE:
        """
        This function is to submit the data to CDSL
        """
        pass


#     todo: add more methods here
