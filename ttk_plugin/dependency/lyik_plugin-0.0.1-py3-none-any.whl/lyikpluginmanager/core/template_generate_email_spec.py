from abc import ABC, abstractmethod

import apluggy as pluggy
from typing import Dict, Any
from typing_extensions import Annotated, Doc
from ..models import ContextModel, GenericFormRecordModel, TransformerResponseModel

from ._config import getProjectName

_spec = pluggy.HookspecMarker(getProjectName())


class TemplateGenerateEmailSpec(ABC):
    @abstractmethod
    @_spec
    async def template_generate_email(
        self,
        context: ContextModel,
        record: Annotated[GenericFormRecordModel, Doc("Generic model for form record")],
        transformer: Annotated[
            str,
            Doc(
                "The Transformer name which is basically a jinja file name, This will be known by the plugin"
            ),
        ],
        params: Annotated[dict, Doc("required arguments to get additional data")],
    ) -> Annotated[
        TransformerResponseModel, Doc("Response message for user's information")
    ]:
        """
        Given the template_name it will generate the email body and
        Send the email and return a success or failure message back
        If any attachment is found it will get that file from the responsible source and attach to the email body
        """
        pass
