import apluggy as pluggy
from abc import ABC, abstractmethod
from ..models import ContextModel, GenericFormRecordModel, GenerateAllDocsResponseModel
from ._config import getProjectName
import io
from typing_extensions import Doc, Annotated
from typing import List, Dict, Any


_spec = pluggy.HookspecMarker(getProjectName())


class GeneratePdfSpec(ABC):
    @abstractmethod
    @_spec
    async def generate_main_doc(
        self,
        context: ContextModel,
        record: Annotated[
            GenericFormRecordModel,
            Doc("form record fow which the pdf need to be generated"),
        ],
        record_id: Annotated[
            int | None, Doc("record id of the form record which is saved in db")
        ],
        pdf_name: Annotated[str | None, Doc("name to be assigned to generated pdf")],
    ) -> Annotated[io.BytesIO, Doc("pdf file buffer")]:
        """
        This function will generate and return a pdf.
        """
        pass

    @abstractmethod
    @_spec
    async def generate_all_docs(
        self,
        context: ContextModel,
        form_record: Annotated[
            GenericFormRecordModel,
            Doc("form record for which the pdf need to be generated"),
        ],
        record_id: Annotated[
            int, Doc("record id of the form record which is saved in db")
        ],
    ) -> Annotated[
        GenerateAllDocsResponseModel,
        Doc("response having status and link to download generated docs"),
    ]:
        """
        This function will generate and store the pdf(s).
        """
        pass

    @abstractmethod
    @_spec
    async def generate_doc(
        self,
        context: ContextModel,
        form_record: Annotated[
            GenericFormRecordModel,
            Doc("form record for which the pdf need to be generated"),
        ],
        record_id: Annotated[
            int, Doc("record id of the form record which is saved in db")
        ],
        params: Annotated[
            dict | None,
            Doc("This will be given based on the contract with the transformer"),
        ],
    ) -> Annotated[
        GenerateAllDocsResponseModel,
        Doc("response having status and link to download generated docs"),
    ]:
        """
        This function will generate and store the pdf(s).
        """
        pass
