import apluggy as pluggy
from abc import ABC, abstractmethod
from .spec import ContextModel
from ._config import getProjectName
from ..models import (
    EsignStatusResponseModel,
    InitiateEsigningResponseModel,
    GenericFormRecordModel,
    EsignResponseModel,
    EsignTransactionMeta,
    SetupEsigningResponseModel
)
from typing_extensions import Doc, Annotated

_spec = pluggy.HookspecMarker(getProjectName())


class EsignSpec(ABC):


    @abstractmethod
    @_spec
    async def setup_esigning(
        self,
        context: ContextModel,
        record_id: Annotated[int, Doc('record id of the form record')],
        form_record: Annotated[GenericFormRecordModel, Doc('form record')],
    ) -> Annotated[SetupEsigningResponseModel, Doc('Returns the response having esigning url')]:
        """
        This function is to setup the esigning requirements.
        """
        pass

    @abstractmethod
    @_spec
    async def get_transaction(
        self,
        context: ContextModel,
        txnid: Annotated[str, Doc("transaction id for the esigning operation")],
    ) -> Annotated[
        EsignTransactionMeta,
        Doc("Returns the esign transaction meta data corresponsing to a txdid"),
    ]:
        """
        Fetches and returns the transaction meta data corresponding to a txdid
        """
        pass

    @abstractmethod
    @_spec
    async def get_esign_status(
        self,
        context: ContextModel,
        txnid: Annotated[str, Doc("transaction id for the esigning operation")],
    ) -> Annotated[
        EsignStatusResponseModel,
        Doc("Returns the esign information corresponding to a txdid"),
    ]:
        """
        Fetches and returns the esign information corresponding to a txdid
        """
        pass

    @abstractmethod
    @_spec
    async def intiate_protean_esigning(
        self,
        context: ContextModel,
        txnid: Annotated[str, Doc("transaction id for the esigning operation")],
        signerid: Annotated[str, Doc("esigner's id for the esigning operation")],
    ) -> Annotated[
        InitiateEsigningResponseModel,
        Doc("Returns the status of esigning initiation request"),
    ]:
        """
        Does the prerequisites for protean esining process and returns payload require by protean endpoint
        """
        pass

    @abstractmethod
    @_spec
    async def esign(
        self,
        context: ContextModel,
        protean_response_xml: Annotated[
            str, Doc("xml response passed from protean after otp verification.")
        ],
    ) -> Annotated[
        EsignResponseModel,
        Doc(
            "Returns the Esigning operation response having status as success or failure"
        ),
    ]:
        """
        Does the final step in protean esigning process and generates esigned pdf.
        """
        pass
