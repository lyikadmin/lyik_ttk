import apluggy as pluggy
from abc import ABC, abstractmethod
from ..models import ContextModel, PANStatusModel

from ._config import getProjectName
from typing import Dict, Any, List, Annotated
from typing_extensions import Doc

_spec = pluggy.HookspecMarker(getProjectName())


class CVLKRAPluginSpec(ABC):

    @abstractmethod
    @_spec
    async def get_pan_status(
        self,
        context: ContextModel,
        pan: Annotated[str,Doc("The PAN number")],
    ) -> PANStatusModel:
        """
        This function is to translate payload into cvl kra record
        """
        pass
