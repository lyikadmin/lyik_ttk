import apluggy as pluggy
from abc import ABC, abstractmethod
from ..models import ContextModel, GenericFormRecordModel, TransformerResponseModel
from ._config import getProjectName
from typing import Annotated
from typing_extensions import Doc

_spec = pluggy.HookspecMarker(getProjectName())


class TransformerSpec(ABC):
    @abstractmethod
    @_spec
    async def template_transform_data(
        self,
        context: ContextModel,
        transformer: Annotated[
            str,
            Doc(
                "The Transformer name which is basically a jinja file name, This will be known by the plugin"
            ),
        ],
        record: Annotated[GenericFormRecordModel, Doc("Generic model for form record")],
        additional_args: Annotated[
            dict | None, Doc("Additional arguments can be passed with this")
        ],
    ) -> Annotated[
        TransformerResponseModel,
        Doc("Trasformer model containing status and transformed data"),
    ]:
        """
        This function will transform the given record to the desired record format(dict),
        based on the provided transformer.
        """
        pass

    @abstractmethod
    @_spec
    async def template_generate_pdf(
        self,
        context: ContextModel,
        template_id: Annotated[
            str,
            Doc(
                "The Template ID which is the directory name or the actual template name,"
                "eg: AOF or 01_AOF ('AOF/01_AOF')"
                "This will be known by the plugin"
            ),
        ],
        record: Annotated[GenericFormRecordModel, Doc("Generic model for form record")],
        additional_args: Annotated[
            dict | None, Doc("Additional arguments can be passed with this")
        ],
    ) -> Annotated[
        TransformerResponseModel,
        Doc("Trasformer model containing status and transformed data"),
    ]:
        """
        This function will transform and generate the desired pdf given the record,
        based on the provided transformer.

        If the template id is '01_AOF' then it will transform the pdf '01_AOF.pdf' inside the 'AOF' directory.
        If the template id is 'AOF' then it will transform all the pdf inside the directory.

        And if the directory contains multiple pdf like,
        01_AOF.pdf, 02_AOF.pdf and 01_KYC.pdf, then
        01_AOF.pdf and 02_AOF.pdf will be concatenated together as AOF.pdf and flattened, 01_KYC.pdf will be flattened and returned.
        """
        pass
