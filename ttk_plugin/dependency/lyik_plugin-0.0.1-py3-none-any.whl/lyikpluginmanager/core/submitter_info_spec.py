import apluggy as pluggy
from abc import ABC, abstractmethod
from ..models import ContextModel, SubmitterModel
from ._config import getProjectName
from typing import Annotated
from typing_extensions import Doc

_spec = pluggy.HookspecMarker(getProjectName())


class SubmitterInfoSpec(ABC):
    @abstractmethod
    @_spec
    async def get_sumbmitter_info(self, context: ContextModel) -> Annotated[
        SubmitterModel,
        Doc("Returned as Submitter Model containing submitter information"),
    ]:
        """
        This function will return submitter information
        Submitter info will contain maker and user information
        """
        pass
