from abc import ABC, abstractmethod

import apluggy as pluggy
from typing_extensions import Annotated, Doc
from ..models import ContextModel

from ._config import getProjectName
from ..models import (
    EmailModel,
)

_spec = pluggy.HookspecMarker(getProjectName())


class EmailSpec(ABC):

    @abstractmethod
    @_spec
    async def send_email(
        self, 
        context: ContextModel | None,
        payload: Annotated[EmailModel, Doc("Email input model")]
    ) -> Annotated[bool, Doc("True if email is sent successfully, False otherwise")]:
        """
        This function is to send email

        """
        pass
