import apluggy as pluggy
from abc import ABC, abstractmethod
from ..models import ContextModel, NSDLResponseModel, GenericFormRecordModel
from ._config import getProjectName
from typing import Annotated
from typing_extensions import Doc

_spec = pluggy.HookspecMarker(getProjectName())


class NSDLDematAccountSpec(ABC):
    @abstractmethod
    @_spec
    async def create_demat_account(
        self,
        context: ContextModel,
        form_record: Annotated[GenericFormRecordModel, Doc("Form Record")],
    ) -> Annotated[NSDLResponseModel, Doc("The Desired output for NSDL Demat")]:
        """"""
        pass
