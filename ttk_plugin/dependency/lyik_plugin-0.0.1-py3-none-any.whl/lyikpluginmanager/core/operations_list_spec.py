from abc import ABC, abstractmethod

import apluggy as pluggy
from typing_extensions import Annotated, Doc
from ..models import ContextModel, GenericFormRecordModel, OperationsListResponseModel

from ._config import getProjectName

_spec = pluggy.HookspecMarker(getProjectName())


class OperationsListSpec(ABC):

    @abstractmethod
    @_spec
    async def get_operations_list(
        self,
        context: ContextModel,
        form_record: Annotated[
            GenericFormRecordModel,
            Doc("The form record for which the operations list is required"),
        ],
    ) -> Annotated[
        OperationsListResponseModel,
        Doc("The list of operations available for the current form as per user role"),
    ]:
        """
        This function is to get the list of operations available for the current user.
        """
        pass
