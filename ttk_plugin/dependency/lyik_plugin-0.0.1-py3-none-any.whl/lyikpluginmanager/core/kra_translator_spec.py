import apluggy as pluggy
from abc import ABC, abstractmethod
from ..models import ContextModel, GenericKYCData, ROOTDataModel
from typing import Dict, Any, List, Annotated
from typing_extensions import Doc

from ._config import getProjectName

_spec = pluggy.HookspecMarker(getProjectName())


class KRATranslatorSpec(ABC):

    @abstractmethod
    @_spec
    async def translate_to_kra(
        self,
        context: ContextModel,
        kyc_holder: Annotated[GenericKYCData,Doc("Kyc holder data from from record")],
    ) -> Annotated[ROOTDataModel,Doc("Transformed data for KRA upload will be returned")]:
        """
        This function is to translate payload into cvl kra record
        """
        pass
