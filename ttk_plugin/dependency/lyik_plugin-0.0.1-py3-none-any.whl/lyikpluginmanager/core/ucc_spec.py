import apluggy as pluggy
from abc import ABC, abstractmethod
from ..models import ContextModel, GenericFormRecordModel, UCCResponseModel
from typing_extensions import Doc, Annotated


from ._config import getProjectName

_spec = pluggy.HookspecMarker(getProjectName())


class UCCPluginSpec(ABC):

    @abstractmethod
    @_spec
    async def upload_ucc(
        self,
        context: ContextModel,
        form_record: Annotated[
            GenericFormRecordModel,
            Doc("form record data"),
        ],
    )->Annotated[UCCResponseModel, Doc('UCC upload request result')]:
        """
        Used to register a client information in the UCI/UCC system.
        """
        pass
