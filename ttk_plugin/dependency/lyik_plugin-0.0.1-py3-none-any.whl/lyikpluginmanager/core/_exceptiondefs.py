import json
import logging

logger = logging.getLogger(__name__)


class PluginException(Exception):
    """Plugin Exception"""
    def __init__(self, message: str, detailed_message: str = None):
        self.message = message
        self.detailed_message = detailed_message
        self.structured_message = (
            f"{self.message} (Details: {self.detailed_message})"
            if self.detailed_message
            else self.message
        )
        self.log()
        super().__init__(f"PluginException: {self.structured_message}")

    def log(self):
        """Logs the structured message and traceback of the original exception if available."""
        if self.__cause__:
            logger.error(f"PluginException occurred: {self.structured_message}", exc_info=self.__cause__)
        else:
            logger.error(f"PluginException occurred: {self.structured_message}")
