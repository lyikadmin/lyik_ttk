import apluggy as pluggy
from abc import ABC, abstractmethod

from typing_extensions import Annotated, Doc
from ..models import ContextModel


from ._config import getProjectName

_spec = pluggy.HookspecMarker(getProjectName())


class OtpSpec(ABC):

    @abstractmethod
    @_spec
    async def verify_authorization_code(
        self,
        context: ContextModel | None,
        auth_code: Annotated[str, Doc("The authorization code")],
        contact_id: Annotated[str, Doc("The contact id")],
    ) -> Annotated[str | None, Doc("The contact id")]:
        """
        This function is to verify the authorization code
        """
        pass

    @abstractmethod
    @_spec
    async def verify_otp(
        self,
        context: ContextModel | None,
        otp: Annotated[str, Doc("The OTP")],
        contact_id: Annotated[str, Doc("The Contact id")],
        transaction_id: Annotated[str, Doc("The transaction id")],
    ) -> Annotated[str | None, Doc("The authorization code")]:
        """
        This function is to verify the OTP
        """
        pass

    @abstractmethod
    @_spec
    async def generate_and_send_otp(
        self,
        context: ContextModel | None,
        contact_id: Annotated[str, Doc("The contact id")],
    ) -> Annotated[str | None, Doc("The transaction id")]:
        """
        This function is to generate and send OTP
        """
        pass
