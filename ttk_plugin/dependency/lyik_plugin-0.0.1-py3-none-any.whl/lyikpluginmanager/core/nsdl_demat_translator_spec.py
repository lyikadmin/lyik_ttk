import apluggy as pluggy
from abc import ABC, abstractmethod
from ..models import ContextModel, NSDLRquestModel, GenericFormRecordModel
from ._config import getProjectName
from typing import Annotated
from typing_extensions import Doc

_spec = pluggy.HookspecMarker(getProjectName())


class NSDLDematSpec(ABC):

    @abstractmethod
    @_spec
    async def translate_to_nsdl_demat(
        self,
        context: ContextModel,
        form_record: Annotated[GenericFormRecordModel, Doc("Form Record")],
    ) -> Annotated[NSDLRquestModel, Doc("The Desired output for NSDL Demat")]:
        """
        This function is to translate form record into NSDL demat request model
        """
        pass
