class ConfigProxy:
    """
    Pass the global_config when trying to invoke other plugins which require the config
    """
    def __init__(self, config, requested_vars=None):
        self.global_config = config
        self._requested_vars = set(requested_vars) if requested_vars is not None else set()

        # Remove any requested vars that are in RESTRICTED_VARS
        restricted_requested_vars = self._requested_vars.intersection(RESTRICTED_VARS)
        if restricted_requested_vars:
            raise ValueError(f"Access to {restricted_requested_vars} is restricted.")

    def __getattr__(self, name):
        if name in self._requested_vars:
            return getattr(self.global_config, name)
        raise AttributeError(f"Access to '{name}' is not allowed in this context. Make sure the variable was requested with RequiredVars.")

RESTRICTED_VARS = {} 


# Define the list of allowed and restricted variables
AUTH_PROVIDER_METADATA = [
    "AUTH0_DOMAIN", "AUTH0_SIGNING_ALOGRITHM", "AUTH0_APP_AUDIENCE", "AUTH0_API_AUDIENCE", "FIREBASE_PROJECT_NAME"
]

ALLOWED_VARS = {
    "DB_CONN_URL", "ADMIN_DB", "SERVICES_ENDPOINT", "LICENSING_ENDPOINT", "API_DOMAIN",
    "PDF_GARBLE_KEY", "DOWNLOAD_DOC_API_ENDPOINT", "SMS_ENABLED", "TEXTLOCAL_API_KEY",
    "SENDGRID_API_KEY", "ORG_DB", *AUTH_PROVIDER_METADATA
}

