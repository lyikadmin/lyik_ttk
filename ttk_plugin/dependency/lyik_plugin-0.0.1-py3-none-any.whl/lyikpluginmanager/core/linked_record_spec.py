import apluggy as pluggy
from abc import ABC, abstractmethod
from ..models import ContextModel, LinkedRecordResponseModel, GenericFormRecordModel
from typing import Dict
from typing import Annotated
from typing_extensions import Doc

from ._config import getProjectName

_spec = pluggy.HookspecMarker(getProjectName())


class LinkedRecordSpec(ABC):

    @abstractmethod
    @_spec
    async def create_linked_record(
        self,
        context: ContextModel,
        record_id: Annotated[str, Doc("The unique identifier for the record")],
        status: Annotated[str, Doc("The status of the form")],
        form_record: Annotated[
            GenericFormRecordModel,
            Doc("The form record for which the linked record has to be created"),
        ],
    ) -> Annotated[
        LinkedRecordResponseModel,
        Doc("This is the created linked record"),
    ]:
        """
        This function is to create linked record
        """
        pass
