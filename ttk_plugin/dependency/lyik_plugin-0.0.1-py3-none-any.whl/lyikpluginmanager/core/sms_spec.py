from abc import ABC, abstractmethod

import apluggy as pluggy
from typing_extensions import Annotated, Doc
from ..models import ContextModel

from ._config import getProjectName
from ..models import (
    SmsModel,
)

_spec = pluggy.HookspecMarker(getProjectName())


class SmsSpec(ABC):

    @abstractmethod
    @_spec
    async def send_sms(
        self,
        context: ContextModel | None,
        payload: Annotated[SmsModel, Doc("Sms input model")],
    ) -> Annotated[bool, Doc("True if sms is sent successfully, False otherwise")]:
        """
        This function is to send sms
        """
        pass
