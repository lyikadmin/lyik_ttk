import apluggy as pluggy
from abc import ABC, abstractmethod
from ..models import ContextModel
from ._config import getProjectName
from typing import Annotated
from typing_extensions import Doc

_spec = pluggy.HookspecMarker(getProjectName())


class IdGenSpec(ABC):

    @abstractmethod
    @_spec
    async def idGen(
        self,
        context: ContextModel,
        db_name: Annotated[str, Doc("Name of the db in the database")],
    ) -> Annotated[
        str, Doc("A unique generated id based on a sequence will be returned")
    ]:
        """
        This will generate an id based on the sequence
        """
        pass
