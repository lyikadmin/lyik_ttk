import json
import hashlib
from typing import List, Dict, Any
import jwt
from ._exceptiondefs import PluginException
from datetime import datetime, timezone


def generate_hash_id_from_dict(data):
    """
    Given any dictionary (or nested dict/list structures):
      - Remove specified keys (recursively).
      - Sort dictionary keys deterministically.
      - Produce a short hash of the resulting structure.
    """
    length = 8

    def remove_keys(item, keys_to_remove):
        """
        Recursively remove all keys in 'keys_to_remove' from dicts.
        - Works for nested dicts and lists.
        - Preserves order of lists, but removes keys from dicts within lists.
        """
        if isinstance(item, dict):
            return {
                k: remove_keys(v, keys_to_remove)
                for k, v in item.items()
                if k not in keys_to_remove
            }
        elif isinstance(item, list):
            return [remove_keys(element, keys_to_remove) for element in item]
        return item

    def sort_dict(item):
        """Recursively sort dictionaries by keys (nested structures supported)."""
        if isinstance(item, dict):
            return {k: sort_dict(item[k]) for k in sorted(item.keys())}
        elif isinstance(item, list):
            return [sort_dict(elem) for elem in item]
        return item

    # 1) Define ALL keys to remove in one place
    keys_to_exclude = {
        "_ver_status",
        "_approval_status",
        "transaction_id",
        "dependency_relationship_mobile",
        "dependency_relationship_email",
        "otp",
    }

    # 2) Remove all unwanted keys in ONE recursive pass
    cleaned = remove_keys(data, keys_to_exclude)

    # 3) Sort keys recursively
    sorted_data = sort_dict(cleaned)

    # 4) Generate hash
    json_str = json.dumps(sorted_data, separators=(",", ":"))
    return hashlib.sha256(json_str.encode()).hexdigest()[:length]

def get_personas_from_encoded_token(token: str) -> List[str] | None:
    try:
        # Decode the JWT token
        decoded_token = jwt.decode(token, options={"verify_signature": False})

        # Extract the personas from user_metadata
        personas = (
            decoded_token.get("user_metadata", {})
            .get("permissions", {})
            .get("persona", [])
        )

        return personas
    except Exception as e:
        return None

def change_and_add_state(record: Dict[str, Any], new_state: str) -> None:
    current_state = record.get("state")

    # Incase the new state is the same, nothing is added to audit logs.
    if current_state == new_state:
        return current_state

    record["state"] = new_state

    if "_audit_log" not in record:
        record["_audit_log"] = {}

    if not isinstance(record["_audit_log"], dict):
        raise PluginException("_audit_log must be a dictionary")
    record["_audit_log"][current_state] = datetime.now(tz=timezone.utc).isoformat()
    current_state = new_state
    return current_state