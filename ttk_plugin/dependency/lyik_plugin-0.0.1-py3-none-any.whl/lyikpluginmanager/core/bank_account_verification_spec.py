import apluggy as pluggy
from abc import ABC, abstractmethod
from ..models import ContextModel, BankAccountVerifierResponseModel
from ._config import getProjectName
from typing_extensions import Doc, Annotated

_spec = pluggy.HookspecMarker(getProjectName())


class BankAccountVerificationSpec(ABC):
    """
    This is the single spec for all the plugin which will implement bank account verification.
    """

    @abstractmethod
    @_spec
    async def verify_bank(
        self,
        context: ContextModel,
        ifsc_code: Annotated[str, Doc("IFSC Code of the bank")],
        account_number: Annotated[str, Doc("Account number of the user")],
        name: Annotated[str, Doc("Name of the account holder")],
        mobile_number: Annotated[str, Doc("Mobile number of the account holder")],
    ) -> Annotated[
        BankAccountVerifierResponseModel,
        Doc("Returns the bank account verification response"),
    ]:
        """
        This function is to verify the bank acount details of an user.
        """
        pass
