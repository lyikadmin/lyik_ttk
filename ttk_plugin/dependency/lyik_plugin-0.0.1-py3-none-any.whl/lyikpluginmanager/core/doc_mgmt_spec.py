# import apluggy as pluggy
# from abc import ABC, abstractmethod
# from ..models import ContextModel, DocumentModel
# from ._config import getProjectName
# from typing import Annotated
# from typing_extensions import Doc

# _spec = pluggy.HookspecMarker(getProjectName())


# class DocumentManagementSpec(ABC):
#     @abstractmethod
#     @_spec
#     async def addDocument(
#         self,
#         context: ContextModel,
#         document: Annotated[
#             DocumentModel, Doc("Document model is accepted without doc_id")
#         ],
#         coll_name: Annotated[str, Doc("Name of the DB collection")],
#     ) -> Annotated[DocumentModel, Doc("Document model is returned")]:
#         """
#         This function will add a document in the DB
#         """
#         pass

#     @abstractmethod
#     @_spec
#     async def deleteDocument(
#         self,
#         context: ContextModel,
#         file_id: Annotated[str, Doc("file_id which is the documnet id in the DB")],
#         coll_name: Annotated[str, Doc("Name of the DB collection")],
#     ):
#         """
#         This function will delete a document given a file_id
#         """
#         pass

#     @abstractmethod
#     @_spec
#     async def fetchDocument(
#         self,
#         context: ContextModel,
#         file_id: Annotated[str, Doc("file_id which is the documnet id in the DB")],
#         coll_name: Annotated[str, Doc("Name of the DB collection")],
#     ) -> Annotated[DocumentModel, Doc("Document model is returned with doc_id")]:
#         """
#         This function wil return a file in documentModel format
#         """
#         pass

#     @abstractmethod
#     @_spec
#     async def updateDocument(
#         self,
#         context: ContextModel,
#         file_id: Annotated[str, Doc("file_id which is the documnet id in the DB")],
#         document: Annotated[DocumentModel, Doc("Document model is accepted")],
#         coll_name: Annotated[str, Doc("Name of the DB collection")],
#     ) -> Annotated[DocumentModel, Doc("Document model is returned with new doc_id")]:
#         """
#         This function will update a document given a old file_id and new file data
#         """
#         pass


import apluggy as pluggy
from pydantic import ConfigDict, BaseModel
from abc import ABC, abstractmethod
from ..models import ContextModel, DocumentModel, DBDocumentModel, DocMeta, DocQueryGenericModel
from ._config import getProjectName
from typing import Annotated, Dict, Any, List
from typing_extensions import Doc
_spec = pluggy.HookspecMarker(getProjectName())


class DocumentManagementSpec(ABC):
    @abstractmethod
    @_spec
    async def addDocument(
        self,
        context: ContextModel,
        document: Annotated[
            DocumentModel, Doc("Document to be stored")
        ],
        coll_name: Annotated[str, Doc("Name of the DB collection")],
        metadata: Annotated[DocMeta | None, Doc('meta data to be stored along with document')],

    ) -> Annotated[DBDocumentModel, Doc("DBDocument model is returned.")]:
        """
        Adds a document in db along with metadata if provided.
        """
        pass

    @abstractmethod
    @_spec
    async def deleteDocument(
        self,
        context: ContextModel,
        file_id: Annotated[str, Doc("file_id which is the documnet id in the DB")],
        coll_name: Annotated[str, Doc("Name of the DB collection")],
        metadata_params: Annotated[DocQueryGenericModel | None, Doc('meta data params for querying db collection if file_id is not known')],

    )-> Annotated[None, Doc('returns nothing!')]:
        """
        Deletes the file(s) based on file_id or metadata_params, whichever provided.
        """
        pass

    @abstractmethod
    @_spec
    async def fetchDocument(
        self,
        context: ContextModel,
        file_id: Annotated[str | None, Doc("file_id which is the documnet id in the DB")],
        coll_name: Annotated[str, Doc("Name of the DB collection")],
        metadata_params: Annotated[DocQueryGenericModel | None, Doc('query params')],

    ) -> Annotated[List[DBDocumentModel], Doc("List of items returned in DBDocument model with doc_id, doc_name, metadata, etc.")]:
        """
        Fetches the file(s) from db based on file_id or metadata_params.
        """
        pass

    @abstractmethod
    @_spec
    async def updateDocument(
        self,
        context: ContextModel,
        file_id: Annotated[str| None, Doc("file_id which is the documnet id in the DB")],
        document: Annotated[DocumentModel | None, Doc("Document model is accepted")],
        coll_name: Annotated[str, Doc("Name of the DB collection")],
        metadata_params: Annotated[DocQueryGenericModel | None, Doc('query params')],
        new_metadata: Annotated[DocMeta | None, Doc('meta data about doc')],
    ) -> Annotated[List[DBDocumentModel], Doc("new doc_id")]:
        """
        This update operation adds new document in database and deletes existing one if only found!
        """
        pass

