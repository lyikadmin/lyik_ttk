import apluggy as pluggy
from abc import ABC, abstractmethod
from ..models import ContextModel, NSEPayload, BSEPayload, GenericFormRecordModel
from typing import Dict
from typing_extensions import Doc, Annotated
from ._config import getProjectName

_spec = pluggy.HookspecMarker(getProjectName())


class UCCDataParserSpec(ABC):

    # @abstractmethod
    # @_spec
    # async def ucc_bse_data_parse(
    #     self,
    #     context: ContextModel,
    #     form_record: Annotated[
    #         GenericFormRecordModel,
    #         Doc("form record fow which the pdf need to be generated"),
    #     ],
    # ) -> Annotated[BSEPayload, Doc('Data required for BSE UCC/UCI')]:
    #     """
    #     This method formulates form record payload into BSEPayload 
    #     """
    #     pass

    # @abstractmethod
    # @_spec
    # async def ucc_nse_data_parse(
    #     self,
    #     context: ContextModel,
    #     form_record: Annotated[
    #         GenericFormRecordModel,
    #         Doc("form record data"),
    #     ],
    # ) -> Annotated[NSEPayload, Doc('Data required for NSE UCC/UCI')]:
    #     """
    #     This method formulates form record payload into NSEPayload 
    #     """
    #     pass

    @abstractmethod
    @_spec
    async def ucc_data_parse(
        self,
        context: ContextModel,
        form_record: Annotated[
            GenericFormRecordModel,
            Doc("form record data"),
        ],
    ) -> Annotated[NSEPayload | BSEPayload, Doc('Data required for UCC/UCI api')]:
        """
        This method formulates form record payload into NSEPayload  or BSEPayload based on NSDL or CDSL selection.
        """
        pass


