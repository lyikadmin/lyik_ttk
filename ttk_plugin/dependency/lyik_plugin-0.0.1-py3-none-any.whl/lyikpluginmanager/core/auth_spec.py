import apluggy as pluggy
from abc import ABC, abstractmethod

from pydantic import BaseModel
from ..models import AuthorizationRequestModel, ContextModel, PreAuthorizedInfoModel
from ._config import getProjectName
from typing import Dict, Any, List, Annotated, Union
from typing_extensions import Doc

_spec = pluggy.HookspecMarker(getProjectName())


class AuthProviderSpec(ABC):
    @abstractmethod
    @_spec
    async def isValidToken(self, token: str):
        """
        This function is to check if token belongs to the auth provider.
        """
        pass

    @abstractmethod
    @_spec
    async def verifyToken(self, context: ContextModel | None, token: str):
        """
        This function verifies token and returns payload
        """
        pass

    @abstractmethod
    @_spec
    async def getSubject(self, payload: Dict):
        """
        This returns sub (subject) given payload
        """
        pass

    @abstractmethod
    @_spec
    async def getUserId(self, payload: Dict):
        """
        This returns user_id given payload
        """
        pass

    @abstractmethod
    @_spec
    async def isOwnerOf(self, payload: Dict):
        """
        This checks if owner given payload
        """
        pass

    @abstractmethod
    @_spec
    async def getOwnerOf(self, payload: Dict):
        """
        This returns owner given payload
        """
        pass

    @abstractmethod
    @_spec
    async def getPhoneNumber(self, payload: Dict):
        """
        This returns phone number given payload
        """
        pass

    @abstractmethod
    @_spec
    async def getEmail(self, payload: Dict):
        """
        This returns email given payload
        """
        pass

    @abstractmethod
    @_spec
    async def getPreAuthorizedInformation(
        self,
        token: Annotated[
            str,
            Doc("Opaque SSO token issued by the customer's identity provider."),
        ],
    ) -> Annotated[
        PreAuthorizedInfoModel,
        Doc("Model containing the external `user_id`, mapped `roles`, and any `governed_users`."),
    ]:
        """
        Validate the external SSO token and extract the pre-authorized user details required
        to issue a LYIK token without an OTP.

        :param token: External SSO token presented by the client.
        :returns: A `PreAuthorizedInfoModel` with fields:
            - `user_id`: the unique external user identifier
            - `roles`: list of roles granted by the external IdP
            - `governed_users`: list of downstream user IDs this user can act on behalf of
            - `user_name`: the name of the user if available
            - `expiry`: the expiry time of the token
            - `plugin_provider`: the name of the plugin other than LYIK
            - `token`: the token given from the plugin provider
        """
        pass

AUTH_TOKEN = str


class LyikTokenSpec(ABC):

    @abstractmethod
    @_spec
    async def getAuthorizedToken(
        self,
        context: ContextModel | None,
        auth_request: Annotated[
            AuthorizationRequestModel | PreAuthorizedInfoModel | None,
            Doc(
                "If OTP flow: an AuthorizationRequestModel containing "
                "`auth_code` and `contact_id`; "
                "if SSO flow: a PreAuthorizedInfoModel containing "
                "`user_id`, `roles` and `governed_users`."
                " Additionally, the following fields may be present:"
                " - `user_name`: the name of the user if available"
                " - `expiry`: the expiry time of the token"
                " - `plugin_provider`: the name of the plugin other than LYIK"
                " - `token`: the token given from the plugin provider"
            ),
        ],
    ) -> Annotated[
        AUTH_TOKEN,
        Doc("A freshly minted LYIK access token (JWT string), valid for the configured TTL.")
    ]:
        """
        Generate and return a LYIK access token for the given authentication request.

        - **OTP flow** (`AuthorizationRequestModel`):  
        Validates the one-time password and looks up the user by `contact_id` in IAM.
        - **SSO flow** (`PreAuthorizedInfoModel`):  
        Trusts the pre-authorized info (user_id, roles, governed_users) and skips OTP.

        :param context: Optional `ContextModel` carrying request metadata (e.g. correlation IDs).
        :param auth_request: Either:
            - `AuthorizationRequestModel` for OTP-based issuance, or  
            - `PreAuthorizedInfoModel` for SSO-based issuance.
        :returns: An `AUTH_TOKEN` (JWT) encoding the granted scopes and expiry.
        """
        pass

    @abstractmethod
    @_spec
    async def getRefreshedToken(
        self,
        context: ContextModel | None,
        token: Annotated[str, Doc("Valid Lyik Token")],
    ) -> Annotated[AUTH_TOKEN, Doc("The JWT encoded token as string.")]:
        """
        This function is to create and return a refreshed token, if the given token is valid.
        """
        pass
