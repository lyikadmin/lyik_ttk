from abc import ABC, abstractmethod
from ..models import ContextModel, GenericFormRecordModel
from typing_extensions import Doc, Annotated
import apluggy as pluggy
from ._config import getProjectName

_spec = pluggy.HookspecMarker(getProjectName())


class PreSaveProcessorPipelineSpec(ABC):
    """
    This is the single specification for all the pipeline plugins which will implement pre-save processing.
    """

    @abstractmethod
    @_spec
    async def pre_save_processor_pipeline(
        self,
        context: ContextModel | None,
        payload: Annotated[
            GenericFormRecordModel,
            Doc("The payload of form record data ot be preprocessed."),
        ],
    ) -> Annotated[GenericFormRecordModel, Doc("The updated form record data.")]:
        """
        Single function for all the pre-save processor pipeline implementations
        """
        pass


class FormProcessorPipelineSpec(ABC):
    """
    This is the single specification for all the pipeline plugins which will implement form pre-processing
    """

    @abstractmethod
    @_spec
    async def form_definition_processor_pipeline(
        self,
        context: ContextModel | None,
        bform: Annotated[
            GenericFormRecordModel,
            Doc("The payload of form record data ot be preprocessed."),
        ],
    ) -> Annotated[GenericFormRecordModel, Doc("The updated form record data.")]:
        """
        Single function for all the form pre-processor pipeline implementations
        """
        pass


class PreActionProcessorSpec(ABC):
    """
    This is the single specification for all the plugins which will implement pre-action processing.
    """

    @abstractmethod
    @_spec
    async def pre_action_processor(
        self,
        context: ContextModel | None,
        action: Annotated[
            str,
            Doc("The action of the processor like: 'save' and 'submit'"),
        ],
        current_state: Annotated[
            str | None,
            Doc(
                "Current state of the record like: 'save', 'submit', 'approved'"
                "This state will be the already saved state of the record"
            ),
        ],
        new_state: Annotated[
            str | None,
            Doc(
                "New state of the record like: 'save', 'submit', 'approved'"
                "This state will be the new state which will be sent in the request"
            ),
        ],
        payload: Annotated[
            GenericFormRecordModel,
            Doc("The payload of form record data ot be pre processed."),
        ],
    ) -> Annotated[GenericFormRecordModel, Doc("The updated form record data.")]:
        """
        Single function for all the pre-action processor implementations
        """
        pass


class PostActionProcessorSpec(ABC):
    """
    This is the single specification for all the plugins which will implement post-action processing.
    """

    @abstractmethod
    @_spec
    async def post_action_processor(
        self,
        context: ContextModel | None,
        action: Annotated[
            str,
            Doc("The action of the processor like: 'save' and 'submit'"),
        ],
        previous_state: Annotated[
            str | None,
            Doc(
                "Previous state of the record like: 'SAVE', 'SUBMIT', 'APPROVED'"
                "This state will be the already saved state of the record"
            ),
        ],
        current_state: Annotated[
            str,
            Doc(
                "Current state of the record like: 'SAVE', 'SUBMIT', 'APPROVED'"
                "This state will be the new state which will be sent in the request"
            ),
        ],
        payload: Annotated[
            GenericFormRecordModel,
            Doc("The payload of form record data ot be processed post action."),
        ],
    ) -> Annotated[GenericFormRecordModel, Doc("The updated form record data.")]:
        """
        Single function for all the post-action processor implementations
        """
        pass
