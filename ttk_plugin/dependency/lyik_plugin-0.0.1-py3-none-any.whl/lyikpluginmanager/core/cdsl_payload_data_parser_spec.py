import apluggy as pluggy
from abc import ABC, abstractmethod

from ..models import ContextModel, GenericFormRecordModel, CDSLDematPayloadModel

from ._config import getProjectName
from typing import Dict, Any, List, Annotated
from typing_extensions import Doc

_spec = pluggy.HookspecMarker(getProjectName())

PAYLOAD = CDSLDematPayloadModel


class CDSLPayloadDataParserSpec(ABC):

    @abstractmethod
    @_spec
    async def parse_data_to_cdsl_payload(
        self,
        context: ContextModel,
        form_record: Annotated[
            GenericFormRecordModel,
            Doc("The form record for which the data has to be submitted"),
        ],
    ) -> PAYLOAD:
        """
        This function is to get the payload(s) for creating a demat account in CDSL
        """
        pass
