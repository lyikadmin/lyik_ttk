from abc import ABC, abstractmethod
from typing import Dict, Any, List, Tuple

import apluggy as pluggy

from ._config import getProjectName
from ..models import (
    DataTransformModel,
    ContextModel,
)
from ._config import getProjectName
from typing import Dict, Any, List, Union, Tuple, Annotated
from typing_extensions import Doc
from ..models import VerifyHandlerResponseModel, TrustedResponseModel

_spec = pluggy.HookspecMarker(getProjectName())


class DataTransformSpec(ABC):

    @abstractmethod
    @_spec
    async def transform_in(self, payload: DataTransformModel):
        """
        This function will make the necessary transformation for one (typically one) or more attributes of the record
        For example
        it may mask the aadhaar number and store it in the vault
        It may set the date fields to the right format and so on
        """
        pass

    @abstractmethod
    @_spec
    async def transform_out(self, payload: DataTransformModel):
        """
        This function will make the necessary transformation for one (typically one) or more attributes of the record
        For example
        It may convert a masked aadhaar back to its unencrypted form
        """
        pass


class VerifyHandlerSpec(ABC):
    """
    Specification for all plugins implementing a verify handler plugin.

    A verify handler is responsible for verifying the values from a field, and returns its status.

    If a field has the metadata of verify.verify_handler, that verify_handler is called to verify the field value,
    and return its verification status and message. The UI uses this to show the verification status for that field.

    This response may be referenced by other fields that require auto-population.
    """

    @abstractmethod
    @_spec
    async def verify_handler(
        self,
        context: Annotated[
            ContextModel | None,
            Doc(
                "Any metadata which the plugin can use, such as the config, field definition etc."
            ),
        ],
        payload: Annotated[
            dict,
            Doc(
                """
                The value of a field that requires verification.
                
                If a field has an associated verifier, its value is taken and passed as payload to the verify_handler. 

                The UI will store the response of the verification, and use it to denote verificatoin status and message.
                """
            ),
        ],
    ) -> Annotated[
        VerifyHandlerResponseModel,
        Doc(
            """The standard response returned by every verify handler.
            
            This response mainly includes:
            - The verification status.
            - A message providing context or error details.
            """
        ),
    ]:
        """
        Handles the verification of a core field's payload and returns a standard verification response.

        The verification process is triggered when a form field references a core field with verification enabled.
        If verification is successful, the form UI allows the user to proceed; otherwise, corrective actions
        may be required before submission.
        """
        pass


class TrustedPluginSpec(ABC):
    """
    Specification for all plugins implementing a trusted plugin.

    A trusted API is responsible for dynamically fetching field values, often used for:
    - OCR-based field population.
    - Auto-filling forms from enterprise data sources such as CIS (Customer Information System).

    Fields meant to invoke a trusted API use the notation `API.xxx`, where `xxx` represents the
    specific functionality being requested. The UI triggers the trusted API when such a field
    is encountered, and the output is stored as the `response` attribute of the field.

    A field can then access the data with the notation `FLD.reponse_key_name`,
    where the response_key_name is present in the response.

    This response can be referenced by other fields that require auto-population.
    """

    @abstractmethod
    @_spec
    async def trusted(
        self,
        context: Annotated[
            ContextModel | None,
            Doc(
                "Any metadata which the plugin can use, such as the config, field definition etc."
            ),
        ],
        payload: Annotated[
            dict,
            Doc(
                """
                The value of a field that requires trusted API resolution.
                
                If a field is marked as an API-driven field (e.g., `API.OCR`), its value is dynamically 
                retrieved from the trusted API and passed as the payload. 

                The UI will store the response of the trusted API call and use it to populate relevant fields 
                automatically.
                """
            ),
        ],
    ) -> Annotated[TrustedResponseModel, Doc("")]:
        """
        Returns a populated response data based on the field values it receives.
        This enables automated field population for other fields, which reference the output of a trusted plugin.
        """


NEW_STATE = str


class StateProcessorSpec(ABC):
    """
    This is the single specification for plugins which process the state of a record
    """

    @abstractmethod
    @_spec
    async def process_and_return_state(
        self,
        context: ContextModel | None,
        record: Annotated[
            dict,
            Doc("The form record which includes the data to process and change state"),
        ],
        record_id: Annotated[int, Doc("The record id")],
        state_action: Annotated[str, Doc("")],
    ) -> Annotated[
        Tuple[NEW_STATE, dict],
        Doc(
            "The new state, and the modified form record, with the audit logs are returned."
        ),
    ]:
        """
        This gets the current state and data from the form record, processes the state,
        and returns the new state, along with modified record (Audit logs)
        """


# class EmailSpec(ABC):
#
#     @abstractmethod
#     @_spec
#     async def send_email(
#         self, payload: EmailModel, context: ContextModel | None
#     ) -> bool:
#         """
#         This function is to send email.
#
#         Args:
#             payload (EmailModel): The email payload.
#             context (ContextModel): The context model.
#
#         Returns:
#             bool: True if email is sent successfully, False otherwise.
#
#         """
#         pass


# class SmsSpec(ABC):
#
#     @abstractmethod
#     @_spec
#     async def send_sms(self, payload: SmsModel, context: ContextModel) -> bool:
#         """
#         This function is to send sms
#
#         Args:
#             payload (SmsModel): The sms payload.
#             context (ContextModel): The context model.
#
#         Returns:
#             bool: True if sms is sent successfully, False otherwise.
#         """
#         pass


# class OtpSpec(ABC):
#
#     @abstractmethod
#     @_spec
#     async def verify_authorization_code(
#         self, contact_id, auth_code, context: ContextModel
#     ):
#         """
#         This function is to verify the authorization code
#         """
#         pass
#
#     @abstractmethod
#     @_spec
#     async def verify_otp(self, contact_id, otp, transaction_id, context: ContextModel):
#         """
#         This function is to verify the OTP
#         """
#         pass
#
#     @abstractmethod
#     @_spec
#     async def generate_and_send_otp(self, contact_id, context: ContextModel):
#         """
#         This function is to generate and send OTP
#         """
#         pass
