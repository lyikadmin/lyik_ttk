from __future__ import annotations
from typing import List, Any, get_type_hints, Tuple
import apluggy as pluggy
from .core import getProjectName, SPEC_LIST
from .models import ContextModel
from .core import ConfigProxy
from .annotation import RequiredVars, RequiredEnv
import inspect
import asyncio
import os
from enum import Enum
from .validator import validate_plugin_inputs, validate_plugin_output
import threading
import logging

logger = logging.getLogger(__name__)


def _get_env_int(var_name: str, default: int) -> int:
    """
    Retrieve an integer environment variable safely, falling back to default if unset or invalid.
    """
    value = os.getenv(var_name, "").strip()
    if value.isdigit() or (value.startswith("-") and value[1:].isdigit()):
        return int(value)
    return default


class INVOKER_PATTERN(Enum):
    SINGLE = "single"
    ALL = "all"
    VERIFIER = "verifier"
    TRUSTED = "trusted"
    PIPELINE = "pipeline"
    FIRST_SUCCESS = "first_success"
    OPERATION = "operation"


class PluginManager:
    """
    Singleton Class to initiate hook implementers, and get invokers.
    """

    _instance = None
    _lock = threading.Lock()

    PLUGIN_LITERAL = str
    PLUGIN_SPEC = str

    def __new__(cls, *args, **kwargs):
        if not cls._instance:
            with cls._lock:
                if not cls._instance:
                    cls._instance = super().__new__(cls)
        return cls._instance

    def __init__(self):
        if not hasattr(self, "pm"):  # Avoid reinitialisation
            self._load_plugin_manager()

    def _load_plugin_manager(self):
        self.pm = pluggy.PluginManager(getProjectName())
        for spec in SPEC_LIST:
            self.pm.add_hookspecs(spec)
        self.pm.load_setuptools_entrypoints(group=getProjectName())

    def get_invoker(
        self, method: str, pattern: INVOKER_PATTERN, plugin: str | None = None
    ) -> "PluginInvoker":
        """
        Get the appropriate invoker based on the specified pattern.
        """
        if pattern == INVOKER_PATTERN.SINGLE:
            return SinglePluginInvoker(self.pm, method, plugin)
        elif pattern == INVOKER_PATTERN.VERIFIER:
            return VerifierPluginInvoker(self.pm, method, plugin)
        elif pattern == INVOKER_PATTERN.OPERATION:
            return OperationPluginInvoker(self.pm, method, plugin)
        elif pattern == INVOKER_PATTERN.TRUSTED:
            return TrustedPluginInvoker(self.pm, method, plugin)
        elif pattern == INVOKER_PATTERN.PIPELINE:
            return PipelinePluginInvoker(self.pm, method)
        elif pattern == INVOKER_PATTERN.FIRST_SUCCESS:
            return FirstSuccessPluginInvoker(self.pm, method)
        elif pattern == INVOKER_PATTERN.ALL:
            return AllPluginInvoker(self.pm, method)
        else:
            raise ValueError(f"Unknown pattern: {pattern}")

    def generate_plugin_documentation(self, output_file="plugin_docs.md"):
        """
        Generates structured documentation for:
        1. All hookspecs and their hooks (with docstrings and parameter signatures).
        2. All hook implementers grouped by class (with docstrings).
        Saves the documentation to a Markdown file.
        """
        documentation = []

        # ================================
        # SECTION 1: HOOK SPECS & HOOKS
        # ================================
        documentation.append("# Section 1: Hook Specifications & Hooks\n")

        for spec in SPEC_LIST:
            spec_name = spec.__name__
            spec_doc = inspect.getdoc(spec) or "No documentation available."
            documentation.append(f"## {spec_name}\n")
            documentation.append(f"{spec_doc}\n")

            for hook_name in dir(spec):
                if hook_name.startswith("_"):  # Ignore private/internal methods
                    continue

                hook_func = getattr(spec, hook_name, None)
                if not callable(hook_func):
                    continue

                hook_doc = inspect.getdoc(hook_func) or "No documentation available."
                hook_signature, args_section, output_section = (
                    self._extract_parameter_info(hook_func)
                )

                documentation.append(f"### {hook_name}\n")
                documentation.append(f"**Signature:** `{hook_signature}`\n")
                documentation.append(f"{hook_doc}\n")
                if args_section:
                    documentation.append(f"**Args:**\n{args_section}\n")
                if output_section:
                    documentation.append(f"**Output:**\n{output_section}\n")
                documentation.append("---")  # Separator

        # ================================
        # SECTION 2: HOOK IMPLEMENTERS
        # ================================
        documentation.append("\n# Section 2: Hook Implementers (By Class)\n")

        plugin_classes = {}

        for spec in SPEC_LIST:
            for hook_name in dir(spec):
                if hook_name.startswith("_"):  # Ignore private/internal methods
                    continue

                hook_caller = getattr(self.pm.hook, hook_name, None)
                if not hook_caller or not hasattr(hook_caller, "get_hookimpls"):
                    continue

                for impl in hook_caller.get_hookimpls():
                    plugin = impl.plugin
                    plugin_name = self.pm.get_name(plugin)

                    if plugin not in plugin_classes:
                        plugin_classes[plugin] = {
                            "name": plugin_name,
                            "doc": inspect.getdoc(plugin)
                            or "No documentation available.",
                            "hookspecs": set(),
                            "hooks": [],
                        }

                    hook_func = getattr(plugin, hook_name, None)
                    hook_signature, args_section, output_section = (
                        self._extract_parameter_info(hook_func)
                    )

                    plugin_classes[plugin]["hookspecs"].add(spec.__name__)
                    plugin_classes[plugin]["hooks"].append(
                        {
                            "hook_name": hook_name,
                            "signature": hook_signature,
                            "doc": inspect.getdoc(hook_func)
                            or "No documentation available.",
                            "args_section": args_section,
                            "output_section": output_section,
                        }
                    )

        for plugin, details in plugin_classes.items():
            documentation.append(f"## {details['name']}\n")
            documentation.append(f"{details['doc']}\n")
            documentation.append(
                f"**Implements Specs:** `{', '.join(details['hookspecs'])}`\n"
            )

            for hook in details["hooks"]:
                documentation.append(f"### {hook['hook_name']}\n")
                documentation.append(f"**Signature:** `{hook['signature']}`\n")
                documentation.append(f"{hook['doc']}\n")
                if hook["args_section"]:
                    documentation.append(f"**Args:**\n{hook['args_section']}\n")
                if hook["output_section"]:
                    documentation.append(f"**Output:**\n{hook['output_section']}\n")
                documentation.append("---")  # Separator

        with open(output_file, "w", encoding="utf-8") as f:
            f.write("\n".join(documentation))

        logger.info(f"Plugin documentation generated: {output_file}")

    def check_plugin_required_env_variables(self):
        """
        Checks if every environment variable required by the plugins exists in the current environment.
        If not, it raises an exception to shut down the server.
        """

        # Get the required environment variables from all plugins
        required_env_list = self._get_required_env_from_all_plugins()

        # Get all environment variable names
        env_var_dict = os.environ

        missing_vars = []
        invalid_vars = []

        for var_name in required_env_list:
            if var_name not in env_var_dict:
                missing_vars.append(var_name)
            else:
                # Validate the value based on type hints in the variable name
                var_value = env_var_dict[var_name]
                if ":" in var_name:
                    base_name, var_type = var_name.split(":", 1)

                    if var_type == "File":
                        if not os.path.isfile(var_value):
                            invalid_vars.append(
                                f"{var_name} (File path does not exist)"
                            )

                    elif var_type == "bool":
                        if var_value.lower() not in {"true", "false"}:
                            invalid_vars.append(f"{var_name} (Expected boolean)")

                    elif var_type == "int":
                        if not var_value.isdigit():
                            invalid_vars.append(f"{var_name} (Expected integer)")

                    elif var_type == "str":
                        if not isinstance(var_value, str):
                            invalid_vars.append(f"{var_name} (Expected string)")

        # Raise errors if necessary
        if missing_vars or invalid_vars:
            error_messages = []
            if missing_vars:
                error_messages.append(
                    f"Missing required environment variables: {', '.join(missing_vars)}"
                )
            if invalid_vars:
                error_messages.append(
                    f"Invalid environment variable values: {', '.join(invalid_vars)}"
                )

            raise Exception("\n".join(error_messages))

    def _get_required_env_from_all_plugins(self) -> List[str]:
        """
        Get a list of all environment variables required by the plugins.
        """
        required_env_list = []
        for spec in SPEC_LIST:
            for hook_name in dir(spec):
                if hook_name.startswith("_"):  # Ignore private/internal methods
                    continue

                hook_caller = getattr(self.pm.hook, hook_name, None)
                if not hook_caller or not hasattr(hook_caller, "get_hookimpls"):
                    continue

                for hookimpl in hook_caller.get_hookimpls():
                    hookimpl_func = hookimpl.function
                    type_hints = get_type_hints(hookimpl_func, include_extras=True)
                    return_annotation = type_hints.get("return", None)
                    if return_annotation:
                        metadata = getattr(return_annotation, "__metadata__", None)
                        if metadata:
                            for meta in metadata:
                                if isinstance(meta, RequiredEnv):
                                    required_env_list.extend(meta.vars)

        return list(set(required_env_list))

    def _extract_parameter_info(self, func):
        """
        Extracts function parameter information including:
        - Type hints (handling `Annotated[]` to extract the primary type)
        - Parameter descriptions from `Doc("")` if present
        - Function return type with description
        """
        from typing import Any, Annotated, get_origin, get_args, get_type_hints

        signature = inspect.signature(func)
        type_hints = get_type_hints(func, include_extras=True)

        param_details = []
        param_descriptions = []

        for param_name, param in signature.parameters.items():
            param_type = type_hints.get(param_name, "Unknown")  # Extract type hint

            # Handle `Annotated[T, Doc("description")]`
            param_desc = None
            if get_origin(param_type) is Annotated:
                args = get_args(param_type)
                param_type = args[0]  # Extract the actual type
                param_desc = next(
                    (str(a.description) for a in args[1:] if hasattr(a, "description")),
                    None,
                )

            # Format type for signature
            type_str = f"{param_name}: {param_type.__name__ if isinstance(param_type, type) else param_type}"

            param_details.append(type_str)

            # Format Args section
            formatted_param_desc = f"- **{param_name}** ({param_type.__name__ if isinstance(param_type, type) else param_type}):"

            if param_desc and isinstance(param_desc, str):
                formatted_desc = param_desc.strip().replace(
                    "\n", "\n    "
                )  # Process separately
                formatted_param_desc += f"\n    {formatted_desc}"  # Append safely

            param_descriptions.append(formatted_param_desc)

        # Extract return type
        return_type = type_hints.get("return", "None")
        return_desc = None
        if get_origin(return_type) is Annotated:
            args = get_args(return_type)
            return_type = args[0]
            return_desc = next(
                (str(a.description) for a in args[1:] if hasattr(a, "description")),
                None,
            )

        # Format return type for signature
        return_type_str = (
            return_type.__name__ if isinstance(return_type, type) else return_type
        )

        # Format return description
        output_description = ""
        if return_desc and isinstance(return_desc, str):
            formatted_return_desc = return_desc.strip().replace(
                "\n", "\n    "
            )  # Process separately
            output_description = f"- **return** ({return_type_str}):\n    {formatted_return_desc}"  # Append safely

        # Combine all formatted details
        full_signature = f"({', '.join(param_details)}) -> {return_type_str}"
        args_section = "\n".join(param_descriptions)
        output_section = output_description if output_description else ""

        return full_signature, args_section, output_section


class PluginInvoker:
    """
    Base class for all plugin invokers. Handles the main logic of invoking plugin hooks.
    Subclasses should prepare invocation by selecting plugins, and invoking them.
    """

    def __init__(
        self, pm: pluggy.PluginManager, method: str, plugin: str | None = None
    ):
        self.pm = pm
        self.method = method
        self.plugin = plugin
        # Following environment variables set the range for the allowed plugins to run
        self.min_weight = _get_env_int("PLUGIN_MIN_WEIGHT", 0)
        self.max_weight = _get_env_int("PLUGIN_MAX_WEIGHT", 1000)

    def _remove_restricted_plugins(self, hookimpls) -> List:
        """
        Check if the plugins are whithin the allowed range or not. Only allow plugins which are not whithin the restricted range.
        """

        def _is_plugin_allowed(plugin_name: str) -> bool:
            parts = plugin_name.split("_")
            if len(parts) > 1 and parts[1].isdigit():
                weight = int(parts[1])
                return self.min_weight <= weight <= self.max_weight
            return False

        hookimpls = [
            h for h in hookimpls if _is_plugin_allowed(self.pm.get_name(h.plugin))
        ]
        return hookimpls

    def _get_hook_implementations(self) -> List:
        """
        Retrieve and filter hook implementations based on method and plugin.
        Get the IT Team provided restrictions to make sure only the allowed plugin range
        """
        hook_caller = getattr(self.pm.hook, self.method, None)
        if not hook_caller:
            raise Exception(f'No hook named "{self.method}"')

        hookimpls = hook_caller.get_hookimpls()

        plugin_name_information = ""

        if self.plugin:
            hookimpls = [
                h
                for h in hookimpls
                if str(self.pm.get_name(h.plugin)).endswith(str(self.plugin))
            ]
            plugin_name_information = f' "{self.plugin}"'

        if not hookimpls:
            raise Exception(
                f'No plugin{plugin_name_information} implements function "{self.method}"'
            )

        hookimpls = self._remove_restricted_plugins(hookimpls)

        if not hookimpls:
            raise Exception(
                f'No plugin{plugin_name_information} implements function "{self.method}" whithin the range {self.min_weight}->{self.max_weight}'
            )

        return hookimpls

    FUNC_PARAM_KWARGS = dict
    CONTEXT_PARAM_KWARGS = dict

    def _get_func_and_context_parameter_kwargs_from_kwargs(
        self, hookimpl_func, kwargs
    ) -> Tuple[FUNC_PARAM_KWARGS, CONTEXT_PARAM_KWARGS]:
        """
        Separate the kwargs received into two.
        1. Parameters required for the hook implementer directly (apart from the context)
        2. Parameters required to create the ContextModel
        Returns both the hookfunction parameters, and the context parameters as kwargs.
        """

        # Get the signature of the hook implementation, so that appropriate params can be separated from the kwargs.
        hookimpl_func_signature = inspect.signature(hookimpl_func)
        function_params = set(hookimpl_func_signature.parameters.keys())

        # Separate the arguments for the function and the context
        func_param_kwargs = {k: v for k, v in kwargs.items() if k in function_params}
        context_param_kwargs = {
            k: v for k, v in kwargs.items() if k not in function_params
        }
        return func_param_kwargs, context_param_kwargs

    def _create_context_from_context_param_kwargs(
        self, context_param_kwargs: dict, requested_vars: list
    ) -> ContextModel:
        """
        Creates the ContextModel from the context_param_kwargs.
        This creates the ConfigProxy with the requested variables, and handles instance of ConfigProxy aswell.
        """
        # Extract config separately
        config = context_param_kwargs.pop("config", None)
        # If already an instance of configproxy, get the original config.(
        # This can happen when a plugin invokes another plugin using its config.
        if isinstance(config, ConfigProxy):
            config = config.global_config
        config = ConfigProxy(config=config, requested_vars=requested_vars)

        # Create ContextModel with remaining kwargs
        context = ContextModel(config=config, **context_param_kwargs)

        return context

    async def _validate_input_and_call_plugin(self, func_to_call, **kwargs) -> Any:
        """
        Get the validated kwargs and calls the plugin using that.
        """
        validated_kwargs = await validate_plugin_inputs(func_to_call, **kwargs)
        return await func_to_call(**validated_kwargs)

    def _validate_plugin_output(self, result: Any) -> Any:
        """
        Default implementation (subclasses override this for stricter validation).
        """
        return result

    def _get_requested_config_vars_for_implementers(self, hookimpls: List) -> List:
        """
        Get the requested configuration variables from the hook implementers (plugins).
        This returns a list of variable names requested from the global config.
        ConfigProxy can later use this to create a limited access of the config specific to the plugin.
        """
        requested_vars = []
        for hookimpl in hookimpls:
            hookimpl_func = hookimpl.function
            type_hints = get_type_hints(hookimpl_func, include_extras=True)
            return_annotation = type_hints.get("return", None)
            if return_annotation:
                metadata = getattr(return_annotation, "__metadata__", None)
                if metadata:
                    for meta in metadata:
                        if isinstance(meta, RequiredVars):
                            requested_vars.extend(meta.vars)
        # Remove duplicates by converting to a set and back to a list
        requested_vars = list(set(requested_vars))
        return requested_vars

    async def invoke(self, hookimpls: List, **kwargs) -> Any:
        """Executes the function(s) from the provided hook implementations."""
        results = []
        for hookimpl in hookimpls:
            func_to_call = hookimpl.function

            result = await self._validate_input_and_call_plugin(func_to_call, **kwargs)
            results.append({self.pm.get_name(hookimpl.plugin): result})
        return results

    def get_highest_weight_plugin(self, hookimpls: List):
        """
        Returns the hookimpl with the highest weight in the unrestricted range.
        """

        def _get_plugin_weight(plugin):
            try:
                return int(self.pm.get_name(plugin).split("_")[1])
            except (IndexError, ValueError):
                # Return a very low value to ensure this plugin is ignored
                return float("-inf")

        if not hookimpls:
            raise Exception("No hook implementations provided")

        if len(hookimpls) == 1:
            return hookimpls[0]

        highest_weight_plugin = max(
            hookimpls, key=lambda h: _get_plugin_weight(h.plugin)
        )
        return highest_weight_plugin


class SinglePluginInvoker(PluginInvoker):
    """
    Invokes a single plugin.
    """

    async def invoke(self, **kwargs) -> Any:
        # Get the hook implementation
        hookimpls = self._get_hook_implementations()
        # Get the plugin with hihgest weight in allowed range.
        hookimpl = super().get_highest_weight_plugin(hookimpls=hookimpls)

        # Separate the kwargs to hookfunctions parameters, and the parameters required for context.
        hookimpl_func = hookimpl.function
        func_param_kwargs, context_param_kwargs = (
            self._get_func_and_context_parameter_kwargs_from_kwargs(
                hookimpl_func=hookimpl_func, kwargs=kwargs
            )
        )

        # Get the variables requested by the plugin (hookimplementer)
        requested_vars = self._get_requested_config_vars_for_implementers(
            hookimpls=[hookimpl]
        )

        # Create the context with required variable config.
        context = self._create_context_from_context_param_kwargs(
            context_param_kwargs=context_param_kwargs, requested_vars=requested_vars
        )

        # Invoke the plugin, and get the result.
        # This also validates the input before invoking the plugin
        result: List[dict] = await super().invoke(
            hookimpls=[hookimpl], context=context, **func_param_kwargs
        )
        result_val = next(iter(result[0].values()))

        # Validate the result
        result = await validate_plugin_output(
            func_to_call=hookimpl.function, result=result_val
        )
        return result


class VerifierPluginInvoker(PluginInvoker):
    """
    Invokes a verification plugin.
    """

    async def invoke(self, **kwargs) -> Any:
        # Get the hook implementation
        hookimpls = self._get_hook_implementations()
        # Get the plugin with hihgest weight in allowed range.
        hookimpl = super().get_highest_weight_plugin(hookimpls=hookimpls)

        # Separate the kwargs to hookfunctions parameters, and the parameters required for context.
        hookimpl_func = hookimpl.function
        func_param_kwargs, context_param_kwargs = (
            self._get_func_and_context_parameter_kwargs_from_kwargs(
                hookimpl_func=hookimpl_func, kwargs=kwargs
            )
        )

        # Get the variables requested by the plugin (hookimplementer)
        requested_vars = self._get_requested_config_vars_for_implementers(
            hookimpls=[hookimpl]
        )

        # Create the context with required variable config.
        context = self._create_context_from_context_param_kwargs(
            context_param_kwargs=context_param_kwargs, requested_vars=requested_vars
        )

        # Invoke the plugin, and get the result.
        # This also validates the input before invoking the plugin
        result: List[dict] = await super().invoke(
            hookimpls=[hookimpl], context=context, **func_param_kwargs
        )
        result_val = next(iter(result[0].values()))

        # Validate the result
        result = await validate_plugin_output(
            func_to_call=hookimpl.function, result=result_val
        )
        return result


class OperationPluginInvoker(PluginInvoker):
    """
    Invoked an operation plugin
    """

    async def invoke(self, **kwargs) -> Any:
        hookimpls = self._get_hook_implementations()
        # Get the plugin with hihgest weight in allowed range.
        hookimpl = super().get_highest_weight_plugin(hookimpls=hookimpls)

        # Separate the kwargs to hookfunctions parameters, and the parameters required for context.
        hookimpl_func = hookimpl.function
        func_param_kwargs, context_param_kwargs = (
            self._get_func_and_context_parameter_kwargs_from_kwargs(
                hookimpl_func=hookimpl_func, kwargs=kwargs
            )
        )

        # Get the variables requested by the plugin (hookimplementer)
        requested_vars = self._get_requested_config_vars_for_implementers(
            hookimpls=[hookimpl]
        )

        # Create the context with required variable config.
        context = self._create_context_from_context_param_kwargs(
            context_param_kwargs=context_param_kwargs, requested_vars=requested_vars
        )

        # Invoke the plugin, and get the result.
        # This also validates the input before invoking the plugin
        result: List[dict] = await super().invoke(
            hookimpls=[hookimpl], context=context, **func_param_kwargs
        )
        result_val = next(iter(result[0].values()))

        # Validate the result
        result = await validate_plugin_output(
            func_to_call=hookimpl.function, result=result_val
        )
        return result


class TrustedPluginInvoker(PluginInvoker):
    """
    Invokes a trusted api plugin.
    """

    async def invoke(self, **kwargs) -> Any:
        # Get the hook implementation
        hookimpls = self._get_hook_implementations()
        # Get the plugin with hihgest weight in allowed range.
        hookimpl = super().get_highest_weight_plugin(hookimpls=hookimpls)

        # Separate the kwargs to hookfunctions parameters, and the parameters required for context.
        hookimpl_func = hookimpl.function
        func_param_kwargs, context_param_kwargs = (
            self._get_func_and_context_parameter_kwargs_from_kwargs(
                hookimpl_func=hookimpl_func, kwargs=kwargs
            )
        )

        # Get the variables requested by the plugin (hookimplementer)
        requested_vars = self._get_requested_config_vars_for_implementers(
            hookimpls=[hookimpl]
        )

        # Create the context with required variable config.
        context = self._create_context_from_context_param_kwargs(
            context_param_kwargs=context_param_kwargs, requested_vars=requested_vars
        )

        # Invoke the plugin, and get the result.
        # This also validates the input before invoking the plugin
        result: List[dict] = await super().invoke(
            hookimpls=[hookimpl], context=context, **func_param_kwargs
        )
        result_val = next(iter(result[0].values()))

        # Validate the result
        result = await validate_plugin_output(
            func_to_call=hookimpl.function, result=result_val
        )
        return result


class PipelinePluginInvoker(PluginInvoker):
    """
    Invokes all matching plugins in a sequential pipeline, passing output as input.
    """

    async def invoke(self, **kwargs) -> dict:
        # Get the hook implementors
        hookimpls = self._get_hook_implementations()
        # Sort the hook implementors by name
        hookimpls.sort(key=lambda h: self.pm.get_name(h.plugin))

        # Separate the kwargs to hookfunctions parameters, and the parameters required for context.
        hookimpl_func = hookimpls[0].function
        func_param_kwargs, context_param_kwargs = (
            self._get_func_and_context_parameter_kwargs_from_kwargs(
                hookimpl_func=hookimpl_func, kwargs=kwargs
            )
        )

        # Get the variables requested by all hte plugins
        requested_vars = self._get_requested_config_vars_for_implementers(
            hookimpls=hookimpls
        )

        # Create the context with required variable config.
        context = self._create_context_from_context_param_kwargs(
            context_param_kwargs=context_param_kwargs, requested_vars=requested_vars
        )

        # Identify the last key-value pair dynamically
        if not func_param_kwargs:
            raise ValueError("No function parameters found in func_param_kwargs")

        last_key, last_value = list(func_param_kwargs.items())[-1]
        func_param_kwargs.pop(last_key)  # Remove from dict

        # Validate input and invoke each plugin, passing response dynamically
        for hookimpl in hookimpls:
            func_to_call = hookimpl.function
            last_value = await self._validate_input_and_call_plugin(
                func_to_call,
                context=context,
                **func_param_kwargs,
                **{last_key: last_value},
            )

        return last_value


class FirstSuccessPluginInvoker(PluginInvoker):
    """
    Invokes plugins until one successfully returns a result.
    """

    async def invoke(self, **kwargs) -> Any:
        # Get the hook implementations
        hookimpls = self._get_hook_implementations()
        # For each hookimplementor, call them till one does not throw an exception.
        # Then return that result
        for hookimpl in hookimpls:
            func_to_call = hookimpl.function
            try:
                result = await func_to_call(**kwargs)
                return {
                    self.pm.get_name(hookimpl.plugin): result
                }  # Return first successful execution
            except Exception as e:
                print(f"Plugin {self.pm.get_name(hookimpl.plugin)} failed: {e}")

        raise Exception(f"No plugin successfully executed method '{self.method}'")


class AllPluginInvoker(PluginInvoker):
    """
    Invokes all plugins.
    """

    async def invoke(self, **kwargs) -> Any:
        # Get the hook implementors
        hookimpls = self._get_hook_implementations()

        # Separate the kwargs to hookfunctions parameters, and the parameters required for context.
        hookimpl_func = hookimpls[0].function
        func_param_kwargs, context_param_kwargs = (
            self._get_func_and_context_parameter_kwargs_from_kwargs(
                hookimpl_func=hookimpl_func, kwargs=kwargs
            )
        )

        # Get the variables requested by the plugin (hookimplementer)
        requested_vars = self._get_requested_config_vars_for_implementers(
            hookimpls=hookimpls
        )

        # Extract config separately
        config = context_param_kwargs.pop("config", None)
        if config is not None:
            # If config is present, use it
            config = ConfigProxy(config=config, requested_vars=requested_vars)
            # Create ContextModel with remaining kwargs
            context = ContextModel(config=config, **context_param_kwargs)
            result: List[dict] = await super().invoke(
                hookimpls=hookimpls, context=context, **func_param_kwargs
            )
        else:
            # If not present, don't pass the config.
            result: List[dict] = await super().invoke(
                hookimpls=hookimpls, **func_param_kwargs
            )
        return result
