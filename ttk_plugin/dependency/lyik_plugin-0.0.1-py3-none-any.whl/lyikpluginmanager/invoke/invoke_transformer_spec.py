from ._invokers import InvokeSingleHighestWeightPlugin
from ..models import GenericFormRecordModel, TransformerResponseModel


@InvokeSingleHighestWeightPlugin()
async def template_transform_data(
    config: object,
    org_id: str,
    form_id: str,
    form_name: str,
    transformer: str,
    record: GenericFormRecordModel,
    additional_args: dict | None,
) -> TransformerResponseModel:
    """
    This function will transform the given record to the desired record format(dict),
    based on the provided transformer.
    """
    pass


@InvokeSingleHighestWeightPlugin()
async def template_generate_pdf(
    config: object,
    org_id: str,
    form_id: str,
    form_name: str,
    template_id: str,
    record: GenericFormRecordModel,
    additional_args: dict | None,
) -> TransformerResponseModel:
    """
    This function will transform and generate the desired pdf given the record,
    based on the provided transformer.

    If the template id is '01_AOF' then it will transform the pdf inside the 'AOF' directory.
    If the template id is 'AOF' then it will transform all the pdf inside the directory.

    And if the directory contains multiple pdf like,
    01_AOF.pdf, 02_AOF.pdf and 01_KYC.pdf, then
    01_AOF.pdf and 02_AOF.pdf will be concatenated together as AOF.pdf and flattened, 01_KYC.pdf will be flattened and returned.
    """
    pass
