from ._invokers import InvokeSingleHighestWeightPlugin
from ..models import GenericKYCData, ROOTDataModel


@InvokeSingleHighestWeightPlugin()
async def translate_to_kra(config: object, kyc_holder: GenericKYCData) -> ROOTDataModel:
    """This function is to translate payload into cvl kra record"""
    pass
