from ._invokers import InvokeSingleHighestWeightPlugin
from ..models import LinkedRecordResponseModel, GenericFormRecordModel
from typing import Dict
from typing import Annotated
from typing_extensions import Doc

@InvokeSingleHighestWeightPlugin()
async def create_linked_record(
    config: object,
    token:str,
    org_id: str,
    form_id: str,
    dbFormDict : dict,
    record_id: str,
    status: str,
    form_record: GenericFormRecordModel,
) -> LinkedRecordResponseModel:
    """
    This function is to create linked record.
    Args:
        config (object): Global config object.
        token (str): JWT encoded token
        org_id (str): The unique identifier for an organization.
        form_id (str): The unique identifier for a form id.
        dbFormDict (dict): The dbForm as a dictionary.
        record_id (str): The unique identifier for the record.
        status (str): The status of the form.
        form_record (GenericFormRecordModel): The form record for which the linked record has to be created.

    Returns:
        LinkedRecordResponseModel: This is the created linked record.
    """
    pass
