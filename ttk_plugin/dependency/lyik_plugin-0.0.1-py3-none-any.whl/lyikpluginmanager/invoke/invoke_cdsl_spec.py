from ._invokers import InvokeSingleHighestWeightPlugin
from ..models import GenericFormRecordModel


RESPONSE = dict


@InvokeSingleHighestWeightPlugin()
async def upload_bo_setup(
    config: object,
    form_record: GenericFormRecordModel,
) -> RESPONSE:
    """
    This submits the data to CDSL.
    This returns the response text.
    """
    pass
