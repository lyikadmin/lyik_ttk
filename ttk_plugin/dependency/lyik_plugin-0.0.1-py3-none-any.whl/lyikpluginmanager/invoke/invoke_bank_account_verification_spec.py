from ._invokers import InvokeSingleHighestWeightPlugin
from ..models import BankAccountVerifierResponseModel


@InvokeSingleHighestWeightPlugin()
async def verify_bank(
    config: object,
    ifsc_code: str,
    account_number: str,
    name: str,
    mobile_number: str,
) -> BankAccountVerifierResponseModel:
    """
    This function is to verify the bank acount details of an user.
    """
    pass
