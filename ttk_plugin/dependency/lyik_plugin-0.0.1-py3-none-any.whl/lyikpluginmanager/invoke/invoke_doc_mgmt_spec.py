# from ..core import ALLOWED_VARS
# from ..models import DocumentModel
# from typing import Annotated
# from ._invokers import InvokeSinglePlugin
# from typing_extensions import Doc


# @InvokeSinglePlugin()
# async def addDocument(
#     config: object,
#     org_id: str,
#     document: DocumentModel,
#     coll_name: str,
# ) -> DocumentModel:
#     """This function will add a document in the DB."""
#     pass


# @InvokeSinglePlugin()
# async def deleteDocument(
#     config: object,
#     org_id: str,
#     file_id: str,
#     coll_name: str,
# ):
#     """
#     This function will delete a document given a file_id
#     """
#     pass


# @InvokeSinglePlugin()
# async def fetchDocument(
#     config: object,
#     org_id: str,
#     file_id: str,
#     coll_name: str,
# ) -> DocumentModel:
#     """
#     This function wil return a file in documentModel format
#     """
#     pass


# @InvokeSinglePlugin()
# async def updateDocument(
#     config: object,
#     org_id: str,
#     file_id: str,
#     document: DocumentModel,
#     coll_name: str,
# ) -> DocumentModel:
#     """
#     This function will update a document given a old file_id and new file data and return the new file
#     """
#     pass


from ..core import ALLOWED_VARS
from ..models import DocumentModel, DocMeta, DocQueryGenericModel, DBDocumentModel
from typing import Annotated, Dict, Any, List
from ._invokers import InvokeSingleHighestWeightPlugin
from typing_extensions import Doc


@InvokeSingleHighestWeightPlugin()
async def addDocument(
    config: object,
    org_id: str,
    document: DocumentModel,
    coll_name: str,
    metadata: DocMeta | None,
) -> DBDocumentModel:
    """
    Adds a document in db along with metadata if provided.
    Args:
        org_id: org id of the organization to determine db
        coll_name: db collection name
        document: document to be stored
        metadata: metadata to be stored along with document, if any.
    Returns:
        DBDocumentModel: added document info having doc id along with some other info.
    """
    pass


@InvokeSingleHighestWeightPlugin()
async def deleteDocument(
    config: object,
    org_id: str,
    file_id: str,
    coll_name: str,
    metadata_params:DocQueryGenericModel | None,
)->None:
    """
    Deletes the file(s) based on file_id or metadata_params, whichever provided.
    Args:
        org_id: org id of the organization to determine db
        file_id: unique id of the stored document.
        coll_name: db collection name
        metadata_params: meta data params for querying db collection if file_id is not known
    """
    pass


@InvokeSingleHighestWeightPlugin()
async def fetchDocument(
    config: object,
    org_id: str,
    file_id: str | None,
    coll_name: str,
    metadata_params: DocQueryGenericModel | None,
) -> List[DBDocumentModel]:
    """
    Fetches the file(s) from db based on file_id or metadata_params.
    Args:
        org_id: org id of the organization to determine db
        file_id: unique id of the stored document.
        coll_name: db collection name
        metadata_params: meta data params for querying db collection if file_id is not known.
    Returns:
        List[DBDocumentModel]: List of documents each having file bytes along with metadata
    """
    pass


@InvokeSingleHighestWeightPlugin()
async def updateDocument(
    config: object,
    org_id: str,
    file_id: str | None,
    document: DocumentModel | None,
    coll_name: str,
    metadata_params:DocQueryGenericModel| None,
    new_metadata:DocMeta| None,

) -> List[DBDocumentModel]:
    """
    This update operation adds new documents in database and deletes existing one if only found!
    Args:
        org_id: org id of the organization to determine db
        file_id: unique id of the existing stored document.
        coll_name: db collection name
        metadata_params: meta data params for querying db collection if file_id is not known.
        document: new document to be stored
        new_metadata: new metadata to be stored along with document, if any.
    Returns:
        List[DBDocumentModel]: List of newly added documents each having new file id along with metadata.
    """
    pass

