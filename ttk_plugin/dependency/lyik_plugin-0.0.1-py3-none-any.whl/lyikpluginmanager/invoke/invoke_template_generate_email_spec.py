from ._invokers import InvokeSingleHighestWeightPlugin
from ..models import GenericFormRecordModel, TransformerResponseModel
from typing import Any, Dict


@InvokeSingleHighestWeightPlugin()
async def template_generate_email(
    self,
    config: object,
    org_id: str,
    form_id: str,
    form_name: str,
    record: GenericFormRecordModel,
    transformer: str,
    params: dict,
) -> TransformerResponseModel:
    """
    Given the template_name it will generate the email body and
    Send the email and return a success or failure message back
    If any attachment is found it will get that file from the responsible source and attach to the email body
    """
    pass
