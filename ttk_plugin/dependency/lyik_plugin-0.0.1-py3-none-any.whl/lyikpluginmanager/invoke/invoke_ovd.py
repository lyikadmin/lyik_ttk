from typing import Union
from ..models import TrustedResponseModel, TRUSTED_RESPONSE_STATUS
from ..models.ovd import (
    OVDType,
    OVDInput,
    OVDGenericResponse,
    OVDAadhaar,
    OVDDrivingLicense,
    OVDPassport,
    OVDPAN,
    OVDVoterId,
)
from .invoke_spec import trusted

FILE_PATH = str
FILE_PATH_OR_NONE = FILE_PATH | None


async def fetch_ovd_details(
    config: object,
    ovd_front: FILE_PATH_OR_NONE = None,
    ovd_back: FILE_PATH_OR_NONE = None,
) -> Union[
    OVDGenericResponse, OVDPassport, OVDPAN, OVDAadhaar, OVDDrivingLicense, OVDVoterId
]:
    """
    This is an invoker that will internally invoke the trusted plugin with the name "TRUSTED_OVD.
    Without such as trusted plugin, the plugins will have to work very hard to get the OVD.
    Also such as plugin might actually be useful even in customer specific plugins.
    Hence adding it as an invoker for all to use
    """
    payload = OVDInput(
        ovd_type=None,
        ovd_front=ovd_front,
        ovd_back=ovd_back,
    )
    trusted_response: TrustedResponseModel = await trusted(
        config=config, trusted_plugin="TRUSTED_OVD", payload=payload.model_dump()
    )

    if trusted_response.status == TRUSTED_RESPONSE_STATUS.FAILURE:
        raise Exception(f"{trusted_response.message}")

    ovd_response = OVDGenericResponse(**trusted_response.response)
    match ovd_response.document_type:
        case OVDType.AADHAAR:
            ovd_response = OVDAadhaar(**trusted_response.response)
        case OVDType.PAN:
            ovd_response = OVDPAN(**trusted_response.response)
        case OVDType.VOTER_ID:
            ovd_response = OVDVoterId(**trusted_response.response)
        case OVDType.PASSPORT:
            ovd_response = OVDPassport(**trusted_response.response)
        case OVDType.DRIVING_LICENSE:
            ovd_response = OVDDrivingLicense(**trusted_response.response)

    return ovd_response
