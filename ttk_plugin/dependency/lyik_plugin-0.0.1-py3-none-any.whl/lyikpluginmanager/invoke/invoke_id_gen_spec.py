from typing import Annotated
from ._invokers import InvokeSingleHighestWeightPlugin
from typing_extensions import Doc


@InvokeSingleHighestWeightPlugin()
async def idGen(
    config: object,
    db_name: Annotated[str, Doc("Name of the db in the database")],
) -> Annotated[str, Doc("A unique generated id based on a sequence will be returned")]:
    """This will generate an id based on the sequence"""
    pass
