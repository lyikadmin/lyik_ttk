from ._invokers import InvokeSingleHighestWeightPlugin
from ..models import SmsModel

SUCCESS = bool


@InvokeSingleHighestWeightPlugin()
async def send_sms(config: object, payload: SmsModel) -> SUCCESS:
    """
    This sends the sms to the contact id.
    """
    pass
