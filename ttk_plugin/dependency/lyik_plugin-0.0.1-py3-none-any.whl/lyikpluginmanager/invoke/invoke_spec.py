from ..models import VerifyHandlerResponseModel, TrustedResponseModel
from typing import Dict, List, Tuple
from ._invokers import InvokeSingleHighestWeightPlugin, InvokeVerifier, InvokeTrusted


@InvokeSingleHighestWeightPlugin()
async def invoke_get_relationship_info_for_users(
    config: object, user_id: str
) -> Dict[str, List[str]]:
    """Fetches relationship information for a user."""
    pass


@InvokeVerifier()
async def verify_handler(
    config: object,
    org_id: str,
    form_id: str,
    form_name: str,
    field_definition: dict,
    record: dict,
    verify_handler_plugin: str,
    payload: dict,
) -> VerifyHandlerResponseModel:
    """
    Calls verifier plugin and returns the Verify handler response.

    Args:
        config (object): Global config object.
        field_definition (dict): The field definition object associated with the verifiable field.
        verify_handler_plugin (str): The name of the verify handler plugin.
        payload (dict): The payload field value of the verifiable field.

    Returns:
        VerifyHandlerResponseModel: The response model from the verify handler.
    """
    pass


@InvokeTrusted()
async def trusted(
    config: object, trusted_plugin: str, payload: dict
) -> TrustedResponseModel:
    """
    Calls a trusted plugin with the given configuration and payload.

    Args:
        config (object): The configuration object for the plugin.
        trusted_plugin (str): The name of the trusted plugin to be called.
        payload (dict): The payload field value of field.

    Returns:
        TrustedResponseModel: The response from the trusted plugin.
    """
    pass


@InvokeSingleHighestWeightPlugin()
async def process_and_return_state(
    config: object,
    token: str,
    form_id: str,
    org_id: str,
    form_name: str,
    record: dict,
    record_id: int,
    state_action: str,
) -> Tuple[str, dict]:
    """
    Calls the state processor plugin. Processes the state and returns the new state, and modified record.

    Args:
        config (object): The configuration object for the plugin.
        token (str): The JWT encoded token.
        record (dict): The form record.
        record_id (int): The record id of the form record.
        state_action (str): The action to continue the state flow.

    Returns:
        Tuple[str, dict]: The new state and the modified form record as Tuple.
    """
    pass
