from functools import wraps
from typing import Callable, Dict, List, Any, Coroutine
from typing import TypeVar, Awaitable, Dict, List, Any
from typing_extensions import ParamSpec
from ..plugin import PluginManager, INVOKER_PATTERN

# Variabels we will use to denote the Functions Parameters and Return types. We will need this for type hints for IDE.
FnParams = ParamSpec("FnParams")
FnReturn = TypeVar("FnReturn")
class InvokeVerifier:
    """
    A decorator that invokes a verification plugin for the decorated function.
    
    First, define the parameters required for the context. Then, define the parameters as specified in the spec, other than the context.
    Using the first parameters, the context is intelligently created, before invoking the plugin.
    
    This decorator retrieves the corresponding verification plugin method and 
    invokes it asynchronously with the given function's arguments.

    **Requirements:**
    - `verify_handler_plugin` (str): The name of the verification plugin to use.
    - `payload` (dict): The data payload required for verification.

    **Usage:**
    ```
    @InvokeVerifier()
    async def verify_data(...):
        ...
    ```

    The decorator dynamically determines the correct verifier based on 
    the function name and the provided plugin.
    """

    def __init__(self):
        pass

    def __call__(
        self, func: Callable[FnParams, FnReturn]
    ) -> Callable[FnParams, Awaitable[FnReturn]]:
        @wraps(func)
        async def wrapper(*args: FnParams.args, **kwargs: FnParams.kwargs) -> FnReturn:
            plugin_method_name = func.__name__
            verify_handler_plugin = kwargs.get("verify_handler_plugin")

            pm = PluginManager()
            verify_invoker = pm.get_invoker(
                method=plugin_method_name,
                pattern=INVOKER_PATTERN.VERIFIER,
                plugin=verify_handler_plugin,
            )

            result = await verify_invoker.invoke(**kwargs)

            return result

        return wrapper


class InvokeTrusted:
    """
    A decorator that invokes a trusted plugin for the decorated function.

    First, define the parameters required for the context. Then, define the parameters as specified in the spec, other than the context.
    Using the first parameters, the context is intelligently created, before invoking the plugin.
    
    This decorator ensures that the function runs with a specified trusted plugin 
    by dynamically determining the correct method.

    **Requirements:**
    - `trusted_plugin` (str): The name of the trusted plugin to use.
    - `payload` (dict): The data payload required for processing.

    **Usage:**
    ```
    @InvokeTrusted()
    async def process_trusted_data(...):
        ...
    ```

    The decorator dynamically determines the correct trusted plugin based on 
    the function name and the provided plugin.
    """

    def __init__(self):
        pass

    def __call__(
        self, func: Callable[FnParams, FnReturn]
    ) -> Callable[FnParams, Awaitable[FnReturn]]:
        @wraps(func)
        async def wrapper(*args: FnParams.args, **kwargs: FnParams.kwargs) -> FnReturn:
            plugin_method_name = func.__name__
            trusted_plugin = kwargs.get("trusted_plugin")

            pm = PluginManager()
            trusted_invoker = pm.get_invoker(
                method=plugin_method_name,
                pattern=INVOKER_PATTERN.TRUSTED,
                plugin=trusted_plugin,
            )

            result = await trusted_invoker.invoke(**kwargs)

            return result

        return wrapper


class InvokeOperation:
    """
    Invokes operation plugin.
    \n`opeation_plugin` mandatory.
    \n`payload` mandatory.
    """

    def __init__(self):
        pass

    def __call__(
        self, func: Callable[FnParams, FnReturn]
    ) -> Callable[FnParams, Awaitable[FnReturn]]:
        @wraps(func)
        async def wrapper(*args: FnParams.args, **kwargs: FnParams.kwargs) -> FnReturn:
            plugin_method_name = func.__name__

            operation_plugin = kwargs.get("operation_plugin")

            pm = PluginManager()
            trusted_invoker = pm.get_invoker(
                method=plugin_method_name,
                pattern=INVOKER_PATTERN.OPERATION,
                plugin=operation_plugin,
            )

            result = await trusted_invoker.invoke(**kwargs)

            return result

        return wrapper

class InvokeSingleHighestWeightPlugin:
    """
    A decorator that invokes the highest-weight available plugin and returns its output.

    First, define the parameters required for the context. Then, define the parameters as specified in the spec, other than the context.
    Using the first parameters, the context is intelligently created, before invoking the plugin.

    This decorator ensures that only a single, unrestricted plugin is invoked, 
    based on the function name. The plugin invoker manages the plugin selection process.

    **Usage:**
    ```
    @InvokeSinglePlugin()
    async def execute_with_single_plugin(...):
        ...
    ```

    Any method using this decorator can pass context parameters and actual specification parameters.
    """

    def __init__(self):
        pass

    def __call__(
        self, func: Callable[FnParams, FnReturn]
    ) -> Callable[FnParams, Awaitable[FnReturn]]:
        @wraps(func)
        async def wrapper(*args: FnParams.args, **kwargs: FnParams.kwargs) -> FnReturn:
            plugin_method_name = func.__name__

            pm = PluginManager()
            single_invoker = pm.get_invoker(
                method=plugin_method_name,
                pattern=INVOKER_PATTERN.SINGLE,
            )

            result = await single_invoker.invoke(**kwargs)

            return result

        return wrapper

class InvokeSingleSpecifiedPlugin:
    """
    A decorator that invokes the specifed plugin and returns its output. The highest weight of specifed name is invoked.

    First, define the parameters required for the context. Then, define the parameters as specified in the spec, other than the context.
    Using the first parameters, the context is intelligently created, before invoking the plugin.

    This decorator ensures that only a single, unrestricted plugin is invoked, 
    based on the function name. The plugin invoker manages the plugin selection process.

    **Usage:**
    ```
    @InvokeSinglePlugin()
    async def execute_with_single_plugin(...):
        ...
    ```

    Any method using this decorator can pass context parameters and actual specification parameters.
    """

    def __init__(self):
        pass

    def __call__(
        self, func: Callable[FnParams, FnReturn]
    ) -> Callable[FnParams, Awaitable[FnReturn]]:
        @wraps(func)
        async def wrapper(*args: FnParams.args, **kwargs: FnParams.kwargs) -> FnReturn:
            plugin_method_name = func.__name__
            plugin_name = kwargs.get("plugin_name")

            pm = PluginManager()
            single_invoker = pm.get_invoker(
                method=plugin_method_name,
                pattern=INVOKER_PATTERN.SINGLE,
                plugin=plugin_name
            )

            result = await single_invoker.invoke(**kwargs)

            return result

        return wrapper


class InvokePipeline:
    """
    A decorator that executes a pipeline of plugins in sequence.
    The plugin passes its output to the next plugin in the sequence.

    First, define the parameters required for the context. Then, define the parameters as specified in the spec, other than the context.
    Using the first parameters, the context is intelligently created, before invoking the plugin.
    
    This decorator ensures that the function is executed through a pipeline of 
    plugins based on their defined order and constraints.

    **Usage:**
    ```
    @InvokePipeline()
    async def process_pipeline(...):
        ...
    ```

    The plugin invoker manages the context and execution flow automatically.
    """

    def __init__(self):
        pass

    def __call__(
        self, func: Callable[FnParams, FnReturn]
    ) -> Callable[FnParams, Awaitable[FnReturn]]:
        @wraps(func)
        async def wrapper(*args: FnParams.args, **kwargs: FnParams.kwargs) -> FnReturn:
            plugin_method_name = func.__name__

            pm = PluginManager()
            pipeline_invoker = pm.get_invoker(
                method=plugin_method_name,
                pattern=INVOKER_PATTERN.PIPELINE,
            )

            result = await pipeline_invoker.invoke(**kwargs)

            return result

        return wrapper


class InvokeAll:
    """
    A decorator that invokes all available plugins and returns their results.
    This returns the output of all the plugins as a dictionary, in which the key is the plugin name, and the output is in the value.
    First, define the parameters required for the context. Then, define the parameters as specified in the spec, other than the context.
    Using the first parameters, the context is intelligently created, before invoking the plugin.
    
    This decorator ensures that all matching plugins are executed and returns 
    a combined result along with the corresponding plugin names.

    **Usage:**
    ```
    @InvokeAll()
    async def execute_all_plugins(...):
        ...
    ```

    The plugin invoker handles the selection and invocation of all relevant plugins.
    """

    def __init__(self):
        pass

    def __call__(
        self, func: Callable[FnParams, FnReturn]
    ) -> Callable[FnParams, Awaitable[FnReturn]]:
        @wraps(func)
        async def wrapper(*args: FnParams.args, **kwargs: FnParams.kwargs) -> FnReturn:
            plugin_method_name = func.__name__

            pm = PluginManager()
            all_invoker = pm.get_invoker(
                method=plugin_method_name,
                pattern=INVOKER_PATTERN.ALL,
            )

            result = await all_invoker.invoke(**kwargs)

            return result

        return wrapper
