from ._invokers import InvokeSingleHighestWeightPlugin

AUTH_CODE = str | None
TRANSACTION_ID = str | None
CONTACT_ID = str | None


@InvokeSingleHighestWeightPlugin()
async def verify_authorization_code(
    config: object, contact_id: str, auth_code: str
) -> CONTACT_ID:
    """
    This verifies the auth code with the contact id.
    This returns the contact id (str).
    """
    pass


@InvokeSingleHighestWeightPlugin()
async def generate_and_send_otp(config: object, contact_id: str) -> TRANSACTION_ID:
    """
    Generates and send the otp to the contact id. (Either email or sms).
    Returns the Transaction id (str)
    """
    pass


@InvokeSingleHighestWeightPlugin()
async def verify_otp(
    config: object, contact_id: str, otp: str, transaction_id: str
) -> AUTH_CODE:
    """
    This verifies the otp with the contact id and transaction id.
    This returns the auth code as a string.
    """
    pass
