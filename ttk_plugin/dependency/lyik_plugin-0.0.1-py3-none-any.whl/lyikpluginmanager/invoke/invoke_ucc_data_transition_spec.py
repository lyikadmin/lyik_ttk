from ._invokers import InvokeSingleHighestWeightPlugin
from ..models import GenericFormRecordModel, BSEPayload, NSEPayload
import io

# @InvokeSinglePlugin()
# async def ucc_bse_data_parse(
#     config: object,
#     form_record: GenericFormRecordModel,
# )->BSEPayload:
#     '''
#     This method formulates form record payload into BSEPayload 
#     '''
#     pass

# @InvokeSinglePlugin()
# async def ucc_nse_data_parse(
#     config: object,
#     form_record: GenericFormRecordModel,
# )->NSEPayload:
#     '''
#     This method formulates form record payload into NSEPayload 
#     '''
#     pass

@InvokeSingleHighestWeightPlugin()
async def ucc_data_parse(
    config: object,
    form_record: GenericFormRecordModel,
)->NSEPayload | BSEPayload:
    '''
    This method formulates form record payload into NSEPayload/BSEPayload based on NSDL/CDSL selection. 
    '''
    pass