from ._invokers import InvokeSingleHighestWeightPlugin
from ..models import OperationResponseModel, GenericFormRecordModel, NSDLResponseModel


@InvokeSingleHighestWeightPlugin()
async def create_demat_account(
    config: object, form_record: GenericFormRecordModel
) -> NSDLResponseModel:
    """This function is to call the NSDL API to create demat account"""
    pass
