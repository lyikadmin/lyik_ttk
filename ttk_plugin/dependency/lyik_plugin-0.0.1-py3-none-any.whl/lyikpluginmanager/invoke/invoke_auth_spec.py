from typing import Annotated, Union
from typing_extensions import Doc
from ._invokers import (
    InvokeAll,
    InvokeSingleHighestWeightPlugin,
    InvokeSingleSpecifiedPlugin,
)
from ..models import AuthorizationRequestModel, PreAuthorizedInfoModel


@InvokeAll()
async def isValidToken(token: str):
    pass


@InvokeSingleSpecifiedPlugin()
async def verifyToken(config: object, plugin_name: str, token: str):
    pass


AUTH_TOKEN = str


@InvokeSingleHighestWeightPlugin()
async def getAuthorizedToken(
    config: object,
    auth_request: Annotated[
        AuthorizationRequestModel | PreAuthorizedInfoModel | None,
        Doc(
            "Either an AuthorizationRequestModel (with `auth_code` & `contact_id`) "
            "or a PreAuthorizedInfoModel (with `user_id`, `roles`, `governed_users`, user_name, expiry, "
            "`plugin_provider`, and `token`)."
        ),
    ],
) -> Annotated[
    AUTH_TOKEN,
    Doc("A newly issued LYIK access token (JWT string) with configured scopes and expiry."),
]:
    """
    Issue a LYIK access token based on the provided authentication request.

    - **OTP flow** (`AuthorizationRequestModel`): validate the auth code and contact.
    - **SSO flow** (`PreAuthorizedInfoModel`): trust the pre-authorized user info.

    :param config: Global configuration object (e.g. plugin settings).
    :param auth_request: Auth request model for either OTP or SSO flow.
    :returns: A JWT string encoding the granted scopes and expiry.
    """
    pass


@InvokeSingleHighestWeightPlugin()
async def getRefreshedToken(
    config: object,
    token: Annotated[
        str,
        Doc("Existing LYIK access or refresh token to extend or replace."),
    ],
) -> Annotated[
    AUTH_TOKEN,
    Doc("A refreshed LYIK access token (JWT string) with a new expiry."),
]:
    """
    Refresh an existing LYIK token and return a new one with extended validity.

    :param config: Global configuration object.
    :param token: Current access or refresh token to be exchanged.
    :returns: A new JWT string with updated expiry.
    """
    pass


@InvokeSingleSpecifiedPlugin()
async def getPreAuthorizedInformation(
    config: object,
    plugin_name: Annotated[
        str,
        Doc("Identifier of the AuthProvider plugin to use for token validation."),
    ],
    token: Annotated[
        str,
        Doc("Opaque SSO token issued by the external identity provider."),
    ],
) -> Annotated[
    PreAuthorizedInfoModel,
    Doc("Model containing external `user_id`, mapped `roles`, and `governed_users`."),
]:
    """
    Validate an external SSO token and extract pre-authorized user details.

    :param config: Global configuration object.
    :param plugin_name: Name of the AuthProvider plugin to invoke.
    :param token: External SSO token presented by the client.
    :returns: A PreAuthorizedInfoModel with:
        - `user_id`
        - `roles`
        - `governed_users`
        - `user_name` (optional)
        - `expiry` (optional)
        - `plugin_provider` 
        - `token`
    """
    pass