from typing import Annotated
from ._invokers import InvokeSingleHighestWeightPlugin
from typing_extensions import Doc
from ..models import SubmitterModel


@InvokeSingleHighestWeightPlugin()
async def get_sumbmitter_info(
    config: object, token: Annotated[str, Doc("The API Token like: LYIKTOKEN")]
) -> Annotated[
    SubmitterModel,
    Doc("Returned as Submitter Model containing submitter information"),
]:
    """
    This function will return submitter information
    Submitter info will contain maker and user information
    """
    pass
