async def set_state_after_action(
    record: dict, action: str, org_id: str, form_id: str
) -> str:
    """
    Process an action and update the record state in the database.
    Updates both the record and linked record.
    Can be invoked by plugins or api to initiate state flow with an action.
    """
    from lyik_enterprise.state import StateManager
    from lyik_enterprise.model.models import dbFormRecord

    # Initiate state flow, and set the new state
    sm: StateManager = StateManager.instance(org_id=org_id, form_id=form_id)
    new_state = await sm.set_state_after_processing_action(
        record=dbFormRecord.model_validate(record),
        action=action,
        org_id=org_id,
        form_id=form_id,
    )
    return new_state
