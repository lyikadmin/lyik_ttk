from ._invokers import InvokeSingleHighestWeightPlugin
from ..models import EmailModel

SUCCESS = bool


@InvokeSingleHighestWeightPlugin()
async def send_email(config: object, payload: EmailModel) -> SUCCESS:
    """
    This sends the email to the contact id.
    """
    pass
