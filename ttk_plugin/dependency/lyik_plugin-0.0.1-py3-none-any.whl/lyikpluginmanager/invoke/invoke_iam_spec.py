from typing_extensions import Doc
from ._invokers import InvokeSingleHighestWeightPlugin
from ..models import IAMUserIdentifiers, IAMUserMetadata, RoleInfoModel
from typing import Annotated, Any, List


@InvokeSingleHighestWeightPlugin()
async def getIAMInfo(
    config: object, user_identifiers: IAMUserIdentifiers | None
) -> IAMUserMetadata:
    """
    Function to return the permissions given a user_id.

    Args:
        config (object): Global config object.
        user_identifiers (IAMUserIdentifiers | None): Object holding the user's identifying fields.

    Returns:
        IAMUserMetadata: An object containing the user record, role-based permissions, and related relationship details.
    """
    pass


@InvokeSingleHighestWeightPlugin()
async def getRoleInformation(
    config: object,
    roles: Annotated[
        List[str],
        Doc("List of role identifiers for which to retrieve persona and weight details."),
    ],
) -> Annotated[
    RoleInfoModel,
    Doc("Model mapping each role to its persona name and numerical weight."),
]:
    """
    Invoke the highest-weight IAM plugin to resolve persona and weight for roles.

    :param config: Global configuration object.
    :param roles: Roles assigned to the user.
    :returns: RoleInfoModel where each role maps to:
        - `persona`: descriptive persona string
        - `weight`: numeric priority or weight
    """
    pass

@InvokeSingleHighestWeightPlugin()
async def registerUsers(
    config: object,
    org_id: str,
    users_file: bytes | None,
    relationship_file: bytes | None,
    roles_file: bytes | None,
    personas_file: bytes | None,
    content_type: str | None,
) -> str:
    """
    Fetches the relationship (parents and children) for a given user from the IAM system.

    Args:
        config (object): Global config object.
        users_file (bytes | None): CSV file content for user data.
        roles_file (bytes | None): CSV file containing roles mapping to persmisions information.
        relationship_file (bytes | None): CSV file content for relationships.
        content_type (str): Expected content type for the file (must be 'text/csv').


    Returns:
        str: A message indicating the result of the operation (e.g., number of users updated or relationships added).
    """
    pass


@InvokeSingleHighestWeightPlugin()
async def getRelationshipInfoforUser(
    config: object, user_id: str | Any
) -> IAMUserMetadata:
    """
    Fetches the relationship (parents and children) for a given user from the IAM system.

    Args:
        config (object): Global config object.
        user_id (str | Any): Unique identifier of the user whose relationships are requested.

    Returns:
        dict: A dictionary containing the 'parents' and 'children' of the specified user.
    """
    pass


@InvokeSingleHighestWeightPlugin()
async def deleteUsers(config: object, users_list: List[str] | None) -> IAMUserMetadata:
    """
    Fetches the relationship (parents and children) for a given user from the IAM system.

    Args:
        config (object): Global config object.
        users_list (List[str]): List of user IDs to be deleted.

    Returns:
        str: A message indicating the result of the operation (e.g., number of users deleted).
    """
    pass
