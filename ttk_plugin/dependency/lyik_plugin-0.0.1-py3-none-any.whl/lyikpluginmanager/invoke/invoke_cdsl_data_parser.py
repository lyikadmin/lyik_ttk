from typing import List

from ._invokers import InvokeSingleHighestWeightPlugin
from ..models import GenericFormRecordModel, CDSLDematPayloadModel


PAYLOAD_LIST = CDSLDematPayloadModel


@InvokeSingleHighestWeightPlugin()
async def parse_data_to_cdsl_payload(
    config: object,
    form_record: GenericFormRecordModel,
) -> PAYLOAD_LIST:
    """
    This function is to get the payload(s) for creating a demat account in CDSL.
    Args:
        form_record: form record data.
    """
    pass
