from ._invokers import InvokeSingleHighestWeightPlugin
from ..models import PANStatusModel


@InvokeSingleHighestWeightPlugin()
async def get_pan_status(config: object, pan: str) -> PANStatusModel:
    """This function is to translate payload into cvl kra record"""
    pass
