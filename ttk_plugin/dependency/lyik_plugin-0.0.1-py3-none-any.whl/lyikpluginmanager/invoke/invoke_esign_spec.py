from ._invokers import InvokeSingleHighestWeightPlugin
from ..models import EsignStatusResponseModel, InitiateEsigningResponseModel, EsignResponseModel, EsignTransactionMeta, GenericFormRecordModel,SetupEsigningResponseModel

@InvokeSingleHighestWeightPlugin()
async def setup_esigning(
        self,
        config: object,
        form_id:str,
        org_id:str,
        form_name:str,
        record_id: int,
        form_record:GenericFormRecordModel,
    ) -> SetupEsigningResponseModel:
    """
    This function is to setup the esigning requirements.

     Args:
        - org_id: org id of the form record
        - form_id: form id of the form record
        - form_name: form name
        - record_id: record id of the form record
        - form_record: filled form record

    Return:
        - Response having status, message and esigning url if status is success.
    """
    pass

@InvokeSingleHighestWeightPlugin()
async def get_transaction(
        self,
        config: object,
        txnid: str,
    ) -> EsignTransactionMeta:
    '''
    Provides the transaction metadata corresponding to a txnid

    Args:
        txnid (str): transaction id for the esigning operation
    Returns
        the esign transaction meta data corresponsing to a txdid
    '''
    pass

@InvokeSingleHighestWeightPlugin()
async def get_esign_status(config:object, txnid:str)->EsignStatusResponseModel:
    """
    Fetches and returns the esign information corresponding to a txdid
    """
    pass

@InvokeSingleHighestWeightPlugin()
async def intiate_protean_esigning(config:object, txnid:str,signerid:str)->InitiateEsigningResponseModel:
    """
    Does the prerequisites for protean esining process
    """
    pass

@InvokeSingleHighestWeightPlugin()
async def esign(config:object, protean_response_xml:str)->EsignResponseModel:
    """
    Does the final step in protean esigning process and generates esigned pdf.
    """
    pass
