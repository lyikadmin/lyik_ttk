from ._invokers import InvokeOperation
from ..models import OperationResponseModel, GenericFormRecordModel
from typing import Dict, Any


@InvokeOperation()
async def process_operation(
    config: object,
    operation_plugin: str,
    form_id: str,
    org_id: str,
    form_name: str,
    record_id: int,
    status: str,
    form_record: GenericFormRecordModel,
    params: dict | None,
) -> OperationResponseModel:
    """
    Spec for process operation.
    Args:
        - org_id: org id of the form record
        - form_id: form id of the form record
        - form_name: form name
        - record_id: record id of the form record
        - status: state of the form like SAVE, SUBMIT, etc.
        - form_record: filled form record
        - params: additional parameters require for the operation
    """
    pass
