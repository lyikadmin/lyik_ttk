from ._invokers import InvokePipeline
from ..models import GenericFormRecordModel
from typing import Annotated
from typing_extensions import Doc


@InvokePipeline()
async def pre_save_processor_pipeline(
    config: object,
    token: Annotated[str, Doc("The auth JWT encoded token")],
    payload: Annotated[dict, Doc("The entire form record")],
) -> Annotated[GenericFormRecordModel, Doc("The processed form record")]:
    """
    Single function for all the pre-save processor pipeline implementations

    Args:
        config (object): Global config object.
        token (str): JWT encoded token
        payload (dict): form record data

    Returns:
        GenericFormRecordModel: updated form record data
    """
    pass


@InvokePipeline()
async def form_definition_processor_pipeline(
    config: object,
    token: Annotated[str, Doc("The auth JWT encoded token.")],
    bform: Annotated[dict, Doc("The entire business form.")],
) -> Annotated[GenericFormRecordModel, Doc("The processed business form")]:
    pass


@InvokePipeline()
async def pre_action_processor(
    config: object,
    token: Annotated[str, Doc("The auth JWT encoded token.")],
    action: Annotated[str, Doc("Action eg: 'save', 'submit'")],
    current_state: Annotated[str | None, Doc("State eg: 'SUBMIT', 'APPROVED'")],
    new_state: Annotated[str | None, Doc("State eg: 'SUBMIT', 'APPROVED'")],
    payload: Annotated[GenericFormRecordModel, Doc("The entire form record")],
) -> Annotated[GenericFormRecordModel, Doc("The processed form record")]:
    pass


@InvokePipeline()
async def post_action_processor(
    config: object,
    token: Annotated[str, Doc("The auth JWT encoded token.")],
    action: Annotated[str, Doc("Action eg: 'save', 'submit'")],
    previous_state: Annotated[str | None, Doc("State eg: 'SUBMIT', 'APPROVED'")],
    current_state: Annotated[str, Doc("State eg: 'SUBMIT', 'APPROVED'")],
    payload: Annotated[GenericFormRecordModel, Doc("The entire form record")],
) -> Annotated[GenericFormRecordModel, Doc("The processed form record")]:
    pass
