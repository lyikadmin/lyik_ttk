from ._invokers import InvokeSingleHighestWeightPlugin
from ..models import GenericFormRecordModel, GenerateAllDocsResponseModel
import io
from typing import List, Dict, Any


@InvokeSingleHighestWeightPlugin()
async def generate_main_doc(
    config: object,
    org_id: str,
    form_id: str,
    form_name: str,
    record: GenericFormRecordModel,
    record_id: int | None,
    pdf_name: str | None,
) -> io.BytesIO:
    """
    This function will generate and return a pdf for a given form record.
    Args:
        org_id: organization id of the record,
        form_id: form id of the record,
        form_name: form name
        record: form record for which the pdf need to be generated.
        record_id: record id of the form record saved in db.
        pdf_name: name to be assigned to generated pdf.

    Returns:
        pdf file buffer
    """


@InvokeSingleHighestWeightPlugin()
async def generate_all_docs(
    config: object,
    org_id: str,
    form_id: str,
    form_name: str,
    form_record: GenericFormRecordModel,
    record_id: int,
) -> GenerateAllDocsResponseModel:
    """
    This function will generate and return a pdf for a given form record.
    Args:
        org_id: organization id of the record,
        form_id: form id of the record,
        form_name: form name
        form_ecord: form record for which the pdf(s) need to be generated and stored.
        record_id: record id of the form record saved in db.

    Returns:
        GenerateAllDocsResponseModel: status and link to download generated docs.
    """

@InvokeSingleHighestWeightPlugin()
async def generate_doc(
    config: object,
    org_id: str,
    form_id: str,
    form_name: str,
    form_record: GenericFormRecordModel,
    record_id: int,
    params: dict | None
) -> GenerateAllDocsResponseModel:
    """
    This generates the pdf(s) using Transerformer plugin, and then stores in db.
    Args:
        org_id: organization id of the record,
        form_id: form id of the record,
        form_name: form name
        form_ecord: form record for which the pdf(s) need to be generated and stored.
        record_id: record id of the form record saved in db.
        params: additional parameters required for the operation.
    Returns:
        GenerateAllDocsResponseModel: status and link to download generated docs.
    """
