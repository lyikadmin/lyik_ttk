from ._invokers import InvokeSingleHighestWeightPlugin
from ..models import GenericFormRecordModel, OperationsListResponseModel


@InvokeSingleHighestWeightPlugin()
async def get_operations_list(
    config: object,
    token: str,
    form_record: GenericFormRecordModel,
) -> OperationsListResponseModel:
    """
    This function is to get the list of operations available for the current user.
    Args:
        config (object): Global config object.
        token (str): JWT encoded token.
        form_record (GenericFormRecordModel): The form record for which the operations list is required.

    Returns:
        OperationsListResponseModel: The list of operations available for the current form as per user role.
    """
    pass
