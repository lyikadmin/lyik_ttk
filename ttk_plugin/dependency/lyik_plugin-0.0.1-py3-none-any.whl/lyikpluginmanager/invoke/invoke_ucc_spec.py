from ._invokers import InvokeSingleHighestWeightPlugin
from ..models import GenericFormRecordModel, UCCResponseModel
import io


@InvokeSingleHighestWeightPlugin()
async def upload_ucc(
    config: object,
    form_record: GenericFormRecordModel,
) -> UCCResponseModel:
    """
    Used to register a client information in the UCI/UCC system.
    Args:
        record: form record data.
    """
    pass
