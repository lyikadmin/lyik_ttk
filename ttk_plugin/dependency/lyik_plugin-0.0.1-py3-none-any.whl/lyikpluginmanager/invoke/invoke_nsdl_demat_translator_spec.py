from ._invokers import InvokeSingleHighestWeightPlugin
from ..models import OperationResponseModel, GenericFormRecordModel, NSDLRquestModel


@InvokeSingleHighestWeightPlugin()
async def translate_to_nsdl_demat(
    config: object, form_id:str, org_id:str, form_record: GenericFormRecordModel
) -> NSDLRquestModel:
    """This function is to translate form record into NSDLRequestModel"""
    pass