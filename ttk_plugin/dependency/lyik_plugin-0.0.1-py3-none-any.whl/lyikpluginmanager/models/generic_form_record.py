from pydantic import BaseModel, ConfigDict

class GenericFormRecordModel(BaseModel):
    """
    A generic form record model to work with form data.
    """    
    model_config = ConfigDict(extra="allow")
