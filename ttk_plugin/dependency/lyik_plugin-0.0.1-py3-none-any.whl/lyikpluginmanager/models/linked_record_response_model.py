from pydantic import BaseModel, ConfigDict
from typing import List
import datetime


class LinkedRecordResponseModel(BaseModel):
    form_name: str
    form_uri: str
    record_id: str
    created_on: str | datetime.datetime
    last_updated: str | datetime.datetime
    status: str | None
    _owner: List[str]

    model_config = ConfigDict(
        extra="allow",
    )
