from pydantic import BaseModel
from enum import Enum

class GenerateAllDocsStatus(Enum):
    SUCCESS = 'success'
    FAILED = 'failed'

class GenerateAllDocsResponseModel(BaseModel):
    status: GenerateAllDocsStatus
    message: str
    zip_docs_link: str | None


