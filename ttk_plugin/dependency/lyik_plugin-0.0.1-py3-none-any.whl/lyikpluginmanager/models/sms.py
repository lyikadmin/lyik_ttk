from pydantic import ConfigDict, BaseModel, Field


class SmsModel(BaseModel):
    """
    Represents the model used for sending sms
    """

    phone_number: str = Field(
        ..., title="Phone Number", description="Phone number to send the sms to"
    )
    message: str = Field(
        ..., title="SMS Message", description="Message to be sent in the sms"
    )
    model_config = ConfigDict(extra="forbid")

    def __init__(self, phone_number: str, message: str):
        super().__init__(phone_number=phone_number, message=message)
