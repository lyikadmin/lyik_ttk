from pydantic import BaseModel, Field
from typing import Dict, Any, List, Optional
from enum import Enum


class TRUSTED_RESPONSE_STATUS(str, Enum):
    SUCCESS = "success"
    FAILURE = "failure"


class TrustedResponseModel(BaseModel):
    status: TRUSTED_RESPONSE_STATUS = Field(
        ...,
        description="This is the status of the Trusted API as returned by the trusted plugin",
    )
    message: Optional[str] = Field(
        None,
        description="This is the message of the Trusted API as returned by the trusted plugin",
    )
    response: Dict[str, Any] = Field(
        default={},
        description="The response which is a dictonary and also can be empty",
    )
    attachments: List[Dict[str, Any]] = Field(
        default=[], description="Attachment will be here and also can be empty"
    )
