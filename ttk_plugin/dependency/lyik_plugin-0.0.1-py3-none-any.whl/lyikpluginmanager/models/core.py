from pydantic import ConfigDict, BaseModel, Field
from typing import Dict, Any, List
from ..core.configproxy import ConfigProxy


class ContextModel(BaseModel):
    config: object | None = Field(
        None, description="The config with variables which the plugin has access to."
    )
    token: str | None = Field(None, description="Token using which the API was called")
    org_id: str | None = Field(
        None, description="The organization id from which the plugin is called"
    )
    form_id: str | None = Field(
        None, description="The form id for which the plugin is called."
    )
    form_name: str | None = Field(None, description="The name of form.")

    field_definition: Dict[str, Any] | None = Field(
        None, description="Field Definition as dictionary"
    )
    dbFormDict: Dict[str, Any] = Field(
        None, description="dbForm as a dictionary"
    )
    model_config = ConfigDict(extra="allow")

class DataTransformModel(BaseModel):
    """
    Represents the model used for the data transformation functions
    such as transform_in and transform_out
    """

    record: dict = Field(
        ...,
        title="Record",
        description="This is the record that has to be transformed",
    )
    lyik_form: dict = Field(
        ...,
        title="LYIK Form Definition",
        description="This is the entire form's meta data as described in the DB. This is meta data as represented by dbForm model",
    )


class AuthModel(BaseModel):
    """
    Represents the model used for the data transformation functions
    such as transform_in and transform_out
    """

    record: dict = Field(
        ...,
        title="Record",
        description="This is the record that has to be transformed",
    )
    lyik_form: dict = Field(
        ...,
        title="LYIK Form Definition",
        description="This is the entire form's meta data as described in the DB. This is meta data as represented by dbForm model",
    )


class AuthorizationRequestModel(BaseModel):
    auth_code: str = Field(
        ..., description="Authorization code for verifying an auth request"
    )
    contact_id: str = Field(
        ..., description="The id requesting the token, can be a phone or email."
    )

class PreAuthorizedInfoModel(BaseModel):
    user_id: str = Field(
        ..., description="The user id for which the token is created"
    )
    roles: List[str] = Field(
        ..., description="List of roles assigned to the user"
    )
    governed_users: List[str] = Field(
        ..., description="List of governed users associated with the user"
    )
    user_name: str | None = Field(
        ..., description="The name of the user"
    )
    expiry: int | None = Field(
        ..., description="The expiry time of the token"
    )
    plugin_provider: str | None = Field(
        ..., description="The name of the plugin other than LYIK"
    )
    token: str | None = Field(
        ..., description="The token given from the plugin provider"
    )

class RoleInfoModel(BaseModel):
    weight: int | None = Field(
        ..., description="Weight of the role"
    )
    persona: List[str] | None = Field(
        ..., description="Persona of the role"
    )