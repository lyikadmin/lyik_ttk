from pydantic import ConfigDict, BaseModel, Field
from typing import List

from enum import Enum

class EsignState(str, Enum):
    PENDING = "pending"
    INPROGRESS = "inprogress"
    DONE = "done"
    FAILED = "failed"

class EsignStatus(BaseModel):
    """
    Contains the esign status related data for one signature.
    - If status is failed then err_code and err_msg will be present.
    - If status is done or failed then last_signed_time will be present.
    """
    status: EsignState = Field(..., description="Flag for detecting state of esign")
    err_code: str | None = Field(None, description="Error code if any")
    err_msg: str | None = Field(None, description="Error message if any")
    last_activity: str | None = Field(None, description="timestamp of last activity")

    model_config = ConfigDict(
        extra="allow",  # Allow extra fields
    )

class EsignMeta(BaseModel):
    """
    Contains the esign stamp related data for one signature.
    """
    page_no: str = Field(..., description="pdf page number where esign will be placed")
    xy: tuple = Field(..., description="coords of pdf page where esign stamp")
    hw: tuple = Field(..., description="height and width of esign stamp")
    location : str=  Field(..., description="location of Esigner")
    name: str = Field(..., description="Esigner Name to be placed on esign stamp")
    reason_for_esign:str = Field(..., description="Reason to be shown on esign stamp")
    id: str | None = Field(None, description="Esigner identifier") 
    signature: str | None = Field(None, description="Base64 of signature by which pdf is signed")
    sign_status: EsignStatus | None = Field(None, description="Status of esign")

class Esign(BaseModel):
    """
    Contains esign related data
    """
    esign_meta: List[EsignMeta] = Field(...)
    
    # signed_pdf: DocumentModel | None = Field(None)
    # last_signed_time: str | None = Field(None, description="timestamp of (last) signature")
    
    model_config = ConfigDict(
        extra="allow",  # Allow extra fields
    )

class DocMeta(BaseModel):
    """
    Contains the pdf related data
    """
    org_id: str | None = Field(None, description='The organization to which it belongs to')
    form_id: str | None = Field(None) 
    record_id: int | None = Field(None) 
    doc_type: str | None = Field(None, description="This is the File type")
    digest: str | None = Field(None)
    esign: Esign | None = Field(None)
    model_config = ConfigDict(
        extra="allow",  # Allow extra fields
    )




