from pydantic import BaseModel, Field


class GenerateEmailData(BaseModel):
    key_name: str = Field(..., description="Key for additional_args in transformer")
    email_body: str = Field(..., description="Value to be substituted in the template")


class GenerateEmailParams(BaseModel):
    generate_email_data: GenerateEmailData
