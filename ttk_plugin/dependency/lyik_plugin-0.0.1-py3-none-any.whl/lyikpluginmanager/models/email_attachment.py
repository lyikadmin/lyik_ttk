from pydantic import BaseModel, Field


class EmailAttachment(BaseModel):
    attachment_name: str = Field(..., description="The name of the attachment file")
    attachment_type: str = Field(..., description="MIME type of the attachment")
    attachment_content: bytes = Field(..., description="Attachment content in bytes")
