from pydantic import BaseModel, Field
from typing import Dict, Any, List
from enum import Enum


class OperationStatus(str, Enum):
    SUCCESS = "SUCCESS"
    FAILED = "FAILED"
    IN_PROGRESS = "IN-PROGRESS"


class OperationResponseModel(BaseModel):
    status: OperationStatus = Field(
        ...,
        description="The status of the operation"
    )
    message: str = Field(
        ...,
        description="A message describing the response"
    )
