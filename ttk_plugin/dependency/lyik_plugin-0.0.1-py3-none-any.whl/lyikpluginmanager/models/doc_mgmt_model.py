from pydantic import BaseModel, Field, ConfigDict
from .doc_meta import DocMeta


class DocumentModel(BaseModel):
    doc_id: str | None = Field(
        None,
        description="This is the file id whic can be a refrence for the stored doc. \n When adding file this id will contain the refrenced doc id \n When deleting a file this id must be passed",
    )
    doc_name: str = Field(..., description="This is the File name")
    doc_type: str = Field(..., description="This is the File type")
    doc_size: int = Field(..., description="This is the File size in bytes")
    doc_content: bytes | None = Field(
        None,
        description="This is the File content in bytes, only when file is fetched or updated",
    )

class DocQueryGenericModel(BaseModel):
    """
    A model for querying docs based on metadata of doc for doc mgmt plugin.
    """    
    # Todo: make org_id, form_id and record_id mandatory!
    org_id: str | None = Field(None, description='The organization to which it belongs to')
    form_id: str | None = Field(None)
    record_id: int | None = Field(None) 
    model_config = ConfigDict(extra="allow")

class DBDocumentModel(BaseModel):
    doc_id: str | None = Field(
        None,
        description="file id stored in db",
    )
    doc_name: str = Field(..., description="This is the File name")
    doc_size: int = Field(..., description="This is the File size in bytes")
    doc_content: bytes | None = Field(
        None,
        description="This is the File content in bytes, only when file is fetched or updated",
    )
    metadata: DocMeta = Field(
        ...,
        description="This field stores the content-type and other additional metadata for the file"
    )
