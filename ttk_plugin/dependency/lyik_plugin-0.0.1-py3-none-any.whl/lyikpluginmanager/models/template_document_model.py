from pydantic import BaseModel, Field, ConfigDict
from .doc_meta import DocMeta


class TemplateDocumentModel(BaseModel):
    doc_name: str = Field(..., description="This is the File name")
    doc_type: str = Field(..., description="This is the File type")
    doc_content: bytes = Field(
        ...,
        description="This is the File content in bytes, only when file is fetched or updated",
    )
    metadata: DocMeta | None = Field(
        None,
        description="metadata for the file",
    )