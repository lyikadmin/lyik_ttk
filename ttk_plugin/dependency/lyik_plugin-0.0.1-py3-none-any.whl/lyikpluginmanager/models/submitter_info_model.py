from pydantic import BaseModel, Field
from datetime import datetime


class SubmitterModel(BaseModel):
    """
    Data model for a form submitter
    """

    id: str = Field(
        ...,
        description="This is the ID of the submitter as recognized by the a&a system. This is usually fetched from the token. For example user_id in the LyikToken.",
    )
    phone: str | None = Field(None, description="Phone number of the submitter")
    email: str | None = Field(None, description="Email id of the submitter")
    time: datetime = Field(
        ..., description="Date time at which the submission was made"
    )
