from pydantic import BaseModel, Field, ConfigDict
from typing import Any
from enum import Enum


class TRANSFORMER_RESPONSE_STATUS(str, Enum):
    SUCCESS = "success"
    FAILURE = "failure"


class TransformerResponseModel(BaseModel):
    """
    A generic transformer response model.
    """

    status: TRANSFORMER_RESPONSE_STATUS = Field(
        ...,
        description="This is the status of the Transformer as returned by the Transformer plugin",
    )
    message: str | None = Field(
        None,
        description="This is the message of the Transformer as returned by the Transformer plugin",
    )
    response: Any = Field(
        None,
        description="The response which is a dictonary and also can be empty",
    )
    model_config = ConfigDict(extra="allow")
