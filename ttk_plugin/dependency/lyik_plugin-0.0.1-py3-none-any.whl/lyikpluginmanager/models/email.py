from pydantic import ConfigDict, BaseModel, Field
from typing import Optional, List
from .email_attachment import EmailAttachment


class EmailModel(BaseModel):
    """
    Represents the model used for sending emails
    """

    from_email: Optional[str] | None = Field(
        None, title="From Email", description="Email address to send the email from"
    )
    subject: str = Field(..., title="Email Subject", description="Subject of the email")
    email_address: str = Field(
        ..., title="Email Address", description="Email address to send the email to"
    )
    message: str = Field(
        ..., title="Email Message", description="Message to be sent in the email"
    )
    attachments: Optional[List[EmailAttachment]] | None = Field(
        None, title="Attachments", description="List of attachments"
    )
    model_config = ConfigDict(extra="forbid")

    def __init__(
        self,
        subject: str,
        email_address: str,
        message: str,
        attachments: Optional[List[EmailAttachment]] = None,
        from_email: Optional[str] = None,
    ):
        super().__init__(
            subject=subject,
            email_address=email_address,
            message=message,
            attachments=attachments,
            from_email=from_email,
        )
