from typing import List, Optional
from pydantic import BaseModel, Field
from enum import Enum

class EsignTransactionMeta(BaseModel):
    """
    Holds the required metadata for a esign transaction.
    """

    txnid: str
    org_id: str
    form_id: str
    record_id: int

class ESignerMeta(BaseModel):
    name: str
    identifier: str = Field(..., alias="_identifier")
    sign_status: bool
    message: str | None = Field(None)

class EsignStatusResponseModel(BaseModel):
    """
    Example:
    {
        "signers": [
            {
                "name": "Ashok K",
                "identifier": "abcd1234",
                "sign_status": True,
                "message": "Success Message"
            }
        ],
        "docs_zip_url": "https://api.lyik.com/v1/forms/pdf/abcd1234.pdf"
    }
    """
    signers: List[ESignerMeta]
    docs_zip_url: str


class InitiateEsignStatus(str, Enum):
    success = "success"
    error = "error"

class InitiateEsigningResponseModel(BaseModel):
    '''
    Example:
     {
        "status": "success",
        "message": "Esigning process has been initiated for ...",
        "payload": "<payload_xml>",
        "action_url": "https://api.example.com/v1/endpoint"
    }
    '''
    status: InitiateEsignStatus
    message: str
    payload: str | None = Field(None)  # Optional field
    action_url: str | None = Field(None)  # Optional field

class EsignResponseModel(BaseModel):
    status: str = Field(...)
    txnid:str | None = Field(None) # optional field
    message: str = Field(...)


class SetupEsigningStatus(Enum):
    INITIATED = 'initiated'
    INPROGRESS = 'inprogress'
    FAILED = 'failed'
    COMPLETED = 'completed'
class SetupEsigningResponseModel(BaseModel):
    status: SetupEsigningStatus = Field(...)
    message: str = Field(...)
    esign_url: str | None = Field(None)