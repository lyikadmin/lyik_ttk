from pydantic import model_validator, BaseModel, Field, ConfigDict
from enum import Enum
from typing import Dict, Any


class VERIFY_RESPONSE_STATUS(str, Enum):
    SUCCESS = "success"
    FAILURE = "failure"
    INDETERMINATE = "indeterminate"


class VerifyHandlerResponseModel(BaseModel):
    status: VERIFY_RESPONSE_STATUS = Field(
        ...,
        description="This is the status of the verification as returned by the verify_handler",
    )
    message: str | None = Field(
        None,
        description="A message that will be displayed on the checker panel and will be relevant when the status is Failure",
    )
    id: str | None = Field(
        None,
        description="An identifier that will help the verify handler identify the status of verification",
    )
    actor: str | None = Field(
        None, description="To identify the actor which has done the verification"
    )
    user_id: str | None = Field(
        None, description="To identify the user who has initiated verification"
    )
    weight: int | None = Field(
        None,
        description="To identify the weight of the user who has initiated verification",
    )
    response: Dict[str, Any] | None= Field(
        None,
        description="The response which may contain additional data for autofilling in the UI.",
    )
    model_config = ConfigDict(extra="allow")


class SingleFieldModel(BaseModel):
    payload: Dict[str, Any] = Field(
        ..., description="Root payload containing exactly one key-value pair"
    )

    @model_validator(mode="before")
    @classmethod
    def check_single_key(cls, values):
        payload = values.get("payload", {})
        if len(payload) != 1:
            raise ValueError("Payload must contain exactly one key-value pair.")
        return values

    @property
    def field_name(self) -> str:
        return next(iter(self.payload))

    @property
    def field_value(self) -> Any:
        return next(iter(self.payload.values()))
