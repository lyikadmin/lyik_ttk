from pydantic import BaseModel, Field, ConfigDict
from typing import List, Any, Dict, Optional

USER_ID = str
ORG_ID = str

class IAMUserInfo(BaseModel):
    user_id: str | None = Field(None)
    phone_number: str | None = Field(None)
    email: str | None = Field(None)
    model_config = ConfigDict(extra="allow")


class IAMUserRelationshipInfo(BaseModel):
    parents: List[USER_ID] = []
    children: List[USER_ID] = []


class IAMUserMetadata(BaseModel):
    user_info: IAMUserInfo | None = Field(None)
    user_relationship_info: IAMUserRelationshipInfo | None = Field(None)
    owner_of: List[ORG_ID] | None = Field(None)
    permissions: Dict | None = Field(None)

class IAMUserIdentifiers(BaseModel):
    user_id: str | None = Field(None)
    phone_number: str | None = Field(None)
    email: str | None = Field(None)


class ProviderInfo(BaseModel):
    provider_name: str = Field(
        ...,
        description="The name of the provider",
    )
    token: str = Field(
        ...,
        description="The token given by the provider",
    )