from pydantic import BaseModel, Field, ConfigDict
from typing import Dict, Any
from enum import Enum


class BANK_ACCOUNT_VERIFICATION_STATUS(str, Enum):
    SUCCESS = "success"
    FAILURE = "failure"


class BankAccountVerifierResponseModel(BaseModel):
    status: BANK_ACCOUNT_VERIFICATION_STATUS = Field(
        ...,
        description="This is the status of the verification as returned by the verifier",
    )
    message: str | None = Field(None, description="Response message")
    account_number: str | None = Field(None, description="Account number of the user")
    customer_name: str | None = Field(None, description="Name of the account holder")
    customer_email: str | None = Field(
        None, description="Email ID of the account holder"
    )
    customer_mobile: str | None = Field(
        None, description="Mobile number of the account holder"
    )
    bank_tnx_id: str | None = Field(None, description="Bank transaction id")
