from typing import Optional, Any
from pydantic import BaseModel
from enum import Enum

class ResponseStatusEnum(str, Enum):
    success = "success"
    failure = "failure"

class StandardResponse(BaseModel):
    status: ResponseStatusEnum
    message: str
    result: Optional[Any] = None

class ServicesEnum(str, Enum):
    SignatureExtraction = "signature_extraction"
    LivenessCheck = "liveness"
    FaceDetection = "detect_face"
    OCR = "ocr"