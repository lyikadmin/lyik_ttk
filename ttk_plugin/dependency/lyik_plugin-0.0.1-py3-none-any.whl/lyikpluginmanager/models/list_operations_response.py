from pydantic import BaseModel, ConfigDict
from typing import List, Dict


class Operation(BaseModel):
    op_id: str
    op_name: str
    display_text: str
    params: dict | None = None


class OperationsListResponseModel(BaseModel):
    operations: List[Operation]
