from enum import Enum

class DPType(str,Enum):
    CH = "CH" #Clearing House/Clearing Corporation
    CM = "CM" #Clearing Member
    DP = "DP" #Regular/Depository Participant
    RT = "RT" #Registered Transfer Agent
    DE = "DE" #Depository
    CU = "CU" #Custodian
    SE = "SE" #Stock Exchange
    DF = "DF" #Default

class BOTransactionType(str,Enum):
    BOSET = 'BOSET' # Creation
    BOMOD = 'BOMOD' # Modification
    BOCLS = 'BOCLS' # Closure Setup
    CBOCL = 'CBOCL' # Cancel BO Closure
    CAPDP = 'CAPDP' # Closure Approved By DP
    DFT = 'DFT' # Default

class ProductNumber(str,Enum):
    IND = 'IND' #	INDIVIDUAL / Resident
    COR = 'COR' #	CORPORATE / Body Corporate
    NRI = 'NRI' #	NON RESIDENT INDIVIDUAL / NRI
    IFI = 'IFI' #	INDIAN FINANCIAL INSTITUTION / FI
    FII = 'IFI' #	FOREIGN INSTITUTIONAL INVESTOR / FII
    MF = 'MF' #	MUTUAL FUNDS
    BNK = 'BNK' #	BANK
    HUF = 'HUF' #	HUF
    CM = 'CM' #	CM-POOL ( CORPORATE ) / CM
    CME = 'CME' #	SETTLEMENT LIEN ACCOUNT (CM ESCROW)
    VBP = 'VBP' #	CM VYAJ BADLA POOL
    CHP = 'CHP' #	SETTLEMENT DEFAULT ACCOUNT (CH POOL)
    CHE = 'CHE' #	SETTLEMENT ESCROW ACCOUNT (CH ESCROW)
    ODN = 'ODN' #	OTHER DEPOSITORY NOSTRO ACCOUNT
    FN = 'FN' #	FOREIGN NATIONAL
    NCM = 'NCM' #	NSCCL CLEARING MEMBER ACCOUNT
    CHA = 'CHA' #	CH/CC HOUSE ACCOUNT
    ACM = 'ACM' #	AHMEDABAD CLEARING MEMBER ACCOUNT
    TRS = 'TRS' #	TRUST
    CCM = 'CCM' #	CSE CLEARING MEMBER ACCOUNT
    DCM = 'DCM' #	DSE CLEARING MEMBER ACCOUNT
    NAA = 'NAA' #	NSCCL ALBM ACCOUNT
    OCM = 'OCM' #	OTCEI CLEARING MEMBER ACCOUNT
    EPA = 'EPA' #	EARLY PAY-IN ACCOUNT
    MTA = 'MTA' #	MARGIN TRADING ACCOUNT (MANTRA)
    CMT = 'CMT' #	CORPORATE MARGIN TRADING A/C (MANTRA)
    NCCM = 'NCCM' #	NCDEX CLEARING MEMBER POOL ACCOUNT
    ICOM = 'ICOM' #	INDIVIDUAL-COMMODITY ACCOUNT
    CCOM = 'CCOM' #	CORPORATE-COMMODITY ACCOUNT
    BCOM = 'BCOM' #	BANK-COMMODITY ACCOUNT
    MCCM = 'MCCM' #	MCX CLEARING MEMBER ACCOUNT
    NSCM = 'NSCM' #	CLEARING MEMBER ACCOUNT - NSE-SLB
    IPOA = 'IPOA' #	INDIVIDUAL POA
    CPOA = 'CPOA' #	CORPORATE POA
    NLCM = 'NLCM' #	NSEL CLEARING MEMBER POOL ACCOUNT
    MSCM = 'MSCM' #	MCX-SX CLEARING MEMBER ACCOUNT
    RSCM = 'RSCM' #	RSX CLEARING MEMBER ACCOUNT
    ACCM = 'ACCM' #	ACE CLEARING MEMBER ACCOUNT
    CF = 'CF' #	CORPORATE FOREIGN
    NRIC = 'NRIC' #	NON RESIDENT INDIVIDUAL COMMODITY A/C
    QFIC = 'QFIC' #	QUALIFIED FOREIGN INVESTOR - CORPORATE
    QFII = 'QFII' #	QUALIFIED FOREIGN INVESTOR - INDIVIDUAL
    UCM = 'UCM' #	UCX CLEARING MEMBER ACCOUNT
    FPII = 'FPII' #	FOREIGN PORTFOLIO INVESTOR - INDIVIDUAL
    FPIC = 'FPIC' #	FOREIGN PORTFOLIO INVESTOR - CORPORATE
    CCLCM = 'CCLCM' #	CCIL Clearing Member Account
    CUSPA = 'CUSPA' #	CLIENT UNPAID SECURITIES ACCOUNT
    PMSPA = 'PMSPA' #	PMS Pool Account
    MCICM = 'MCICM' #	MCCIL CLEARING MEMBER ACCOUNT - ICEX
    ARCMP = 'ARCMP' #	ARCL CM Principal Account
    ARCPO = 'ARCPO' #	ARCL CM POOL ACCOUNT
    AIF = 'AIF' #	Alternate Investment Fund
    IEPF = 'IEPF' #	IEPF
    QIB = 'QIB' #	QIB
    STKBI = 'STKBI' #	Stock Broker (Individual)
    STKBC = 'STKBC' #	Stock Broker (Corporate)
    PCM = 'PCM' #	PCM
    DFT = 'DFT' #	Default

class BeneficiarySubType(str, Enum):
    ASSRC = 'ASSRC'  # Asset Reconstruction Companies
    ASSCS = 'ASSCS'  # Associate companies / Subsidiaries
    ASSPR = 'ASSPR'  # Association of Persons (AOP)
    BNKDR = 'BNKDR'  # Bank-Depositary Receipt
    BNKPR = 'BNKPR'  # Banks Promoter / Others-Promoter
    BDFII = 'BDFII'  # Bilateral Development Financial Institution
    CATGI = 'CATGI'  # Category I
    CATVI = 'CATVI'  # Category I -  VRR
    CATDI = 'CATDI'  # Category I -DR
    CATII = 'CATII'  # Category II
    CAVII = 'CAVII'  # Category II - DR
    CAIIV = 'CAIIV'  # Category II - VRR
    CAIIR = 'CAIIR'  # Category II -  VRR
    CAIID = 'CAIID'  # Category II -DR
    CAIII = 'CAIII'  # Category III
    CIIID = 'CIIID'  # Category III -DR
    CSGPR = 'CSGPR'  # Central / State Government -Promoter
    CGPROM = 'CGPROM'  # Central Government - Promoter
    CGPOI = 'CGPOI'  # Central Government / President of India
    CLHOS = 'CLHOS'  # Clearing House
    CSMFA = 'CSMFA'  # Client securities Margin Funding Account / TM-Client Securities under Margin Funding Account
    CMCNF = 'CMCNF'  # Corporate CM Client Nodal MFOS / CM - Client Nodal MFOS Account
    CCSMP = 'CCSMP'  # CM Client Sec Margin Pledge / Corporate CM Client Sec Margin Pledge
    CMCUS = 'CMCUS'  # CM CUSPA / Corporate CM CUSPA
    COOBK = 'COOBK'  # Co-operative Bank / Bank - Co-operative
    COBPR = 'COBPR'  # Co-operative Bank  - Promoter
    COBDP = 'COBDP'  # Co-operative Body - Promoter
    COOSB = 'COOSB'  # Co-Operative Scheduled Bank
    CORPT = 'CORPT'  # Corporate
    CBDPM = 'CBDPM'  # Corporate Body - Domestic - PMS
    CBFVC = 'CBFVC'  # Corporate Body - Foreign Venture Capital
    CBDER = 'CBDER'  # Corporate Body-Depositary Receipt
    CBDOD = 'CBDOD'  # Corporate Body-Domestic / Domestic
    CBFRB = 'CBFRB'  # Corporate Body-Foreign Bodies
    CBFBP = 'CBFBP'  # Corporate Body-Foreign body-Promoter
    CBGCO = 'CBGCO'  # Corporate Body-Govt Company
    CORBO = 'CORBO'  # Corporate Body-OCB
    CBOCB = 'CBOCB'  # Corporate Body-OCB-Depositary Receipt
    CBPRO = 'CBPRO'  # Corporate Body-Promoter
    CBSTG = 'CBSTG'  # Corporate Body-State Govt
    CORMT = 'CORMT'  # Corporate-Margin Trading Account
    COSBO = 'COSBO'  # Cos/Bodies Corp-Centrl/Stat Gov Promter
    CUMBD = 'CUMBD'  # Cum bond
    CUAIF = 'CUAIF'  # Custodian Alternate Investment Fund
    CUSBN = 'CUSBN'  # Custodian Bank
    CUSBF = 'CUSBF'  # Custodian Bank Foreign
    CUSBT = 'CUSBT'  # Custodian Bank Others
    CUSCM = 'CUSCM'  # Custodian Clearing Member
    CUSCB = 'CUSCB'  # Custodian Client  Bank
    CUSCC = 'CUSCC'  # Custodian Client  Corporate
    CCFBC = 'CCFBC'  # Custodian Client  Foreign Body Corporate
    CCIRN = 'CCIRN'  # Custodian Clnt  Ind Resi No Nomination
    CCRNO = 'CCRNO'  # Custodian Clnt  Ind Resi with Nomination
    CCBFV = 'CCBFV'  # Custodian Corp Body Foreign Venture Cap
    CCBOD = 'CCBOD'  # Custodian Corporate Body Domestic
    CCNBF = 'CCNBF'  # Custodian Corporate Body NBFC
    CCBOT = 'CCBOT'  # Custodian Corporate Body Others
    CCBFR = 'CCBFR'  # Custodian Corporate Body-Foreign Body
    CFISF = 'CFISF'  # Custodian FI Govt Sponsored FI
    CUFIO = 'CUFIO'  # Custodian FI Others
    CFDER = 'CFDER'  # Custodian FII Depositary Receipt
    CFIIM = 'CFIIM'  # Custodian FII Mauritius-based
    CFIIO = 'CFIIO'  # Custodian FII Others
    CFPI1 = 'CFPI1'  # Custodian FPI-Category I
    CFPII = 'CFPII'  # Custodian FPI-Category II
    CUMFD = 'CUMFD'  # Custodian Mutual Fund
    CNRIP = 'CNRIP'  # Custodian NRI Non Repat PMS No Nominatio
    CNRIR = 'CNRIR'  # Custodian NRI Non Repatriable  PMS
    CNRNN = 'CNRNN'  # Custodian NRI Repat PMS No Nomination
    CNPRE = 'CNPRE'  # Custodian NRI Repatriable - PMS
    CODUD = 'CODUD'  # Custodian Overseas Deposit Underlying DR
    CSCBK = 'CSCBK'  # Custodian Scheduled Commercial Banks
    CUSTR = 'CUSTR'  # Custodian Trusts
    DEBTR = 'DEBTR'  # Debenture Trustee
    DCDER = 'DCDER'  # Domestic Corporate - Depository Receipt
    DCUSH = 'DCUSH'  # Domestic Corporate-Unclaimed shares a/c / Unclaimed Securities- Suspense Escrow account
    DOMDR = 'DOMDR'  # Domestic DR
    DOMPR = 'DOMPR'  # Domestic-Promoter
    DR = 'DR'  # DR
    EBTPR = 'EBTPR'  # Employee Benefit Trusts Promoter
    EMSTO = 'EMSTO'  # Employee Stock Option
    EMSPU = 'EMSPU'  # Employee Stock Purchase
    EMPTR = 'EMPTR'  # Employee Trusts
    ESCAC = 'ESCAC'  # Escrow Account
    ESCBK = 'ESCBK'  # Escrow  Bank / Client collateral account-Escrow
    ESCCO = 'ESCCO'  # Escrow  Corporate
    FNPNN = 'FNPNN'  # Foregn National Promt-Negtiv Nomination
    FORBK = 'FORBK'  # Foreign Bank / Bank - Foreign
    FORBP = 'FORBP'  # Foreign Bank  - Promoter
    FRODR = 'FRODR'  # Foreign Bodies Depository Receipt
    FCQFI = 'FCQFI'  # Foreign Corporate - QFI
    FDINV = 'FDINV'  # Foreign Direct Investment
    FFPIP = 'FFPIP'  # Foreign FPI Promoter
    FORGO = 'FORGO'  # Foreign Government
    FORGP = 'FORGP'  # Foreign Govt Promoter
    FOQFI = 'FOQFI'  # Foreign Individual -QFI
    FORIP = 'FORIP'  # Foreign Institutions -Promoter
    FORNM = 'FORNM'  # Foreign National - Minor
    FORNP = 'FORNP'  # Foreign National - Promoter
    FNNNO = 'FNNNO'  # Foreign National Negative Nomination
    FNDER = 'FNDER'  # Foreign National-Depositary Receipt
    FSCCB = 'FSCCB'  # Foreign Scheduled Comercial Bank
    FPICI = 'FPICI'  # FPI-Category I
    FPCII = 'FPCII'  # FPI-Category II
    FPIII = 'FPIII'  # FPI-Category III
    FUCNV = 'FUCNV'  # Fully Convertible
    GEMBS = 'GEMBS'  # General Employee Benefit Scheme
    GSFIP = 'GSFIP'  # Govt. sponsored FI - Promoter
    GOCPR = 'GOCPR'  # Govt.Companies - Promoter
    GCPRO = 'GCPRO'  # Group Company - Promoter
    HUFPM = 'HUFPM'  # HUF - PMS
    HUFPR = 'HUFPR'  # HUF - Promoter
    ICCNMN = 'ICCNMN'  # Ind CM Clnt Nodal MFOS Negative Nominatn
    ICPAN = 'ICPAN'  # Ind CM/TM Prop Acct Negative Nomination
    IRMNN = 'IRMNN'  # Ind Resident - Minor Negative Nomination
    IRPNN = 'IRPNN'  # Ind Resident-PMS Negative Nomination
    IRMPN = 'IRMPN'  # Ind Residnt-Minor Promt Negtve Nomintion
    ITCNM = 'ITCNM'  # Ind TM Clnt Nodal MFOS Negative Nominatn
    ITCNMN = 'ITCNMN'  # Ind TM/CM Clnt Nodal MFOS Neg Nomination
    INDDR = 'INDDR'  # Independent - Director Relatives / Individual-Directors Relatives
    INDDN = 'INDDN'  # Independent-Dir Relatives Negtiv Nomin
    INDNN = 'INDNN'  # Independent-Director Negative Nominee
    IFIPR = 'IFIPR'  # Indian Financial Institutions  Promoter
    INDIR = 'INDIR'  # Indipendent  - Director
    IDRNN = 'IDRNN'  # Indiv-Directr Relative Negtive Nomnation
    INDVL = 'INDVL'  # Individual
    ICCUN = 'ICCUN'  # Individual CM CUSPA Negative Nomination
    IDNNO = 'IDNNO'  # Individual Director Negative Nomination
    IPNNO = 'IPNNO'  # Individual Promoters Negative Nomination
    INRMP = 'INRMP'  # Individual Resident - Minor -Promoter
    IRPMS = 'IRPMS'  # Individual Resident- PMS
    ITCNN = 'ITCNN'  # Individual TM CUSPA Negative Nomination
    ITCNO = 'ITCNO'  # Individual TM/CM CUSPA Negative Nominatn
    ICPNN = 'ICPNN'  # Individual  CM CMPA No Nominee
    ITCCNN = 'ITCCNN'  # Individual  TM CMPA No Nominee
    ITCPN = 'ITCPN'  # Individual  TM/CM CMPA No Nominee
    INHUF = 'INHUF'  # Individual-HUF / HUF
    INPRO = 'INPRO'  # Individual-Promoters
    INRES = 'INRES'  # Individual-Resident / Ordinary
    INGOT = 'INGOT'  # Insurance Funds - Armed Forces - Govt.of India
    IFDPI = 'IFDPI'  # Insurance Funds - Department of Post India
    KMPE = 'KMPE'  # Key Managerial Personnel
    LLPAR = 'LLPAR'  # Limited Liability Partnership
    LLPFR = 'LLPFR'  # Limited Liability Partnership (Foreign)
    LLPFD = 'LLPFD'  # Limited Liability Partnership (Foreign)-DR
    LLPDR = 'LLPDR'  # Limited Liability Partnership-DR
    LLPPM = 'LLPPM'  # LLP - PMS
    LLCCN = 'LLCCN'  # LLP CM Client Nodal MFOS
    LLCMP = 'LLCMP'  # LLP CM Client Securities Margin Pledge
    LLCUS = 'LLCUS'  # LLP CM CUSPA
    LLPRA = 'LLPRA'  # LLP CM/TM Proprietary Account
    LLTCN = 'LLTCN'  # LLP TM Client Nodal MFOS
    LLTCLM = 'LLTCLM'  # LLP TM Client Securities Margin Pledge
    LLTCU = 'LLTCU'  # LLP TM CUSPA
    LLCNM = 'LLCNM'  # LLP TM/CM Client Nodal MFOS
    LLCUP = 'LLCUP'  # LLP TM/CM CUSPA
    LLTCM = 'LLTCM'  # LLP  TM/CM CMPA
    LOLAU = 'LOLAU'  # Local Authority
    MF = 'MF'  # MF / Mutual Funds
    MDFII = 'MDFII'  # Multilateral Development Financial Institution
    NIFGI = 'NIFGI'  # National Investment Fund - Govt.of India
    NBPRO = 'NBPRO'  # Nationalised Bank  - Promoter
    NBFCP = 'NBFCP'  # NBFC-Promoter
    NOMDR = 'NOMDR'  # Nominee - Director
    NOMDN = 'NOMDN'  # Nominee - Director Relatives
    NODNN = 'NODNN'  # Nominee-Director Negative Nominee
    NDRNN = 'NDRNN'  # Nominee-Director Relatives Negtiv Nomine
    NCDEB = 'NCDEB'  # Non Convertible Debenture
    NBFPR = 'NBFPR'  # Non-NBFC-Promoter
    NORBD = 'NORBD'  # Normal Bond
    NRMNN = 'NRMNN'  # NRI - Repatriable Minor No Nomination
    NNRPM = 'NNRPM'  # NRI Non Repatriable - PMS
    NRNRP = 'NRNRP'  # NRI Non Repatriable - Promoter
    NRNRNN = 'NRNRNN'  # NRI Non Repatriable Negative nomination
    NRRNO = 'NRRNO'  # NRI Non-Repatriable Minor No Nomination
    NRPNN = 'NRPNN'  # NRI Repatr- Promoter  Negtive Nomination
    NRRPM = 'NRRPM'  # NRI Repatriable - PMS
    NRPRO = 'NRPRO'  # NRI Repatriable - Promoter
    NRRNN = 'NRRNN'  # NRI Repatriable Negative Nomination
    NPMNN = 'NPMNN'  # NRI Repatriable PMS Negative Nomination
    NRRHU = 'NRRHU'  # NRI with repatriation - HUF
    NRRMI = 'NRRMI'  # NRI with repatriation - Minor
    NRWRH = 'NRWRH'  # NRI without repatriation - HUF
    NRWMI = 'NRWMI'  # NRI without repatriation - Minor
    NRDRE = 'NRDRE'  # NRI-Depositary Receipt
    NRDNN = 'NRDNN'  # NRI-Depositary Recipt Negtive Nomination
    NNREP = 'NNREP'  # NRI-Non Repatriable
    NNPNO = 'NNPNO'  # NRI-NonRepat-Promoter-NoNominee
    OCBNO = 'OCBNO'  # OCB-NonRepatriable
    OCBRE = 'OCBRE'  # OCB-Repatriable
    OPFCO = 'OPFCO'  # Optionally Fully Convertible
    OTHER = 'OTHER'  # Other
    OEBTR = 'OEBTR'  # Other - Employee Benefit Trust(Old Scheme)
    OTSBK = 'OTSBK'  # Others - Scheduled Bank
    OTPRO = 'OTPRO'  # Others-Promoter
    ODUDR = 'ODUDR'  # Overseas Depository  Underlying DR
    PARCO = 'PARCO'  # Partly Convertible
    PENFC = 'PENFC'  # Pension Fund - Corpus Rs.25 crore & more
    PMSPK = 'PMSPK'  # PMS Service Provider  Bank
    PMSPC = 'PMSPC'  # PMS Service Provider  Corporate
    PROMP = 'PROMP'  # Promoter
    PRIRN = 'PRIRN'  # Promoters - Immdite Relatives No Nominee
    PRIRE = 'PRIRE'  # Promoters - Immediate Relatives
    PROTR = 'PROTR'  # Promoters - Other Relatives
    POIRN = 'POIRN'  # Promter Othr imediat Reltiv No Nominee
    PRPFD = 'PRPFD'  # Providend/Pension Fund
    PFC25 = 'PFC25'  # Provident Fund - Corpus Rs.25 crore & more
    PUFII = 'PUFII'  # Public Financial Institution
    REIDR = 'REIDR'  # Resdnt Ind-Depstry Rept Negtve Nomintion
    RESDR = 'RESDR'  # Resident Individual - Depository Receipt
    RETBS = 'RETBS'  # Retirement Benefit Scheme
    SCHCO = 'SCHCO'  # Scheduled Commercial Bank
    SFCPR = 'SFCPR'  # SFC-Promoter
    SWFDO = 'SWFDO'  # Sovereign Wealth Funds - Domestic
    SWFFO = 'SWFFO'  # Sovereign Wealth Funds - Foreign
    STGPR = 'STGPR'  # State Government - Promoter
    STGGO = 'STGGO'  # State Government / Governor
    STIDC = 'STIDC'  # State Industrial Development Corporation
    STPAR = 'STPAR'  # Stock Appreciation Right
    STBCL = 'STBCL'  # Stock Broker - Client
    SINBF = 'SINBF'  # Systemically Important NBFCs
    TMCNM = 'TMCNM'  # TM Client Nodal MFOS / Individual TM Client Nodal MFOS
    TMCSM = 'TMCSM'  # TM Client Sec Margin Pledge / Individual TMClient Sec Margin Pledge
    TMCUS = 'TMCUS'  # TM CUSPA
    TMPOL = 'TMPOL'  # TM Pool
    TCMPA = 'TCMPA'  # TM/CM CMPA / Individual  TM/CM CMPA
    TMCUP = 'TMCUP'  # TM/CM CUSPA / Individual TM/CM CUSPA
    TRUPM = 'TRUPM'  # Trust - PMS
    TRCOM = 'TRCOM'  # Trusteeship Company
    USSEA = 'USSEA'  # Unclaimed Securities- Suspense Escrow account
    VCFRW = 'VCFRW'  # Venture Capital Fund Registered With SEBI
    SBPR = 'SBPR'  # Stock Broker - Proprietary
    SBCL = 'SBCL'  # Stock Broker - Collateral
    STFCO = 'STFCO'  # SFC
    NRRP = 'NRRP'  # NRI - Repatriable
    GVTC = 'GVTC'  # Govt.Companies
    CEGV = 'CEGV'  # Central Government
    STGV = 'STGV'  # State Government
    COPB = 'COPB'  # Co-operative Body
    NNBFC = 'NNBFC'  # Non-NBFC
    CLMTS = 'CLMTS'  # Client Margin Trading Securities account / Individual-Margin Trading Account
    FORN = 'FORN'  # FN / Foreign National
    CDMDF = 'CDMDF'  # Corporate Debt Market Development Fund
    AGESC = 'AGESC'  # AGGREGATE ESCROW 
    PFICA = 'PFICA'  # Public Financial Inst. Sec.2(72)Companies Act 2013
    IRIRD = 'IRIRD'  # Insurance Company Registered with IRDA
    DFT = 'DFT'  # Default
    CBCG = 'CBCG'  # Corporate Body-Central Govt
    ODA = 'ODA'  # Other Depositary Account
    IHMTA = 'IHMTA'  # Individual-HUF-Margin Trading Account
    RIM = 'RIM'  # Resident Individual - Minor
    INDCO = 'INDCO'  # Individual-Commodity
    CORCO = 'CORCO'  # Corporate-Commodity
    BKCO = 'BKCO'  # Bank-Commodity
    CCTCA = 'CCTCA'  # Corporate CM/TM  Client  Account
    CCTCB = 'CCTCB'  # Corporate CM/TM - Client Beneficiary A/c
    ICTCA = 'ICTCA'  # Individual CM/TM  Client Account
    ICTCB = 'ICTCB'  # Individual CM/TM-Client Beneficiary A/c
    HCTCA = 'HCTCA'  # HUF CM/TM  Client  Account
    HCTCB = 'HCTCB'  # HUF CM/TM - Client Beneficiary A/c
    CBOCBP = 'CBOCBP'  # Corporate Body - OCB - Promoter
    IRNNO = 'IRNNO'  # Individual- Resident Negative Nomination
    LLPCO = 'LLPCO'  # Limited Liability Partnership-Commodity
    ICOMR = 'ICOMR'  # Individual-Commodity-Minor
    ICOHUF = 'ICOHUF'  # Individual-Commodity-HUF
    TRPR = 'TRPR'  # Trust - Promoter
    NNRPNN = 'NNRPNN'  # NRI Non Repatriable PMS Negative Nominat
    LLPP = 'LLPP'  # Limited Liability Partnership - Promoter
    IEPFSA = 'IEPFSA'  # IEPF SUSPENSE ACCOUNT
    CCTPA = 'CCTPA'  # Corporate CM/TM Proprietary Account / Stock Broker - Proprietary
    CCTCLA = 'CCTCLA'  # Corporate CM/TM Collateral Account
    ICTPA = 'ICTPA'  # Individual CM/TM Proprietary Account / Stock Broker - Proprietary
    ICTCLA = 'ICTCLA'  # Individual CM/TM Collateral Account
    HCTPA = 'HCTPA'  # HUF CM/TM Proprietary Account
    HCTCLA = 'HCTCLA'  # HUF CM/TM Collateral Account
    VCF = 'VCF'  # Venture Capital Fund
    AIF = 'AIF'  # Alternate Investment Fund
    INSCO = 'INSCO'  # Insurance Company
    LLCTCA = 'LLCTCA'  # LLP CM/TM Client Account
    LLCTCL = 'LLCTCL'  # LLP CM/TM Collateral Account
    CCCA = 'CCCA'  # Corporate Client Collateral Account / Client collateral account
    ICCA = 'ICCA'  # Individual Client Collateral Account
    HUFCCA = 'HUFCCA'  # HUF Client Collateral Account
    LLPCCA = 'LLPCCA'  # LLP Client Collateral Account
    TMCUSA = 'TMCUSA'  # TM CUSA
    ICCNN = 'ICCNN'  # Individual Client Collateral-NoNominee
    CTCSMP = 'CTCSMP'  # Corporate TM Client Sec Margin Pledge
    HTCSMP = 'HTCSMP'  # HUF TM Client Securities Margin Pledge
    ICCSMP = 'ICCSMP'  # Individual CM Client Sec Margin Pledge
    HCCSMP = 'HCCSMP'  # HUF CM Client Securities Margin Pledge
    CTCCMP = 'CTCCMP'  # Corporate  TM/CM CMPA
    HTCCMP = 'HTCCMP'  # HUF  TM/CM CMPA
    CCB = 'CCB'  # Custodian Client  Bank
    CCACC = 'CCACC'  # Clnt Collateral Acct Custodian Corporate
    CCACB = 'CCACB'  # Clnt Collateral Acct Custodian Bank /Client collateral account-Custodian
    PMSPB = 'PMSPB'  # PMS Service Provider  Bank
    IFIP = 'IFIP'  # Indian Financial Institutions  Promoter
    ITCUSP = 'ITCUSP'  # Individual TM CUSPA
    CTCUSP = 'CTCUSP'  # Corporate TM CUSPA
    ICCUSP = 'ICCUSP'  # Individual CM CUSPA
    HTCUSP = 'HTCUSP'  # HUF TM CUSPA
    HCCUSP = 'HCCUSP'  # HUF CM CUSPA
    CTCCUS = 'CTCCUS'  # Corporate TM/CM CUSPA
    HTCCUS = 'HTCCUS'  # HUF TM/CM CUSPA
    CTCNMF = 'CTCNMF'  # Corporate TM Client Nodal MFOS / TM - Client Nodal MFOS Account
    ICCNMF = 'ICCNMF'  # Individual CM Client Nodal MFOS / CM - Client Nodal MFOS Account
    HTCNMF = 'HTCNMF'  # HUF TM Client Nodal MFOS
    HCCNMF = 'HCCNMF'  # HUF CM Client Nodal MFOS
    ITCCNM = 'ITCCNM'  # Individual TM/CM Client Nodal MFOS / TM/CM - Client Nodal MFOS Account
    CTCCNM = 'CTCCNM'  # Corporate TM/CM Client Nodal MFOS / TM/CM- Client Unpaid Securities Pledgee Account
    HTCCNM = 'HTCCNM'  # HUF TM/CM Client Nodal MFOS
    INDLIR = 'INDLIR'  # Individual Director
    INDIRR = 'INDIRR'  # Independent - Director Relatives
    AGEAIF = 'AGEAIF'  # Aggregate Escrow - AIF
    NBFCRB = 'NBFCRB'  # NBFCs registered with RBI
    TPPGT = 'TPPGT'  # Trust Promter&Promoter Grp trustee
    GSFI = 'GSFI'  # FI-Government Sponsered FI
    FISFC = 'FISFC'  # FI-SFC
    FIOTH = 'FIOTH'  # FI-Others
    FIIMB = 'FIIMB'  # FII-Mauritius Based
    FIIOTH = 'FIIOTH'  # FII-Others
    NRIRPT = 'NRIRPT'  # NRI-Repatriable
    CBCOB = 'CBCOB'  # Corporate Body-Co Operative Bank
    CBNBFC = 'CBNBFC'  # Corporate Body-NBFC
    CBNNBF = 'CBNNBF'  # Corporate Body-Non NBFC
    CBBRKR = 'CBBRKR'  # Corporate Body-Broker
    CBGC = 'CBGC'  # Corporate Body-Group Company / Group Company
    CBOTH = 'CBOTH'  # Corporate Body-Others / Others
    CM = 'CM'  # Clearing Member
    TRST = 'TRST'  # Trusts
    BN = 'BN'  # Bank-Nationalized / Nationalised Bank
    BOTH = 'BOTH'  # Bank-Others / Others
    FIIDR = 'FIIDR'  # FII-Depositary Receipt
    CFPICI = 'CFPICI'  # FPI-Category I
    FPICII = 'FPICII'  # FPI-Category II
    FPICIII = 'FPICIII'  # FPI-Category III
    IRPMNN = 'IRPMNN'  # Ind Resident PMS Negative Nomination
    CHRINS = 'CHRINS'  # Charitable Institutions
    UNVRST = 'UNVRST'  # University
    OPRO = 'OPRO'  # Others-Promoter
    SBCOL = 'SBCOL'  # Stock Broker - Collateral
    CCACU = 'CCACU'  # Client collateral account-Custodian
    DOR = 'DOR'  # DR
    MUTF = 'MUTF'  # MF
    OTR = 'OTR'  # Other
    DORE = 'DORE'  # DR
    CAVRR = 'CAVRR'  # Category I -  VRR
    CAONE = 'CAONE'  # Category I
    CATWO = 'CATWO'  # Category II
    CATHR = 'CATHR'  # Category III
    CMCMP = 'CMCMP'  # CM-Client Securities Margin Pledge Account
    TMCMP = 'TMCMP'  # TM-Client Securities Margin Pledge Account
    TCCMP = 'TCCMP'  # TM/CM-Client Securities Margin Pledge Account
    TCSMF = 'TCSMF'  # TM-Client Securities under Margin Funding Account
    TCLSP = 'TCLSP'  # TM- Client Unpaid Securities Pledgee Account
    CUSPL = 'CUSPL'  # CM - Client Unpaid Securities Pledgee Account
    TCUPL = 'TCUPL'  # TM/CM - Client Unpaid Securities Pledgee Account
    ORHUF = 'ORHUF'  # HUF - Discontinued
    ORSTB = 'ORSTB'  # Stock Broker - Client - Discontinued
    OHUFP = 'OHUFP'  # HUF-Promoter - Discontinued
    ORCCA = 'ORCCA'  # Client collateral account - Discontinued
    COBRK = 'COBRK'  # Broker - Discontinued
    COSTB = 'COSTB'  # Stock Broker - Client - Discontinued
    FPCTT = 'FPCTT'  # Category III - Discontinued
    FPIDR = 'FPIDR'  # Category III -DR - Discontinued
    FPCTH = 'FPCTH'  # Category III - Discontinued
    FPCDR = 'FPCDR'  # Category III -DR - Discontinued

class Purpose(str, Enum):
    FH = 'FH'  # First Holder
    SH = 'SH'  # Second Holder
    TH = 'TH'  # Third Holder
    NM = 'NM'  # Nominee
    GD = 'GD'  # Guardian
    NMG = 'NMG'  # Nominee's Guardian
    AS = 'AS'  # Authorized Signatory
    KR = 'KR'  # Karta
    CP = 'CP'  # Coparcenar
    PMS = 'PMS'  # PMS Manager
    MPCM = 'MPCM'  # Mapping of CM Accounts With CM POA / PMS POA / DDPI Master
    BOUCC = 'BOUCC'  # BO–UCC Linking / Delinking Details
    POALB = 'POALB'  # POA Linking with BO
    IPOA = 'IPOA'  # Individual POA/DDPI
    CPOA = 'CPOA'  # Corporate POA/DDPI
    PSIGT = 'PSIGT'  # POA/DDPI signatory
    PTCM = 'PTCM'  # POA / DDPI target client mapping
    SMCU = 'SMCU'  # Signatory Member creation Upload
    CSCU = 'CSCU'  # Corporate Signatory Creation upload 
    ASMC = 'ASMC'  # Auth Signatory Mapping with Client
    POAC = 'POAC'  # POA/DDPI - Signatory Mapping with CPOA
    SGNDT = 'SGNDT'  # Signature Details
    DFT = 'DFT'  # Default

class Gender(str, Enum):
    MALE = 'MALE'  # Male
    FMALE = 'FMALE'  # Female
    TRGEN = 'TRGEN'  # Transgender
    DFT = 'DFT'  # Default

class PANVerificationFlag(str, Enum):
    PANNV = 'PANNV'  # PAN Not Verified (Not Allowed for DP)
    PANV = 'PANV'  # PAN Verified (For Other Than Individuals)
    PANVR = 'PANVR'  # PAN Verification Reversed (Updated by Depository)
    PANVAL = 'PANVAL'  # PAN Verified and Aadhar Linked / PAN verified and seeded with Adhaar (Updated By Depository)
    EXMPT = 'EXMPT'  # PAN Exempted
    PANATC = 'PANATC'  # PAN Verified,Aadhar link to be checked
    PANVLD = 'PANVLD'  # PAN-Aadhar Verified and Linked-Confirmed By DP
    AEXMPT = 'AEXMPT'  # Aadhar Exempted Cases /PAN verified and seeding with Adhaar is not required
    PANVNS = 'PANVNS'  # PAN verified and not seeded with Adhaar
    DFT = 'DFT'  # Default
    YES = 'YES'  # Yes
    NO = 'NO'  # No

class PANExemptedCode(str, Enum):
    CONDP = 'CONDP'  # Consolidation of DP
    CUSTDN = 'CUSTDN'  # Custodian
    ERRTXR = 'ERRTXR'  # Erroneous Transfer
    GOVRNR = 'GOVRNR'  # Governor
    HLDRDC = 'HLDRDC'  # Holder Deceased
    COMMDT = 'COMMDT'  # Commodity
    NRI = 'NRI'  # Non Resident Indian (NRI)
    PIO = 'PIO'  # Person of Indian Origin (PIO)
    PRSDNT = 'PRSDNT'  # President of India
    SIKKIM = 'SIKKIM'  # Sikkim Resident
    CM = 'CM'  # Clearing Members
    UNMA = 'UNMA'  # UN entities / Multilateral Agencies
    DFT = 'DFT'  # Default

class AadhaarAuthenticationWithUIDFlag(str, Enum):
    ADRNV = 'ADRNV'  # Aadhar Not Verified
    ADRV = 'ADRV'  # Aadhar Verified / Aadhar Verified by DP
    DFT = 'DFT'  # Default

class ReasonForNonUpdatedAadhaar(str, Enum):
    ADRAPL = 'ADRAPL'  # Proof of application of enrollment for Aadhaar is submitted
    AEXMPT = 'AEXMPT'  # Aadhar Exempted
    NONRSD = 'NONRSD'  # Non Resident
    SNCDCS = 'SNCDCS'  # Since Deceased
    POAOIC = 'POAOIC'  # POA for Operating only Individual Client
    DFT = 'DFT'  # Default
    ROJK = 'ROJK'  # Resident of Jammu & Kashmir
    DDPOIC = 'DDPOIC'  # DDPI for operating only individual client

class SMSFacility(str, Enum):
    YES = 'YES'  # SMART REGISTRATION / SMS FACILITY
    NO = 'NO'  # NO SMART REGISTRATION / NO SMS FACILITY
    DFT = 'DFT'  # Default

class FamilyFlagForMobile(str,Enum):
    YES = 'YES'	# Family Mobile Number
    NO = 'NO'	# Not Family mobile Number
    DFT = 'DFT'	# Default

class FamilyFlagForEmail(str,Enum):
    YES = 'YES'	# Family Email
    NO = 'NO'	# Not Family email
    DFT = 'DFT'	# Default

class NoNominationFlag(str, Enum):
    YES = 'YES'  # Not Opted / Opted Out
    NO = 'NO'  # Nomination Opted
    OON = 'OON'  # Opted Out of Nomination
    DFT = 'DFT'  # Default

class ModeOfOperation(str, Enum):
    SLHLD = 'SLHLD'  # SOLE HOLDER
    JTHLDR = 'JTHLDR'  # JOINTLY (ALL HOLDER)
    ANOSUR = 'ANOSUR'  # ANY ONE OR SURVIVORS
    DFT = 'DFT'  # Default

class StandingInstructionIndicator(str, Enum):
    YES = 'YES'  # Purchase Confirmation Waived
    NO = 'NO'  # Purchase Confirmation Not Waived
    DFT = 'DFT'  # Default

class GrossAnnualIncomeRange(str, Enum):
    UPT1L = 'UPT1L'  # Upto Rs.1 lakhs
    _1LT5L = '1LT5L'  # 1,00,001 To 5,00,000
    _5LTXL = '5LTXL'  # 5,00,001 To 10,00,000
    XLTXXV = 'XLTXXV'  # 10,00,001 To 25,00,000
    GT24L = 'GT24L'  # MORE THAN 25,00,000 (Only For Individuals)
    _25T1CR = '25T1CR'  # 25,000,01 to 1,00,000,00 (Only For Corporates)
    GT1CR = 'GT1CR'  # More than 1,00,000,00 (Only For Corporates)
    BL2L = 'BL2L'  # Below 20 Lac
    _2T5L = '2T5L'  # 20-50 lac
    _5T1CR = '5T1CR'  # 50-100 lac
    DFT = 'DFT'  # Default

class OneTimeDeclarationFlagForGSECIDT(str, Enum):
    PHY = 'Physical OR'
    ELE = 'Electronic (Easi Easiest) OR'
    ONLAO = 'Online A/c Opening through DP portal'
    YES = 'Yes'
    NO = 'No'
    DFT = 'Default'

class ECSMandate(str, Enum):
    Yes = 'Yes'  # Yes
    No = 'No'  # No
    DFT = 'DFT'  # Default

class EducationDegree(str, Enum):
    HS = 'HS'  # High School
    GD = 'GD'  # Graduate
    PG = 'PG'  # Post Graduate
    DCT = 'DCT'  # Doctorate
    PD = 'PD'  # Professional Degree
    UHS = 'UHS'  # Under High School
    ILLT = 'ILLT'  # Illiterate
    OTHR = 'OTHR'  # Others
    DFT = 'DFT'  # Default

class AnnualReportFlag(str, Enum):
    YES = 'YES'  # Yes
    NO = 'NO'  # No
    PHY = 'PHY'  # Physical
    ELC = 'ELC'  # Electronic
    BPE = 'BPE'  # Both Physical and Electronic
    DFT = 'DFT'  # Default

# todo: Make it dict?
class BOStatementCycleCode(str, Enum):
    _2M = '2M'  # Twice Monthly # TODO: Need to confirm this!
    DA = 'DA'  # Daily
    EM = 'EM'  # End of Month
    EW = 'EW'  # End of Week
    YY = 'YY'  # No Statements
    DF = 'DF'  # Default

class ElectronicConfitmation(str, Enum):
    YES = 'YES'  # YES
    NO = 'NO'  # NO
    DFT = 'DFT'  # Default

class EmailRTADDwonloadFlag(str, Enum):
    YES = 'YES'  # Email to be shared with RTA
    NO = 'NO'  # Email not to be shared with RTA
    DFT = 'DFT'  # Default

class GeoCode(str, Enum):
    METRO = 'METRO'  # Metropolitan
    OTHR = 'OTHR'  # Others
    RURAL = 'RURAL'  # Rural
    SEURB = 'SEURB'  # Semi Urban
    URBAN = 'URBAN'  # Urban
    DFT = 'DFT'  # Default

class Exchange(str, Enum):
    BSE = 'BSE'  # BOMBAY STOCK EXCHANGE LIMITED
    NSE = 'NSE'  # NATIONAL STOCK EXCHANGE OF INDIA LIMITED
    OTC = 'OTC'  # OTC EXCHANGE OF INDIA
    NCD = 'NCD'  # NATIONAL COMMODITY & DERIVATIVES EXCHANGE LIMITED
    MCX = 'MCX'  # MULTI COMMODITY EXCHANGE OF INDIA LIMITED
    NSL = 'NSL'  # NATIONAL STOCK EXCHANGE OF INDIA LIMITED - SLB
    ICS = 'ICS'  # INTER-CONNECTED STOCK EXCHANGE OF INDIA LIMITED
    MSE = 'MSE'  # METROPOLITAN STOCK EXCHANGE OF INDIA LIMITED
    BSC = 'BSC'  # BOMBAY STOCK EXCHANGE LIMITED
    RBI = 'RBI'  # RESERVE BANK OF INDIA
    ICX = 'ICX'  # INDIAN COMMODITY EXCHANGE LIMITED (ICEX)
    CSE = 'CSE'  # THE CALCUTTA STOCK EXCHANGE ASSOCIATION LIMITED
    DSE = 'DSE'  # THE DELHI STOCK EXCHANGE ASSOCIATION LIMITED
    ASE = 'ASE'  # THE STOCK EXCHANGE AHMEDABAD
    BSS = 'BSS'  # BOMBAY STOCK EXCHANGE LIMITED - SLB
    NSP = 'NSP'  # NATIONAL SPOT EXCHANGE LTD
    ACE = 'ACE'  # ACE DERIVATIVES AND COMMODITIES EXCHANGE LIMITED
    UCX = 'UCX'  # UNIVERSAL COMMODITY EXCHANGE LIMITED
    DSP = 'DSP'  # DUMMY SETTLEMENT POCKET1
    CA = 'CA'  # CORPORATE ACTION
    DFT = 'DFT'  # Default
    LSE = 'LSE'  # LUDHIANA STOCK EXCHANGE
    BGE = 'BGE'  # BANGALORE STOCK EXCHANGE
    MDE = 'MDE'  # MADRAS STOCK EXCHANGE
    CCI = 'CCI'  # THE CLEARING CORPORATION OF INDIA LIMITED

class MentalDisablity(str, Enum):
    YES = 'YES'  # YES
    NO = 'NO'  # NO
    DFT = 'DFT'  # Default

class Nationality(str, Enum):
    IN = 'IN'  # INDIA
    USA = 'USA'  # UNITED STATES OF AMERICA
    GB = 'GB'  # UNITED KINGDOM
    MEN = 'MEN'  # MIDDLE EAST NATIONS
    JP = 'JP'  # JAPAN
    FR = 'FR'  # FRANCE
    DE = 'DE'  # GERMANY
    # Todo: There are more in Doc to be added!

class CASMode(str, Enum):
    NO = 'NO'  #  CAS NOT REQUIRED
    PH = 'PH'  #  PHYSICAL CAS REQUIRED
    DF = 'DF'  # Default

class AutoPledgeIndicator(str, Enum):
    YES = 'YES'  # YES
    NO = 'NO'  # NO
    DFT = 'DFT'  # Default

class BankAccountType(str, Enum):
    SVG = 'SVG'  # Saving
    CUR = 'CUR'  # Current
    CCR = 'CCR'  # Cash Credit / Overdraft
    DFT = 'DFT'  # Default

class BOCategory(str, Enum):
    NHB = 'NHB'  # Regular BO / Non House Beneficiary
    CMP = 'CMP'  # CM Principal
    CME = 'CME'  # CM Escrow
    CHP = 'CHP'  # CH Pool
    CHE = 'CHE'  # CH Escrow
    CUS = 'CUS'  # Client Unpaid Securities
    CML = 'CML'  # CM VB/CM Lend
    CMO = 'CMO'  # CM Pool
    NOS = 'NOS'  # Nostro
    CM = 'CM'  # Clearing member / CM
    POA = 'POA'  # POA
    PMS = 'PMS'  # PMS Pool
    HOS = 'HOS'  # House
    INT = 'INT'  # Intermediary
    INS = 'INS'  # Internal Suspense
    CON = 'CON'  # Control
    CUP = 'CUP'  # Custodian Principal
    CUE = 'CUE'  # Custodian Escrow
    ODE = 'ODE'  # Other DP Escrow
    CPR = 'CPR'  # CH Principal
    DFT = 'DFT'  # Default

class BeneficiaryTaxDeductionStatus(str, Enum):
    EXM = 'EXM'  # EXEMPT
    RI = 'RI'  # RESIDENT INDIVIDUAL
    NRIWR = 'NRIWR'  # NRI WITH REPATRIATION
    NRWTR = 'NRWTR'  # NRI WITHOUT REPATRIATION
    DC = 'DC'  # DOMESTIC COMPANIES
    OCB = 'OCB'  # OVERSEAS CORPORATE BODIES
    FC = 'FC'  # FOREIGN COMPANIES
    MF = 'MF'  # MUTUAL FUNDS
    DTT = 'DTT'  # DOUBLE TAXATION TREATY
    OTH = 'OTH'  # OTHERS
    TR = 'TR'  # TRUST
    DFT = 'DFT'  # Default

class CHId(str, Enum):
    ICCL = 'ICCL'  # Indian Clearing Corporation Limited
    NCL = 'NCL'  # NSE Clearing Limited
    NCLSLB = 'NCLSLB'  # NSE Clearing Limited - SLB
    OTCEI = 'OTCEI'  # NATIONAL SECURITIES CLEARING CORP LTD-OTCEI
    NCCL = 'NCCL'  # NATIONAL COMMODITY  CLEARING LIMITED (NCCL)
    MCXCCL = 'MCXCCL'  # MULTI COMMODITY EXCHANGE CLEARING CORPORATION LIMITED (MCXCCL)
    MCCL = 'MCCL'  # METROPOLITAN CLEARING CORPORATION OF INDIA LIMITED
    CSECH = 'CSECH'  # CALCUTTA STOCK EXCHANGE- CLEARING HOUSE
    DSECH = 'DSECH'  # DELHI STOCK EXCHANGE LIMITED - CLEARING HOUSE
    ASECH = 'ASECH'  # AHMEDABAD STOCK EXCHANGE CLEARING HOUSE
    BSLSLB = 'BSLSLB'  # BOI SHAREHOLDING LIMITED - SLB
    NSEL = 'NSEL'  # NATIONAL SPOT EXCHANGE LIMITED
    ICSEL = 'ICSEL'  # INTER-CONNECTED STOCK EXCHANGE OF INDIA LIMITED
    ICL = 'ICL'  # INDIAN CLEARING CORPORATION LIMITED - Debt
    ADCEL = 'ADCEL'  # ACE DERIVATIVES AND COMMODITIES EXCHANGE LIMITED
    UCEL = 'UCEL'  # UNIVERSAL COMMODITY EXCHANGE LIMITED
    CCIL = 'CCIL'  # THE CLEARING CORPORATION OF INDIA LTD.
    MCL = 'MCL'  # METROPOLITAN CLEARING CORPORATION OF INDIA LIMITED - ICX
    DFT = 'DFT'  # Default
    BSL = 'BSL'  # BOI SHAREHOLDING LIMITED
    NCDL = 'NCDL'  # NATIONAL COMMODITY AND DERIVATIVES EXCH. LTD.
    LASE = 'LASE'  # LUDHIANA STOCK EXCHANGE
    BASE = 'BASE'  # BANGALORE STOCK EXCHANGE
    MDSE = 'MDSE'  # MADRAS STOCK EXCHANGE
    MCEL = 'MCEL'  # MULTI COMMODITY EXCHANGE OF INDIA LIMITED
    ARCL = 'ARCL'  # AMC REPO CLEARING LIMITED
    CA = 'CA'  # Corporate Action

class BSDAFlag(str, Enum):
    BSDA = 'BSDA'  # BSDA
    NBSD = 'NBSD'  # NON BSDA
    OPTO = 'OPTO'  # Opted Out
    DFT = 'DFT'  # Default

class Occupation(str, Enum):
    BUS = 'BUS'  # BUSINESS
    FAR = 'FAR'  # FARMER/Agriculture
    GOV = 'GOV'  # GOVERNMENT SERVICES
    HOU = 'HOU'  # HOUSEWIFE
    OTH = 'OTH'  # OTHERS
    PRO = 'PRO'  # PROFESSIONAL
    PUS = 'PUS'  # PUBLIC SECTOR
    PRS = 'PRS'  # PRIVATE SECTOR
    RET = 'RET'  # RETIRED
    SER = 'SER'  # SERVICE
    STU = 'STU'  # STUDENT
    LAN = 'LAN'  # LANDLORD
    DFT = 'DFT'  # Default

class PMSClientAccountFlag(str, Enum):
    YES = 'YES'  # YES
    NO = 'NO'  # NO
    DFT = 'DFT'  # Default

class PositiveConfimation(str, Enum):
    YES = 'YES'  # YES
    NO = 'NO'  # NO
    DFT = 'DFT'  # Default

class EmailStatementFlag(str, Enum):
    ELE = 'ELE'  # ELECTRONIC STATEMENT
    PHY = 'PHY'  # PHYSICAL STATEMENT
    DFT = 'DFT'  # Default

class CommunicationPreference(str, Enum):
    FIH = 'FIH'  # First Holder
    ALH = 'ALH'  # All Holders
    DFT = 'DFT'  # Default

class DeletionFlag(str, Enum):
    DFH = 'DFH'  # First Holder
    DSH = 'DSH'  # Second Holder
    DTH = 'DTH'  # Third Holder
    DFT = 'DFT'  # Default

class ReasonCodeForDeletion(str, Enum):
    DOM = 'DOM'  # Death of 1 or More Holder
    DFT = 'DFT'  # Default

class AccountOpeningSource(str, Enum):
    OLAO = 'OLAO'  # Online Account opening by the BO
    AOBSP = 'AOBSP'  # Account Opening based on submission of Physical form
    DFT = 'DFT'  # Default

class POAOrDDPIType(str, Enum):
    DDPI = 'DDPI'  # DDPI / DDPI Holder
    CPOA = 'CPOA'  # Corporate POA
    CMPOA = 'CMPOA'  # Clearing Member POA
    PMSPA = 'PMSPA'  # PMS POA
    POA = 'POA'  # POA Holder / Regular POA
    POAS = 'POAS'  # POA Signatory
    DDPIS = 'DDPIS'  # DDPI Signatory
    DFT = 'DFT'  # Default

class DematGateway(str, Enum):
    YES = 'YES'  # YES
    NO = 'NO'  # NO
    DFT = 'DFT'  # Default

class NomineeMinorIndicator(str, Enum):
    FNM = 'FNM'  # If 1st Nominee is minor
    SNM = 'SNM'  # If 2nd Nominee is minor
    TNM = 'TNM'  # If 3rd Nominee is minor
    FSM = 'FSM'  # if 1st and 2nd Nominees are minor
    FTM = 'FTM'  # if 1st and 3rd Nominees are minor
    STM = 'STM'  # if 2nd and 3rd Nominees are minor
    ANM = 'ANM'  # if all Nominees are minor
    DFT = 'DFT'  # Default

class FlagForSharePercentageEquality(str, Enum):
    YES = 'YES'  # YES
    NO = 'NO'  # NO
    DFT = 'DFT'  # Default

class ResidualSecuritiesFlag(str, Enum):
    YES = 'YES'  # YES
    NO = 'NO'  # NO
    DFT = 'DFT'  # Default

class RelationshipWithBOorKarta(str, Enum):
    SPO = 'SPO'  # Spouse
    SON = 'SON'  # Son
    DAU = 'DAU'  # Daughter
    FAT = 'FAT'  # Father
    MOT = 'MOT'  # Mother
    BRO = 'BRO'  # Brother
    SIS = 'SIS'  # Sister
    GSN = 'GSN'  # Grand-Son
    GDU = 'GDU'  # Grand-Daughter
    GRF = 'GRF'  # Grand-Father
    GRM = 'GRM'  # Grand-Mother
    OTH = 'OTH'  # Others
    NOP = 'NOP'  # Not provided
    MIL = 'MIL'  # Mother In Law
    FIL = 'FIL'  # Father In Law
    BIL = 'BIL'  # Brother In Law
    SIL = 'SIL'  # Sister In Law
    SNL = 'SNL'  # Son In Law
    DIL = 'DIL'  # Daughter In Law
    DFT = 'DFT'  # Default


class PoaToOperateAccount(str, Enum):
    YES = 'YES'  # YES
    NO = 'NO'  # NO
    DFT = 'DFT'  # Default

class GPABPAFlag(str, Enum):
    BKS = 'BKS'  # Bank Specific
    GNP = 'GNP'  # General purpose
    SET = 'SET'  # Settlement
    MRP = 'MRP'  # Margin Pledge
    MUF = 'MUF'  # Mutual Fund
    TEO = 'TEO'  # Tender Offer
    STB = 'STB'  # Stock Broker
    CUS = 'CUS'  # Custodian
    PMS = 'PMS'  # PMS
    NFC = 'NFC'  # NBFC
    DFT = 'DFT'  # Default

class POALinkPurposeCode(str, Enum):
    FRH = 'FRH'  # First Holder
    SRH = 'SRH'  # Second Holder
    TRH = 'TRH'  # Third Holder
    ARH = 'ARH'  # All Holders
    DFT = 'DFT'  # Default

class BOUCCLinkFlag(str, Enum):
    ADD = 'ADD'  # ADD
    DEL = 'DEL'  # DELETE
    DFT = 'DFT'  # Default

class ConsentFlag(str, Enum):
    BOUCC = 'BOUCC'  # BO - UCC Linking will be done only for the BOID setup in this upload file
    PANUCC = 'PANUCC'  # BO - UCC Linking will be done for all BO accounts with same 1st Holder PAN
    DFT = 'DFT'  # Default

class Segment(str, Enum):
    CM = 'CM'  # Cash segment
    FO = 'FO'  # Equity Derivatives Segment
    CD = 'CD'  # Currency Derivative Segment
    DT = 'DT'  # Debt Segment
    CO = 'CO'  # Commodity Derivatives Segment
    SB = 'SB'  # SLB Segment
    AL = 'AL'  # ALL Segments
    EG = 'EG'  # EGR
    FP = 'FP'  # Futures and Options Physical
    OF = 'OF'  # OFS
    AC = 'AC'  # Auction Cash, SLB, FO
    SM = 'SM'  # SME
    DF = 'DF'  # Default

class MappingUnmappingFlag(str, Enum):
    MAP = 'MAP'  # MAPPING
    UNM = 'UNM'  # UNMAPPING
    DFT = 'DFT'  # Default

class PurposeCode(str, Enum):
    CORAD = 'CORAD'  # CORR. ADDRESS/Local Address
    PERAD = 'PERAD'  # PERMANT ADDRESS
    BBADD = 'BBADD'  # Bank Branch Address
    NOMAD = 'NOMAD'  # Nominee/Guardian Address
    FORAD = 'FORAD'  # Foreign/Correspondence Address
    CUSAD = 'CUSAD'  # Custodian Address
    MNGAD = 'MNGAD'  # MinorNomineeGuardianAddress
    SENAD = 'SENAD'  # SecondNomineeAddress
    SMNGA = 'SMNGA'  # SecondMinorNomineeGuardianAddress
    THNAD = 'THNAD'  # ThirdNomineeAddress
    TMNGA = 'TMNGA'  # ThirdMinorNomineeGuardianAddress
    DFT = 'DFT'  # Default

class AddressPrefFlag(str, Enum):
    LOC = 'LOC'  # Local Address
    COR = 'COR'  # correspondence Address
    FOR = 'FOR'  # Foreign Address
    DFT = 'DFT'  # Default

class AddressCountryCode(str, Enum):
    IN = 'INDIA'
    USA = 'UNITED STATES OF AMERICA'
    GB = 'UNITED KINGDOM'
    MEN = 'MIDDLE EAST NATIONS'
    JP = 'JAPAN'
    FR = 'FRANCE'
    DE = 'GERMANY'
    SG = 'SINGAPORE'
    CA = 'CANADA'
    OT = 'OTHERS'
    AF = 'AFGHANISTAN'
    AL = 'ALBANIA'
    DZ = 'ALGERIA'
    AD = 'ANDORRA'
    AO = 'ANGOLA'
    AB = 'ANTIGUA BARBUDA'
    AR = 'ARGENTINA'
    AM = 'ARMENIA'
    AU = 'AUSTRALIA'
    AT = 'AUSTRIA'
    AZ = 'AZERBAIJAN'
    BS = 'BAHAMAS'
    BHR = 'BAHRAIN'
    BD = 'BANGLADESH'
    BB = 'BARBADOS'
    BY = 'BELARUS'
    BE = 'BELGIUM'
    BZ = 'BELIZE'
    BJ = 'BENIN'
    BT = 'BHUTAN'
    BO = 'BOLIVIA'
    BH = 'BOSNIA HERZEGOVINA'
    BW = 'BOTSWANA'
    BR = 'BRAZIL'
    BRU = 'BRUNEI'
    BG = 'BULGARIA'
    BF = 'BURKINA FASO'
    BI = 'BURUNDI'
    KH = 'CAMBODIA'
    CM = 'CAMEROON'
    CV = 'CAPE VERDE'
    CF = 'CENTRAL AFRICAN REPUBLIC'
    TD = 'CHAD'
    CL = 'CHILE'
    CN = 'CHINA'
    CO = 'COLOMBIA'
    KM = 'COMOROS'
    DRC = 'DEMOCRATIC REPUBLIC CONGO'
    RC = 'REPUBLIC OF CONGO'
    CR = 'COSTA RICA'
    CDI = 'COTE D IVOIRE'
    CT = 'CROTIA'
    CU = 'CUBA'
    CY = 'CYRUS'
    TC = 'TURKISH CYPRUS'
    CZR = 'CZECH RUPUBLIC'
    DK = 'DENMARK'
    DJ = 'DJIBOUTI'
    DM = 'DOMINICA'
    DO = 'DOMINICAN REPUBLIC'
    ET = 'EAST TIMOR'
    EC = 'ECUADOR'
    EG = 'EGYPT'
    SV = 'EL SALVADOR'
    EQG = 'EQUITORIAL GUINEA'
    ER = 'ERITREA'
    EE = 'ESTONIA'
    ETP = 'ETHIOPIA'
    FJ = 'FIJI'
    FI = 'FINLAND'
    GA = 'GABON'
    GM = 'GAMBIA'
    GE = 'GEORGIA'
    GH = 'GHANA'
    GR = 'GREECE'
    GD = 'GRENADA'
    GT = 'GUATEMALA'
    GN = 'GUINEA'
    GW = 'GUINEA-BISSAU'
    GY = 'GUYANA'
    HT = 'HAITI'
    HN = 'HONDURAS'
    HU = 'HUNGARY'
    IS = 'ICELAND'
    ID = 'INDONESIA'
    IR = 'IRAN'
    IQ = 'IRAQ'
    IE = 'IRELAND'
    IL = 'ISRAEL'
    IT = 'ITALY'
    JM = 'JAMAICA'
    JO = 'JORDAN'
    KZ = 'KAZAKHSTAN'
    KE = 'KENYA'
    KI = 'KIRIBATI'
    KP = 'NORTH KOREA'
    KR = 'SOUTH KOREA'
    KW = 'KUWAIT'
    KG = 'KYRGYSTAN'
    LA = 'LAOS'
    LV = 'LATVIA'
    LBN = 'LEBANON'
    LS = 'LESOTHO'
    LR = 'LIBERIA'
    LY = 'LIBYA'
    LI = 'LIECHTENSTEIN'
    LT = 'LITHUANIA'
    LB = 'LUXEMBORG'
    MD = 'MACEDONIA'
    MG = 'MADAGASCAR'
    MW = 'MALAWI'
    MY = 'MALAYSIA'
    MV = 'MALDIVES'
    ML = 'MALI'
    MT = 'MALTA'
    MH = 'MARSHALL ISLANDS'
    MR = 'MAURITANIA'
    MU = 'MAURITIUS'
    MX = 'MEXICO'
    MCN = 'MICRONESIA'
    MO = 'MOLDOVA'
    MC = 'MONACO'
    MN = 'MONGOLIA'
    ME = 'MONTENEGRO'
    MA = 'MOROCCO'
    MZ = 'MOZAMBIQUE'
    MM = 'MYANMAR'
    NA = 'NAMIBIA'
    NR = 'NAURU'
    NP = 'NEPAL'
    NL = 'NETHERLANDS'
    NZ = 'NEW ZEALAND'
    NI = 'NICARAGUA'
    NE = 'NIGER'
    NG = 'NIGERIA'
    NO = 'NORWAY'
    OM = 'OMAN'
    PK = 'PAKISTAN'
    PW = 'PALAU'
    PAL = 'PALESTINE'
    PA = 'PANAMA'
    PG = 'PAPUA NEW GUINEA'
    PY = 'PARAGUAY'
    PE = 'PERU'
    PHI = 'PHILLIPINES'
    PL = 'POLAND'
    PT = 'PORTUGAL'
    QA = 'QATAR'
    RO = 'ROMANIA'
    RUS = 'RUSSIA'
    RW = 'RWANDA'
    WS = 'SAMOA'
    SM = 'SAN MARINO'
    SADR = 'SAHRAWI ARAB DEMOCRATIC REPUBLIC'
    STP = 'SAO TOME & PRINCIPE'
    SA = 'SAUDI ARABIA'
    SN = 'SENEGAL'
    RS = 'SERBIA'
    SC = 'SEYCHELLES'
    SL = 'SIERRA LEONNE'
    SK = 'SLOVAKIA'
    SOL = 'SOLOVENIA'
    SOLIS = 'SOLOMAN ISLANDS'
    SO = 'SOMALIA'
    ZA = 'SOUTH AFRICA'
    ES = 'SPAIN'
    LK = 'SRI LANKA'
    STKN = 'ST KITTS-NEVIS'
    STL = 'ST LUCIA'
    STVG = 'ST VINCENT & THE GRENADINES'
    SD = 'SUDAN'
    SR = 'SURINAME'
    SZ = 'SWAZILAND'
    SE = 'SWEDEN'
    CH = 'SWITZERLAND'
    SYR = 'SYRUIA'
    TW = 'TAIWAN'
    TJ = 'TAJIKISTAN'
    TZ = 'TANZANIA'
    TH = 'THAILAND'
    TG = 'TOGO'
    TO = 'TONGA'
    TT = 'TRINIDAD AND TOBAGO'
    TN = 'TUNISIA'
    TR = 'TURKEY'
    TM = 'TURKMENISTAN'
    TV = 'TUVALU'
    UG = 'UGANDA'
    UA = 'UKRAINE'
    UY = 'URUGUAY'
    UZ = 'UZBEKISTAN'
    VU = 'VANUATU'
    VC = 'VATICAN CITY'
    VE = 'VENEZUELA'
    VN = 'VIETNAM'
    YE = 'YEMEN'
    ZM = 'ZAMBIA'
    ZW = 'ZIMBABWE'
    DFT = 'Default'
    
class ProofOfResidence(str, Enum):
    YES = 'YES'  # YES
    NO = 'NO'  # NO
    DFT = 'DFT'  # Default

class NomineeGuardianAddressPresent(str, Enum):
    YES = 'YES'  # YES
    NO = 'NO'  # NO
    DFT = 'DFT'  # Default

class MinorNomineeGuardianAddressPresent(str, Enum):
    YES = 'YES'  # YES
    NO = 'NO'  # NO
    DFT = 'DFT'  # Default

class ForeignCorrespondenceAddressPresent(str, Enum):
    YES = 'YES'  # YES
    NO = 'NO'  # NO
    DFT = 'DFT'  # Default

class AuthFlag(str, Enum):
    YES = 'YES'  # YES
    NO = 'NO'  # NO
    DFT = 'DFT'  # Default

class CoparcenerOrMember(str, Enum):
    COP = 'COP'  # Coparcener
    MBR = 'MBR'  # Member
    DFT = 'DFT'  # Default

class StatusOrClosureReasonCode(str, Enum):
    CICC = 'CICC'  # CDSL Initiated CISA Closure
    IDNAST = 'IDNAST'  # ID Not Activated Within Stipulated Time
    ATS = 'ATS'  # Account Transmission
    ATC = 'ATC'  # ACCOUNT TRANSFER
    TTOD = 'TTOD'  # Transfer to other DP
    VAWD = 'VAWD'  # Violation of Agreement with DP
    NPOD = 'NPOD'  # Non Payment of Dues
    VOPBO = 'VOPBO'  # Violation of Provisions by a BO
    TODP = 'TODP'  # Termination of DP
    SODP = 'SODP'  # Suspension of DP
    CBDPC = 'CBDPC'  # Closed because of DP Closure
    MODCR = 'MODCR'  # Modification as per Client's Request
    VLRBP = 'VLRBP'  # Voluntary rectifications by Participants
    CRNSDL = 'CRNSDL'  # Client request to NSDL
    MANCON = 'MANCON'  # Mandatory Conversion
    CPOA = 'CPOA'  # Cessation of POA on intimation from Exchanges as per SEBI  Cir
    CLNTRQ = 'CLNTRQ'  # As per Client's Request
    CLIBP = 'CLIBP'  # Closure Initiated by Participants
    OTHR = 'OTHR'  # User defined text
    DFT = 'DFT'  # Default   


class NameChangeReasonCode(str, Enum):
    OAOM = 'OAOM'  # On account of marriage
    OTTM = 'OTTM'  # Other than marriage
    ERRDP = 'ERRDP'  # Participant error / Typographical error at DP end
    DTHOK = 'DTHOK'  # Death of Karta
    PPOH = 'PPOH'  # Partial Partition of HUF
    CPOG = 'CPOG'  # Change published in official gazette
    NCNIA = 'NCNIA'  # Name Change of Non Individual Account
    CHGNM = 'CHGNM'  # Change of Nominee
    MNRCR = 'MNRCR'  # Minor Correction in the name of the BO
    CHGGRD = 'CHGGRD'  # Change of Guardian
    DFT = 'DFT'  # Default

class AdditionDeletionIndicator(str, Enum):
    ADD = 'ADD'  # Addition
    MOD = 'MOD'  # Modification
    DEL = 'DEL'  # Deletion
    DFT = 'DFT'  # Default

class PreferredDepositoryFlagForCAS(str, Enum):
    CDSL = 'CDSL'  # Central Depository Services (India) Limited
    NSDL = 'NSDL'  # National Securities Depository Limited
    DFT = 'DFT'  # Default

class ClosureInitiatedBy(str, Enum):
    BO = 'BO'  # Initiated By BO
    DP = 'DP'  # Initiated by DP
    DF = 'DF'  # Default

class RemainingBalances(str, Enum):
    BRT = 'BRT'  # Both Rematerialized And Transferred.
    NA = 'NA'  # Not Applicable.
    RMT = 'RMT'  # Rematerialized.
    TRF = 'TRF'  # Transfer.
    DFT = 'DFT'  # Default

class SaralFlag(str, Enum):
    YES = 'YES'  # YES
    NO = 'NO'  # NO
    DFT = 'DFT'  # Default


class SignatureType(str, Enum):
    PHY = 'PHY'  # Physical
    DIG = 'DIG'  # Digital
    DFT = 'DFT'  # Default