from pydantic import BaseModel, Field
from datetime import date, datetime
from abc import ABC
from typing import List

# Import all the enums from helper_enums.py
from .helper_enums import *


class Signature(BaseModel):
    file_name: str = Field(..., description="File name of the signature")
    doc_id: str = Field(..., description="Doc id  of the signature")


class CDSLRecordModel(BaseModel, ABC):
    """Base model for CDSL demat payload with common fields."""

    Purpse: Purpose | None = Field(None, description="Purpose Code")
    BOTxnTyp: BOTransactionType | None = Field(None, description="BO Transaction Type")
    Titl: str | None = Field(None, description="BO TITLE")
    FrstNm: str | None = Field(None, description="BO NAME")
    MddlNm: str | None = Field(None, description="BO MIDDLE NAME")
    LastNm: str | None = Field(None, description="LAST / SEARCH NAME")
    BirthDt: date | None = Field(
        None, description="DATE OF BIRTH/ORIGIN/ Date of Maturity / Date of formation"
    )
    NmnorGrdnAddPrsnt: NomineeGuardianAddressPresent | None = Field(
        None, description="Nominee/Guardian address present"
    )
    MnrNmnGrdnAddPrsnt: MinorNomineeGuardianAddressPresent | None = Field(
        None, description="Minor Nominee's Guardian Address present"
    )
    Gndr: Gender | None = Field(None, description="SEX CODE / Gender")
    UID: str | None = Field(None, description="Aadhaar/ UID")
    PAN: str | None = Field(None, description="PAN / INCOME TAX PAN")
    EmailAdr: str | None = Field(None, description="Email ID/ PRIMARY EMAIL")
    MobNb: str | None = Field(None, description="Mobile no/ PRIMARY MOBILE NO")
    Adr1: str | None = Field(None, description="Address 1 / CUST ADDR 1")
    Adr2: str | None = Field(None, description="Address 2 / CUST ADDR 2")
    Adr3: str | None = Field(None, description="Address 3 / CUST ADDR 3")
    Adr4: str | None = Field(None, description="Address 4 /Cust Addr City")
    PstCd: str | None = Field(None, description="Pin Code / CUST ADDR ZIP")
    Ctry: AddressCountryCode | None = Field(
        None, description="Country Code / CUST ADDR CNTRY CODE"
    )
    CtrySubDvsnCd: str | None = Field(
        None, description="State Code / CUST ADDR STATE CODE"
    )
    CtrySubDvsnNm: str | None = Field(None, description="State Name")
    PurpCd: PurposeCode | None = Field(None, description="Address INDICATOR")


class HolderRecord(CDSLRecordModel):
    """Primary account holder model."""

    CntrlSctiesDpstryPtcpt: str = Field(..., description="DP Id")
    BrnchId: str = Field(..., description="Branch Code, always 000000 for CDSL")
    BtchId: int | None = Field(
        None, description="Batch Number, to determine uniqueness of batch"
    )
    ClntId: str | None = Field(None, description="BO ID/Client ID")
    SndrId: str | None = Field(
        None,
        description="Sender User ID /Operator ID. User ID of user uploading the file. Max 6 characters for CDSL.",
    )
    CntrlSctiesDpstryPtcptRole: DPType | None = Field(
        None, description="DP Type / BP Role"
    )
    SndrDt: date | None = Field(None, description="Sender Date")
    RcvDt: datetime | None = Field(
        None,
        description="Document Receive Date / BO REQUEST RECEIVE DATE / POA Registratration - Deregistration Date",
    )
    RcrdNb: int = Field(..., description="Record Number")
    RcdSRNumber: int | None = Field(
        None, description="Record Serial Number / Line Number"
    )
    PrdNb: ProductNumber | None = Field(
        None, description="Product Number / Client Type"
    )
    BnfcrySubTp: BeneficiarySubType | None = Field(
        None, description="Beneficiary Sub Type / BO Sub Status"
    )
    FSfx: str | None = Field(None, description="BO SUFFIX")
    BnfcryShrtNm: str | None = Field(None, description="Beneficiary Short name")
    ScndHldrNmOfFthr: str | None = Field(None, description="FATHER / HUSBAND NAME")
    PANVrfyFlg: PANVerificationFlag | None = Field(
        None, description="PAN Flag/PAN Verification Flag"
    )
    PANXmptnCd: PANExemptedCode | None = Field(None, description="PAN Exemption Code")
    AdhrAuthntcnWthUID: AadhaarAuthenticationWithUIDFlag | None = Field(
        None, description="Aadhaar Authenticated with UIDAI/ UID VERIFICATION FLAG"
    )
    RsnForNonUpdtdAdhr: ReasonForNonUpdatedAadhaar | None = Field(
        None, description="Reason for Non-Updation of Aadhaar"
    )  # Not applicable for CDSL
    VID: str = Field(
        "", description="Virtual ID (VID), N/A for CDSL"
    )  # Not applicable for CDSL
    SMSFclty: SMSFacility | None = Field(
        None, description="SMS facility/ SMART REGISTRATION INDICATOR"
    )
    PrmryISDCd: str | None = Field(
        None, description="ISD code for Mobile no/ PRIMARY MOBILE NO ISD CODE"
    )
    FmlyFlgForMobNbOf: FamilyFlagForMobile | None = Field(
        None, description="Family Flag for Mobile Number"
    )  # Not applicable for CDSL
    ScndryISDCd: str | None = Field(
        None, description="ISD code for Mobile no/ Secondary MOBILE NO ISD CODE"
    )
    PhneNb: str | None = Field(None, description="Phone No. / SECONDARY MOBILE / PHONE")
    FmlyFlgForEmailAdr: FamilyFlagForEmail | None = Field(
        None, description="Family Flag for Email ID/ FAMILY ACCOUNT FLAG"
    )
    AltrnEmailAdr: str | None = Field(
        None, description="Alternate Email ID/ SECONDARY EMAIL"
    )
    NoNmntnFlg: NoNominationFlag | None = Field(
        None, description="No Nomination Flag / Opt out of Nomination Flag"
    )  # Not applicable for CDSL
    MdOfOpr: ModeOfOperation | None = Field(None, description="Mode of Operation")
    ClrMmbId: str | None = Field(None, description="CM ID")
    StgInstr: StandingInstructionIndicator | None = Field(
        None, description="Standing Instruction Indicator / CONFIRMATION WAIVED"
    )
    GrssAnlIncmRg: GrossAnnualIncomeRange | None = Field(
        None, description="Gross Annual Income Range / ANNUAL INCOME CODE"
    )
    NetWrth: int | None = Field(
        None, description="Net Worth, not applicable for CDSL"
    )  # Not applicable for CDSL
    NetWrthAsOnDt: date | None = Field(
        None, description="Net Worth Date, , not applicable for CDSL"
    )  # Not applicable for CDSL
    LEI: str | None = Field(None, description="LEI No.")
    LEIExp: date | None = Field(None, description="LEI Expiry date")
    OneTmDclrtnFlgForGSECIDT: OneTimeDeclarationFlagForGSECIDT | None = Field(
        None, description="One Time Declaration Flag for GSEC IDT / BONAFIDE FLAG"
    )
    INIFSC: str | None = Field(None, description="IFSC / DIVIDEND BANK IFSC CODE")
    MICRCd: str | None = Field(None, description="MICR Code / DIVND BANK CODE")
    DvddCcy: int | None = Field(None, description="DIVIDEND CURRENCY")
    DvddBkCcy: int | None = Field(None, description="DIVND BANK CCY")
    RBIApprvdDt: date | None = Field(
        None, description="RBI Approval date / IRDA Approval Date / RBI APPROVAL DATE"
    )
    RBIRefNb: date | None = Field(
        None, description="RBI Reference No. / IRDA Ref. No. / RBI REFERENCE NUMBER"
    )
    Mndt: ECSMandate | None = Field(None, description="ECS MANDATE")
    SEBIRegNb: str | None = Field(None, description="SEBI Registration Number")
    EdctnLvl: EducationDegree | None = Field(None, description="EDUCATION/DEGREE")
    AnlRptFlg: AnnualReportFlag | None = Field(
        None,
        description="Receive Annual Reports, AGM notices and other communications from Issuers & RTAs in physical form / ANNUAL REPORT FLAG",
    )
    BnfclOwnrSttlmCyclCd: BOStatementCycleCode | None = Field(
        None, description="BO STATEMENT CYCLE CODE"
    )
    ElctrncConf: ElectronicConfitmation | None = Field(
        None, description="ELECTRONIC CONFIRMATION"
    )
    EmailRTADwnldFlg: EmailRTADDwonloadFlag | None = Field(
        None, description="EMAIL RTA DOWNLOAD FLAG"
    )
    GeoCd: GeoCode | None = Field(None, description="GEOGRAPHICAL CODE")
    Xchg: Exchange | None = Field(None, description="Exchange ID")
    MntlDsblty: MentalDisablity | None = Field(None, description="MENTAL DISABILITY")
    Ntlty: Nationality | None = Field(None, description="NATIONALITY CODE")
    CASMd: CASMode | None = Field(None, description="CAS MODE")
    AncstrlFlg: str | None = Field(
        None, description="Ancestral Flag, not applicable to CDSL"
    )  # Not applicable for CDSL
    PldgStgInstrFlg: AutoPledgeIndicator | None = Field(
        None, description="Auto Pledge Indicator / PLEDGE STANDING INSTRUCTION FLAG"
    )
    BkAcctTp: BankAccountType | None = Field(
        None, description="Bank Acct Type / DIVND BANK ACCT TYPE"
    )
    BnfcryAcctCtgy: BOCategory | None = Field(
        None, description="Beneficiary Account Category /BO Category"
    )
    BnfcryBkAcctNb: str | None = Field(
        None, description="Beneficiary Bank Account Number / DIVND ACCT NUMB"
    )
    BnfcryBkNm: str | None = Field(
        None, description="Beneficiary Bank Name"
    )  # Not applicable for CDSL
    BnfcryTaxDdctnSts: BeneficiaryTaxDeductionStatus | None = Field(
        None,
        description="Beneficiary Tax Deduction Status / BENEFICIARY TAX DEDUCTION STATUS",
    )
    ClrSysId: CHId | None = Field(None, description="CC ID/CH ID")
    BSDAFlg: BSDAFlag | None = Field(None, description="BSDA Flag / BSDA FLAG")
    Ocptn: Occupation | None = Field(
        None, description="Beneficiary Occupation / Occupation"
    )
    PMSClntAcctFlg: PMSClientAccountFlag | None = Field(
        None, description="PMS Client Account Flag"
    )  # Not applicable for CDSL
    PMSSEBIRegnNb: str | None = Field(None, description="PMS SEBI Registration No.")
    PostvConf: PositiveConfimation | None = Field(
        None, description="Positive Confirmation"
    )  # Not applicable for CDSL
    FrstClntOptnToRcvElctrncStmtFlg: EmailStatementFlag | None = Field(
        None,
        description="Client Option to receive e- Statement' Flag / Email Statement Flag",
    )
    ComToBeSentTo: CommunicationPreference | None = Field(
        None, description="Communications to be sent to /Communication Preference"
    )
    DelFlg: DeletionFlag | None = Field(None, description="DELETION FLAG")
    RsnCdDeltn: ReasonCodeForDeletion | None = Field(
        None, description="REASON CODE FOR DELETION"
    )
    DtOfDeath: date | None = Field(None, description="DATE OF DEATH")
    AccntOpSrc: AccountOpeningSource | None = Field(
        None, description="Account opening source"
    )
    CustdPmsEmailId: str | None = Field(None, description="Custodian /PMS email Id")
    POAOrDDPITp: POAOrDDPIType | None = Field(None, description="POA / DDPI Type")
    TradgId: str | None = Field(None, description="TRADING ID")
    SndrRefNb1: str | None = Field(None, description="Sender reference number 1")
    SndrRefNb2: str | None = Field(
        None, description="Sender reference number 2, not applicable for CDSL"
    )  # Not applicable for CDSL
    CtdnFlg: str | None = Field(
        None, description="Custodian Flag"
    )  # Not applicable for CDSL
    DmtrlstnGtwy: DematGateway | None = Field(
        None, description="Demat Gateway"
    )  # Not applicable for CDSL
    AdrPrefFlg: AddressPrefFlag | None = Field(
        None, description="Address preference flag"
    )  # Not applicable for CDSL
    CitySeqNb: int | None = Field(None, description="CITY SEQUENCE NUMBER")
    FaxNb: str | None = Field(None, description="Fax No. / FAX")
    ITCrcl: str | None = Field(None, description="IT CIRCLE")
    ProofOfRes: ProofOfResidence | None = Field(
        None, description="Proof of Residence / Correspondence Address not Submitted"
    )  # Not applicable for CDSL
    LclAddPrsnt: str | None = Field(
        None, description="Local address present"
    )  # Not applicable for CDSL
    BnkAddPrsnt: str | None = Field(None, description="Bank address present")
    FrgnOrCorrAddPrsnt: ForeignCorrespondenceAddressPresent | None = Field(
        None, description="Foreign/Correspondence address present"
    )
    NbOfAuthSgnt: int | None = Field(
        None, description="Number of Authorized Signatories"
    )
    AuthFlg: AuthFlag | None = Field(None, description="Auth Flag")
    CoprcnrOrMmbr: CoparcenerOrMember | None = Field(
        None, description="Coparcener / Member"
    )
    TypMod: str | None = Field(None, description="Type to be modified")
    SubTypMod: str | None = Field(None, description="Subtype to be modified")
    StsChgRsnOrClsrRsnCd: StatusOrClosureReasonCode | None = Field(
        None, description="Status Change Reason / Closure Reason Code"
    )
    NmChgRsnCd: NameChangeReasonCode | None = Field(
        None, description="Name Change Reason Code"
    )
    ExecDt: date | None = Field(None, description="Execution Date")
    AddModDelInd: AdditionDeletionIndicator | None = Field(
        None, description="Addition and Deletion Indicator"
    )
    AppKrta: str | None = Field(None, description="Appoint as Karta")
    ChgKrtaRsn: str | None = Field(None, description="Change of Karta Reason")
    DtIntmnBO: date | None = Field(None, description="Date of Intimation to BO")
    PrfDpstryFldFrCAS: PreferredDepositoryFlagForCAS | None = Field(
        None, description="Preferred Depository Flag For CAS"
    )
    CoprcnrsId: int | None = Field(None, description="Coparcener / Member ID")
    ClsrInitBy: ClosureInitiatedBy | None = Field(
        None, description="Closure Initiated By"
    )
    RmngBal: RemainingBalances | None = Field(None, description="Remaining Balances")
    CANm: str | None = Field(None, description="CA Name")
    CertNbr: str | None = Field(None, description="Certificate Number")
    CertXpryDt: date | None = Field(None, description="Certificate Expiry Date")
    NbrPOASgntryReqSign: int | None = Field(
        None, description="No of POA / DDPI Signatory required for Signing"
    )
    DpstryInd: str | None = Field(None, description="Depository Indicator")
    AcctTyp: str | None = Field(None, description="Account Type")
    SrcCMBPID: str | None = Field(None, description="Source CM BP ID")
    TrgtDPID: str | None = Field(None, description="Target DP ID")
    TrgtClntID: str | None = Field(
        None, description="Target Client ID/ Other Depository Client Code"
    )
    SrlFlg: SaralFlag | None = Field(None, description="Saral Flag")
    UPIId: str | None = Field(None, description="UPI ID")
    SignTyp: str | None = Field(None, description="Signature Type")
    NBOID: str | None = Field(None, description="New BO ID")
    ChrInstUnvFlg: str | None = Field(
        None, description="Charitable institution / University Flag"
    )
    Rsvd3: str | None = Field(None, description="Dummy_Field_3")
    Rsvd4: str | None = Field(None, description="Dummy_Field_4")
    SignFlNm: str | None = Field(None, description="Signature File Name")


class NomineeRecord(CDSLRecordModel):
    """Nominee details model."""

    # Nominee specific fields
    NmneeMnrInd: NomineeMinorIndicator | None = Field(
        None, description="Nominee Minor Indicator"
    )
    RltshWthBnfclOwnr: RelationshipWithBOorKarta | None = Field(
        None, description="Relationship with BO"
    )
    NmneePctgOfShr: float | None = Field(
        None, description="Percentage of Share"
    )  # Not applicable for CDSL
    SrlNbr: int | None = Field(None, description="Serial No of Nominee")
    FlgForShrPctgEqlty: FlagForSharePercentageEquality | None = Field(
        None, description="Flag for Share Percentage Equality"
    )
    RsdlSecFlg: ResidualSecuritiesFlag | None = Field(
        None, description="Residual Securities Flag"
    )


class NomineeGuardianRecord(CDSLRecordModel):
    """Nominee Guardian details model."""

    # Nominee Guardian specific fields
    RltshWthBnfclOwnr: RelationshipWithBOorKarta | None = Field(
        None, description="Relationship with BO / Relation with Karta"
    )
    SrlNbr: int | None = Field(
        None, description="Serial No of the Authorized Signatory"
    )


class CDSLDematPayloadModel(BaseModel):
    records: List[CDSLRecordModel] = Field(
        ..., description="List of holder/nominee/guardian records"
    )
    signatures: List[Signature] = Field(..., description="List of signatures")
