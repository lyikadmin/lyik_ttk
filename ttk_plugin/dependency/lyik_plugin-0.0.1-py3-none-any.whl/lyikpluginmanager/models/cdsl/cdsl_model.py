from pydantic import BaseModel, Field
from datetime import date, datetime
from src.lyikpluginmanager.models.cdsl.helper_enums import *


class ExcelModel(BaseModel):
    CntrlSctiesDpstryPtcpt: str = Field(..., description="DP Id")
    BrnchId: str = Field("000000", description="Branch Code, always 000000 for CDSL")
    BtchId: int = Field(
        ..., description="Batch Number, to determine uniqueness of batch"
    )
    SndrId: str = Field(
        ...,
        description="Sender User ID /Operator ID. User ID of user uploading the file. Max 6 characters for CDSL.",
    )
    CntrlSctiesDpstryPtcptRole: DPType = Field(..., description="DP Type / BP Role")
    SndrDt: date = Field(..., description="Sender Date")
    RcvDt: datetime = Field(
        ...,
        description="Document Receive Date / BO REQUEST RECEIVE DATE / POA Registratration - Deregistration Date",
    )
    RcrdNb: int = Field(..., description="Record Number")
    RcdSRNumber: int = Field(..., description="Record Serial Number / Line Number")
    BOTxnTyp: BOTransactionType = Field(..., description="BO Transaction Type")
    ClntId: str = Field(..., description="BO ID/Client ID")
    PrdNb: ProductNumber = Field(..., description="Product Number / Client Type")
    BnfcrySubTp: BeneficiarySubType = Field(
        ..., description="Beneficiary Sub Type / BO Sub Status"
    )
    Purpse: Purpose = Field(..., description="Purpose Code")
    Titl: str = Field(..., description="BO TITLE")
    FrstNm: str = Field(..., description="BO NAME")
    MddlNm: str = Field(..., description="BO MIDDLE NAME")
    LastNm: str = Field(..., description="LAST / SEARCH NAME")
    FSfx: str = Field(..., description="BO SUFFIX")
    BnfcryShrtNm: str = Field(..., description="Beneficiary Short name")
    ScndHldrNmOfFthr: str = Field(..., description="FATHER / HUSBAND NAME")
    BirthDt: date = Field(
        ..., description="DATE OF BIRTH/ORIGIN/ Date of Maturity / Date of formation"
    )
    Gndr: Gender = Field(..., description="SEX CODE / Gender")
    PAN: str = Field(..., description="PAN / INCOME TAX PAN")
    PANVrfyFlg: PANVerificationFlag = Field(
        ..., description="PAN Flag/PAN Verification Flag"
    )
    PANXmptnCd: PANExemptedCode = Field(..., description="PAN Exemption Code")
    UID: str = Field(..., description="Aadhaar/ UID")
    AdhrAuthntcnWthUID: AadhaarAuthenticationWithUIDFlag = Field(
        ..., description="Aadhaar Authenticated with UIDAI/ UID VERIFICATION FLAG"
    )
    RsnForNonUpdtdAdhr: ReasonForNonUpdatedAadhaar = Field(
        ..., description="Reason for Non-Updation of Aadhaar"
    )
    VID: str = Field("", description="Virtual ID (VID), N/A for CDSL")
    SMSFclty: SMSFacility = Field(
        ..., description="SMS facility/ SMART REGISTRATION INDICATOR"
    )
    PrmryISDCd: str = Field(
        ..., description="ISD code for Mobile no/ PRIMARY MOBILE NO ISD CODE"
    )  # TODO: ENUM PENDING, But Need to be dict as
    MobNb: str = Field(..., description="Mobile no/ PRIMARY MOBILE NO")
    FmlyFlgForMobNbOf: FamilyFlagForMobile = Field(
        ..., description="Family Flag for Mobile Number"
    )
    ScndryISDCd: str = Field(
        ..., description="ISD code for Mobile no/ Secondary MOBILE NO ISD CODE"
    )  # TODO: ENUM PENDING, could be same enum as PrmryISDCd
    PhneNb: str = Field(..., description="Phone No. / SECONDARY MOBILE / PHONE")
    EmailAdr: str = Field(..., description="Email ID/ PRIMARY EMAIL")
    FmlyFlgForEmailAdr: FamilyFlagForEmail = Field(
        ..., description="Family Flag for Email ID/ FAMILY ACCOUNT FLAG"
    )
    AltrnEmailAdr: str = Field(..., description="Alternate Email ID/ SECONDARY EMAIL")
    NoNmntnFlg: NoNominationFlag = Field(
        ..., description="No Nomination Flag / Opt out of Nomination Flag"
    )
    MdOfOpr: ModeOfOperation = Field(..., description="Mode of Operation")
    ClrMmbId: str = Field(..., description="CM ID")
    StgInstr: StandingInstructionIndicator = Field(
        ..., description="Standing Instruction Indicator / CONFIRMATION WAIVED"
    )
    GrssAnlIncmRg: GrossAnnualIncomeRange = Field(
        ..., description="Gross Annual Income Range / ANNUAL INCOME CODE"
    )
    NetWrth: int | None = Field(
        None, description="Net Worth, not applicable for CDSL"
    )  # Not applicable for CDSL
    NetWrthAsOnDt: date | None = Field(
        None, description="Net Worth Date, , not applicable for CDSL"
    )  # Not applicable for CDSL
    LEI: str = Field(..., description="LEI No.")
    LEIExp: date = Field(..., description="LEI Expiry date")
    OneTmDclrtnFlgForGSECIDT: OneTimeDeclarationFlagForGSECIDT = Field(
        ..., description="One Time Declaration Flag for GSEC IDT / BONAFIDE FLAG"
    )  # todo: check if enum
    INIFSC: str = Field(..., description="IFSC / DIVIDEND BANK IFSC CODE")
    MICRCd: str = Field(
        ..., description="MICR Code / DIVND BANK CODE"
    )  # Mandatory for 1st holder, blank for others
    DvddCcy: int = Field(..., description="DIVIDEND CURRENCY")
    DvddBkCcy: int = Field(..., description="DIVND BANK CCY")
    RBIApprvdDt: date = Field(
        ..., description="RBI Approval date / IRDA Approval Date / RBI APPROVAL DATE"
    )
    RBIRefNb: date = Field(
        ..., description="RBI Reference No. / IRDA Ref. No. / RBI REFERENCE NUMBER"
    )
    Mndt: ECSMandate = Field(..., description="ECS MANDATE")
    SEBIRegNb: str = Field(..., description="SEBI Registration Number")
    EdctnLvl: EducationDegree = Field(..., description="EDUCATION/DEGREE")
    AnlRptFlg: AnnualReportFlag = Field(
        ...,
        description="Receive Annual Reports, AGM notices and other communications from Issuers & RTAs in physical form / ANNUAL REPORT FLAG",
    )  # todo: check if enum
    BnfclOwnrSttlmCyclCd: BOStatementCycleCode = (
        Field(..., description="BO STATEMENT CYCLE CODE"),
    )  # TODO: Need to confirm this!
    ElctrncConf: ElectronicConfitmation = Field(
        ..., description="ELECTRONIC CONFIRMATION"
    )
    EmailRTADwnldFlg: EmailRTADDwonloadFlag = Field(
        ..., description="EMAIL RTA DOWNLOAD FLAG"
    )
    GeoCd: GeoCode = Field(..., description="GEOGRAPHICAL CODE")
    Xchg: Exchange = Field(..., description="Exchange ID")
    MntlDsblty: MentalDisablity = Field(..., description="MENTAL DISABILITY")
    Ntlty: Nationality = Field(..., description="NATIONALITY CODE")
    CASMd: CASMode = Field(..., description="CAS MODE")
    AncstrlFlg: str | None = Field(
        None, description="Ancestral Flag, not applicable to CDSL"
    )  # todo: IT's a ENUM, but Not Aplicable for CDSL
    PldgStgInstrFlg: AutoPledgeIndicator = Field(
        ..., description="Auto Pledge Indicator / PLEDGE STANDING INSTRUCTION FLAG"
    )
    BkAcctTp: BankAccountType = Field(
        ..., description="Bank Acct Type / DIVND BANK ACCT TYPE"
    )
    BnfcryAcctCtgy: BOCategory = Field(
        ..., description="Beneficiary Account Category /BO Category"
    )
    BnfcryBkAcctNb: str = Field(
        ..., description="Beneficiary Bank Account Number / DIVND ACCT NUMB"
    )
    BnfcryBkNm: str = Field(..., description="Beneficiary Bank Name")
    BnfcryTaxDdctnSts: BeneficiaryTaxDeductionStatus = Field(
        ...,
        description="Beneficiary Tax Deduction Status / BENEFICIARY TAX DEDUCTION STATUS",
    )
    ClrSysId: CHId = Field(..., description="CC ID/CH ID")
    BSDAFlg: BSDAFlag = Field(..., description="BSDA Flag / BSDA FLAG")
    Ocptn: Occupation = Field(..., description="Beneficiary Occupation / Occupation")
    PMSClntAcctFlg: PMSClientAccountFlag = Field(
        ..., description="PMS Client Account Flag"
    )
    PMSSEBIRegnNb: str = Field(..., description="PMS SEBI Registration No.")
    PostvConf: PositiveConfimation = Field(..., description="Positive Confirmation")
    FrstClntOptnToRcvElctrncStmtFlg: EmailStatementFlag = Field(
        ...,
        description="Client Option to receive e- Statement' Flag / Email Statement Flag",
    )
    ComToBeSentTo: CommunicationPreference = Field(
        ..., description="Communications to be sent to /Communication Preference"
    )  # todo: check if enum
    DelFlg: DeletionFlag = Field(..., description="DELETION FLAG")
    RsnCdDeltn: ReasonCodeForDeletion = Field(
        ..., description="REASON CODE FOR DELETION"
    )
    DtOfDeath: date = Field(..., description="DATE OF DEATH")
    AccntOpSrc: AccountOpeningSource = Field(..., description="Account opening source")
    CustdPmsEmailId: str = Field(..., description="Custodian /PMS email Id")
    POAOrDDPITp: POAOrDDPIType = Field(..., description="POA / DDPI Type")
    TradgId: str = Field(..., description="TRADING ID")
    SndrRefNb1: str = Field(
        ..., description="Sender reference number 1"
    )  # Mandatory in case of CDSL Account Opening
    SndrRefNb2: str | None = Field(
        None, description="Sender reference number 2, not applicable for CDSL"
    )  # not applicable for CDSL
    CtdnFlg: str | None = Field(
        None, description="Custodian Flag"
    )  # ENUM but not applicable for CDSL
    DmtrlstnGtwy: DematGateway = Field(..., description="Demat Gateway")
    NmneeMnrInd: NomineeMinorIndicator = Field(
        ..., description="Nominee Minor Indicator"
    )
    SrlNbr: int = Field(
        ..., description="Serial No of Nominee or the Authorized Signatory"
    )
    NmneePctgOfShr: float = Field(
        ..., description="Nominee Percentage of Share / PERCENTAGE OF SHARES"
    )
    FlgForShrPctgEqlty: FlagForSharePercentageEquality = Field(
        ..., description="Flag for Share Percentage Equality"
    )
    RsdlSecFlg: ResidualSecuritiesFlag = Field(
        ..., description="Residual Securities Flag"
    )
    RltshWthBnfclOwnr: RelationshipWithBOorKarta = Field(
        ..., description="RELATIONSHIP WITH BO / Relation with Karta"
    )
    NbOfPOAMppng: int | None = Field(None, description="Number of Poa mapping")
    POAId: str = Field(..., description="POA ID (POA REGISTRATION NO.)")
    POAToOprtAcct: PoaToOperateAccount = Field(..., description="POA TO OPERATE A/C")
    POAOrDDPIId: str = Field(..., description="POA / DDPI ID")
    SetUpDt: date = Field(
        ..., description="SETUP DATE"
    )  # TODO: Need clarification date or datetime?
    FrDt: date = Field(..., description="EFFECTIVE FROM DATE")
    ToDt: str = Field(..., description="EFFECTIVE TO DATE")
    GPABPAFlg: GPABPAFlag = Field(..., description="GPA/BPA FLAG/POA NATURE TYPE")
    POAMstrID: str = Field(..., description="POA Master ID")
    PoaLnkPurpCd: POALinkPurposeCode = Field(
        ..., description="POA Link purpose code / Indicator Link code"
    )  # todo: check if enum
    Rmk: str = Field(..., description="Remark / Account Closure Reason Text")
    BOUCCLkFlg: BOUCCLinkFlag = Field(..., description="BO-UCC Link Add/Delete Flag")
    CnsntInd: ConsentFlag = Field(..., description="Consent Flag")
    UnqClntId: str = Field(..., description="UCC")
    Brkr: str = Field(..., description="TM Code (Trading Member Code)")
    Sgmt: Segment = Field(..., description="Segment Code")
    MapUMapFlg: MappingUnmappingFlag = Field(..., description="Mapping/UnMapping Flag")
    CmAcctToMap: str = Field(
        ..., description="CM account to be mapped"
    )  # TODO: need to clarify, LOV not present in StandardValueList(SVL) but Field Master says refer SVL
    PurpCd: PurposeCode = Field(..., description="Address INDICATOR")
    AdrPrefFlg: AddressPrefFlag = Field(..., description="Address preference flag")
    Adr1: str = Field(
        ..., description="Address 1 / CUST ADDR 1"
    )  # Mandatory for First Holder, Optional for all others.
    Adr2: str = Field(..., description="Address 2 / CUST ADDR 2")
    Adr3: str = Field(..., description="Address 3 / CUST ADDR 3")
    Adr4: str = Field(..., description="Address 4 /Cust Addr City")
    Ctry: AddressCountryCode = Field(
        ..., description="Country Code / CUST ADDR CNTRY CODE"
    )
    PstCd: str = Field(..., description="Pin Code / CUST ADDR ZIP")
    CtrySubDvsnCd: str = Field(
        ..., description="State Code / CUST ADDR STATE CODE"
    )  # todo: Need to be a Dict of statename-statecode
    CitySeqNb: int = Field(
        ..., description="CITY SEQUENCE NUMBER"
    )  # TODO: LOV not present in csv doc, but only upto 2 digit number is allowed!
    FaxNb: str = Field(..., description="Fax No. / FAX")
    ITCrcl: str = Field(..., description="IT CIRCLE")
    ProofOfRes: ProofOfResidence = Field(
        ..., description="Proof of Residence / Correspondence Address not Submitted"
    )
    NbOfCoprcnrs: int | None = Field(
        None, description="Number of Coparceners / Members"
    )  # Not applicable for CDSL
    SgntryId: int | None = Field(
        None, description="Signatory"
    )  # Not applicable for CDSL
    SgntrSz: int = Field(
        ..., description="Size of signature"
    )  # Not applicable for CDSL
    BnfclOwnrAcctOfPMSFlg: str | None = Field(
        None, description="Beneficial owner account of PMS' Flag"
    )  # todo: Enum but not applicable for CDSL
    CrspdngBPId: str | None = Field(
        None, description="Corresponding BP ID"
    )  # Not applicable for CDSL
    ClngMbrPAN: str = Field(
        ..., description="Clearing Member PAN No."
    )  # Not applicable for CDSL
    LclAddPrsnt: str = Field(
        ..., description="Local address present"
    )  # Enum but not applicable for CDSL
    BnkAddPrsnt: str | None = Field(None, description="Bank address present")
    NmnorGrdnAddPrsnt: NomineeGuardianAddressPresent | None = Field(
        None, description="Nominee/Guardian address present"
    )  # Enum but not applicable for CDSL
    MnrNmnGrdnAddPrsnt: MinorNomineeGuardianAddressPresent | None = Field(
        None, description="Minor Nominee's Guardian Address present"
    )  # Enum but not applicable for CDSL
    FrgnOrCorrAddPrsnt: ForeignCorrespondenceAddressPresent | None = Field(
        None, description="Foreign/Correspondence address present"
    )  # Enum but not applicable for CDSL
    NbOfAuthSgnt: int | None = Field(
        None, description="Number of Authorized Signatories"
    )
    AuthFlg: AuthFlag | None = Field(
        None, description="Auth Flag"
    )  # Enum but not applicable for CDSL
    CoprcnrOrMmbr: CoparcenerOrMember | None = Field(
        None, description="Coparcener / Member"
    )  # Enum but not applicable for CDSL
    TypMod: str | None = Field(
        None, description="Type to be modified"
    )  # Enum but not applicable for CDSL
    SubTypMod: str | None = Field(
        None, description="Subtype to be modified"
    )  # Enum but not applicable for CDSL
    StsChgRsnOrClsrRsnCd: StatusOrClosureReasonCode = Field(
        ..., description="Status Change Reason / Closure Reason Code"
    )
    NmChgRsnCd: NameChangeReasonCode = Field(..., description="Name Change Reason Code")
    ExecDt: date = Field(..., description="Execution Date")
    AddModDelInd: AdditionDeletionIndicator = Field(
        ..., description="Addition and Deletion Indicator"
    )
    AppKrta: str = Field(
        ..., description="Appoint as Karta"
    )  # Enum but not applicable for CDSL
    ChgKrtaRsn: str = Field(
        ..., description="Change of Karta Reason"
    )  # Enum but not applicable for CDSL
    DtIntmnBO: date | None = Field(
        None, description="Date of Intimation to BO"
    )  # Not applicable for CDSL
    PrfDpstryFldFrCAS: PreferredDepositoryFlagForCAS = Field(
        ..., description="Preferred Depository Flag For CAS"
    )
    CoprcnrsId: int = Field(
        ..., description="Coparcener / Member ID"
    )  # Not applicable for CDSL
    ClsrInitBy: ClosureInitiatedBy = Field(..., description="Closure Initiated By")
    RmngBal: RemainingBalances = Field(..., description="Remaining Balances")
    CANm: str | None = Field(None, description="CA Name")  # Not applicable for CDSL
    CertNbr: str | None = Field(
        None, description="Certificate Number"
    )  # Not applicable for CDSL
    CertXpryDt: date | None = Field(
        None, description="Certificate Expiry Date"
    )  # Not applicable for CDSL
    NbrPOASgntryReqSign: int | None = Field(
        None, description="No of POA / DDPI Signatory required for Signing"
    )  # Not applicable for CDSL
    DpstryInd: str | None = Field(
        None, description="Depository Indicator"
    )  # Not applicable for CDSL
    AcctTyp: str | None = Field(
        None, description="Account Type"
    )  # Enum but not applicable for CDSL
    SrcCMBPID: str | None = Field(
        None, description="Source CM BP ID"
    )  # Not applicable for CDSL
    TrgtDPID: str | None = Field(
        None, description="Target DP ID"
    )  # Not applicable for CDSL
    TrgtClntID: str = Field(
        ..., description="Target Client ID/ Other Depository Client Code"
    )  # Not applicable for CDSL
    SrlFlg: SaralFlag | None = Field(
        None, description="Saral Flag"
    )  # Enum but not applicable for CDSL
    UPIId: str | None = Field(None, description="UPI ID")  # Not applicable for CDSL
    SignTyp: SignatureType | None = Field(
        None, description="Signature Type"
    )  # Enum but not applicable for CDSL
    NBOID: str = Field(..., description="New BO ID")
    ChrInstUnvFlg: str | None = Field(
        None, description="Charitable institution / University Flag"
    )  # Not applicable for CDSL
    CtrySubDvsnNm: str | None = Field(
        None, description="State Name"
    )  # State Name if India, else country Name, optional
    Rsvd3: str | None = Field(None, description="Dummy_Field_3")
    Rsvd4: str | None = Field(None, description="Dummy_Field_4")
