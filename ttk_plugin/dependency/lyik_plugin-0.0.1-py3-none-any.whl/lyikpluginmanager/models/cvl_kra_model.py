from datetime import datetime
from pydantic import BaseModel, Field, ConfigDict, field_validator


class Header(BaseModel):
    COMPANY_CODE: str = Field(description="Company code")
    BATCH_DATE: str = Field(description="Batch date")


class Footer(BaseModel):
    NO_OF_KYC_RECORDS: str = Field(description="Number of KYC records")
    NO_OF_ADDLDATA_RECORDS: str = Field(description="Number of ADDL Data Records")
    NO_OF_FATCA_ADDL_DTLS_RECORDS: str = Field(
        description="Number of FATCA ADDL DTLS Records"
    )


class FATCAAddlDtls(BaseModel):
    APP_FATCA_ENTITY_PAN: str | None = None
    APP_FATCA_COUNTRY_RESIDENCY: str | None = None
    APP_FATCA_TAX_IDENTIFICATION_NO: str | None = None
    APP_FATCA_TAX_EXEMPT_FLAG: str | None = None
    APP_FATCA_TAX_EXEMPT_REASON: str | None = None


class KYCData(BaseModel):
    APP_UPDTFLG: str | None = None
    APP_KRA_CODE: str | None = None
    APP_POS_CODE: str | None = None
    APP_TYPE: str | None = None
    APP_NO: str | None = None
    APP_DATE: str | None = None
    APP_PAN_NO: str | None = None
    APP_PAN_COPY: str | None = None
    APP_EXMT: str | None = None
    APP_EXMT_CAT: str | None = None
    APP_EXMT_ID_PROOF: str | None = None
    APP_IPV_FLAG: str | None = None
    APP_IPV_DATE: str | None = None
    APP_GEN: str | None = None
    APP_NAME: str | None = None
    APP_F_NAME: str | None = None
    APP_REGNO: str | None = None
    APP_DOB_INCORP: str | None = None
    APP_COMMENCE_DT: str | None = None
    APP_NATIONALITY: str | None = None
    APP_OTH_NATIONALITY: str | None = None
    APP_COMP_STATUS: str | None = None
    APP_OTH_COMP_STATUS: str | None = None
    APP_RES_STATUS: str | None = None
    APP_RES_STATUS_PROOF: str | None = None
    APP_UID_NO: str | None = Field(
        None,
        description="UID / Aadhaar No of the applicant in case of Individuals only. Value will be mandatory for E-KYC Transactions. Only Last 4 Digit is acceptable",
    )
    APP_COR_ADD1: str | None = None
    APP_COR_ADD2: str | None = None
    APP_COR_ADD3: str | None = None
    APP_COR_CITY: str | None = None
    APP_COR_PINCD: str | None = None
    APP_COR_STATE: str | None = None
    APP_COR_CTRY: str | None = None
    APP_OFF_ISD: int | None = None
    APP_OFF_STD: int | None = None
    APP_OFF_NO: int | None = None
    APP_RES_ISD: int | None = None
    APP_RES_STD: int | None = None
    APP_RES_NO: int | None = None
    APP_MOB_ISD: int | None = None
    APP_MOB_NO: int | None = None
    APP_FAX_ISD: int | None = None
    APP_FAX_STD: int | None = None
    APP_FAX_NO: int | None = None
    APP_EMAIL: str | None = None
    APP_COR_ADD_PROOF: str | None = None
    APP_COR_ADD_REF: str | None = None
    APP_COR_ADD_DT: str | None = Field(
        None,
        description="Format to be used is dd/mm/yyyy, IF DEEMED OVD IS SUBMITTED, THEN THIS FIELD BECOMES MANDATORY",
    )
    APP_PER_ADD_FLAG: str | None = None
    APP_PER_ADD1: str | None = None
    APP_PER_ADD2: str | None = None
    APP_PER_ADD3: str | None = None
    APP_PER_CITY: str | None = None
    APP_PER_PINCD: str | None = None
    APP_PER_STATE: str | None = None
    APP_PER_CTRY: str | None = None
    APP_PER_ADD_PROOF: str | None = None
    APP_PER_ADD_REF: str | None = None
    APP_PER_ADD_DT: str | None = Field(
        None,
        description="Format to be used is dd/mm/yyyy, IF DEEMED OVD IS SUBMITTED, THEN THIS FIELD BECOMES MANDATORY",
    )
    APP_INCOME: str | None = Field(
        None, description="Gross Annual Income for FATCA MANDATORY"
    )
    APP_OCC: str | None = None
    APP_OTH_OCC: str | None = Field(
        None,
        description="Occupation Description, if OCCUPATIONAL DETAILS 'APP_OCC' is set to Others this field is mandatory.",
    )
    APP_POL_CONN: str | None = Field(None, description="PEP status for FATCA MANDATORY")
    APP_DOC_PROOF: str | None = None
    APP_INTERNAL_REF: str | None = None
    APP_BRANCH_CODE: str | None = None
    APP_MAR_STATUS: str | None = None
    APP_NETWRTH: float | None = Field(None, description="for FATCA MANDATORY")
    APP_NETWORTH_DT: str | None = Field(
        None,
        description="Networth as on Date. This would be non-mandatory for individuals if the Gross Annual Income has been specified. However, if the Networth has been specified in case of non-individuals then the Networth Date is mandatory. Format to be used is dd/mm/yyyy",
    )
    APP_INCORP_PLC: str | None = None
    APP_OTHERINFO: str | None = None
    APP_FILLER1: str | None = None
    APP_FILLER2: str | None = None
    APP_FILLER3: str | None = None
    APP_IPV_NAME: str | None = None
    APP_IPV_DESG: str | None = Field(
        None,
        description="Details are mandatory if the name of the person doing IPV is entered 'APP_IPV_NAME'. TAG is not required in case of Non-Individuals.",
    )
    APP_IPV_ORGAN: str | None = Field(
        None,
        description="Details are mandatory if the name of the person doing IPV is entered. TAG is not required in case of Non-Individuals.",
    )
    APP_KYC_MODE: str | None = None
    APP_VID_NO: str | None = Field(
        None, description="VID of the applicant in case of Individuals only."
    )
    APP_UID_TOKEN: str | None = Field(
        None,
        description="UID Token received from UIDAI as part of the reponse for Aadhaar based transaction in case of Individuals only. Value will be mandatory for E-KYC Transactions with APP_VER_NO: 'V29'",
    )
    APP_VER_NO: str | None = Field(
        None,
        description="By details option, will be mandatory for Integration of Version 2.9 with default value 'V29'",
    )
    APP_AUTH_NAME: str | None = None
    APP_AUTH_EMAIL: str | None = Field(
        None,
        description="Mandatory for Eligbile Foreign Investor - Category II Eligible Foreign Investor - Category III",
    )
    APP_AUTH_EMAIL1: str | None = None
    APP_AUTH_EMAIL2: str | None = None
    APP_AUTH_MOBILE: str | None = None
    APP_AUTH_FPICONSENT: str | None = Field(
        None,
        description="Mandatory for Eligbile Foreign Investor - Category II Eligible Foreign Investor - Category III",
    )
    APP_AUTH_UBOCONSENT: str | None = None
    APP_FATCA_APPLICABLE_FLAG: str | None = None
    APP_FATCA_BIRTH_PLACE: str | None = None
    APP_FATCA_BIRTH_COUNTRY: str | None = None
    APP_FATCA_COUNTRY_RES: str | None = None
    APP_FATCA_COUNTRY_CITYZENSHIP: str | None = None
    APP_FATCA_DATE_DECLARATION: str | None = None


class Root(BaseModel):
    HEADER: Header
    KYCDATA: KYCData
    FATCA_ADDL_DTLS: FATCAAddlDtls
    FOOTER: Footer


class ROOTDataModel(BaseModel):
    ROOT: Root


class GenericKYCData(BaseModel):
    model_config = ConfigDict(extra="allow")


class PANStatusModel(BaseModel):
    APP_PAN_NO: str | None = None
    APP_NAME: str | None = None
    APP_STATUS: str | None = None
    APP_STATUSDT: datetime | None = None
    APP_ENTRYDT: datetime | None = None
    APP_MODDT: datetime | None = None
    APP_STATUS_DELTA: str | None = None
    APP_UPDT_STATUS: str | None = None
    APP_HOLD_DEACTIVE_RMKS: str | None = None
    APP_UPDT_RMKS: str | None = None
    APP_KYC_MODE: str | None = None
    APP_IPV_FLAG: str | None = None
    APP_UBO_FLAG: str | None = None
    APP_PER_ADD_PROOF: str | None = None
    APP_COR_ADD_PROOF: str | None = None

    @field_validator("APP_STATUSDT", "APP_ENTRYDT", "APP_MODDT", mode="before")
    @classmethod
    def parse_dates(cls, value):
        if isinstance(value, str):
            if value:
                return datetime.strptime(value, "%d-%m-%Y %H:%M:%S")  # Convert format
            else:
                value = None
        return value
