from typing import Optional, Union, List
from enum import Enum
from datetime import datetime, date
from pydantic import BaseModel, Field, ConfigDict


class OVDType(str, Enum):
    # NOTE VOTER has to be replaced with VOTER_ID in the input
    VOTER = "VOTER"
    PASSPORT = "PASSPORT"
    # NOTE LICENSE has to be replaced with DRIVING_LICENSE in the input
    LICENSE = "DL"
    AADHAAR = "AADHAAR"
    PAN = "PAN"
    DRIVING_LICENSE = "DRIVING_LICENSE"
    VOTER_ID = "VOTER_ID"
    UNKNOWN = "UNKNOWN"


class OVDInput(BaseModel):
    ovd_type: OVDType | None = None
    ovd_front: Optional[str] = None
    ovd_back: Optional[str] = None


class OVDGenericResponse(BaseModel):
    # The document_type will be overridden by the respective document models
    encoded_response: str | None = Field(None, description="This is the base64 encoded json string containing the full data of the document")
    document_type: OVDType = Field(..., description="Type of document")
    uid: str | None = Field(None, description="Unique identifier")
    gender: str | None = Field(None, description="Gender of the user")
    name: str | None = Field(None, description="Full name of the user")
    full_address: str | None = Field(None, description="Full address of the user")
    state: str | None = Field(None, description="State of residence")
    dist: str | None = Field(None, description="District of residence")
    city: str | None = Field(None, description="City of residence")
    country: str | None = Field(None, description="Country of residence")
    model_config = ConfigDict(extra="allow")


class OVDAadhaar(OVDGenericResponse):
    date_of_birth: Union[date, None] = Field(None)


class OVDPassport(OVDGenericResponse):
    surname: Union[str, None] = Field(None)
    nationality: Union[str, None] = Field(None)
    date_of_birth: Union[date, None] = Field(None)
    date_of_expiry: Union[date, None] = Field(None)
    date_of_issue: Union[date, None] = Field(None)
    place_of_birth: Union[str, None] = Field(None)
    place_of_issue: Union[str, None] = Field(None)
    mrz_line_1: Union[str, None] = Field(None)
    mrz_line_2: Union[str, None] = Field(None)
    type: Union[str, None] = Field(None)
    code: Union[str, None] = Field(None)
    nationality: Union[str, None] = Field(None)
    name_of_father: Union[str, None] = Field(None)
    name_of_mother: Union[str, None] = Field(None)
    name_of_spouse: Union[str, None] = Field(None)
    old_passport_number: Union[str, None] = Field(None)
    old_passport_date_of_issue: Union[str, None] = Field(None)
    old_passport_place_of_issue: Union[str, None] = Field(None)


class OVDDrivingLicense(OVDGenericResponse):
    date_of_issue: Union[date, None] = None
    date_of_expiry: Union[date, None] = None
    category: Union[List[str], None] = Field(
        None, description="can have multiple classes."
    )
    bloodgroup: Union[str, None] = Field(
        None, description="must be valid blood type. Sometimes represented as B.G."
    )
    son_of: Union[str, None] = Field(None, description="given as s/o in credentials")


class OVDVoterId(OVDGenericResponse):
    date_of_birth: Union[date, None] = Field(None)


class OVDPAN(OVDGenericResponse):
    fathers_name: Union[str, None] = Field(None)
    date_of_birth: Union[date, None] = Field(None)
    model_config = ConfigDict(extra="allow")
