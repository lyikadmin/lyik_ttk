from pydantic import BaseModel, Field, ConfigDict, field_validator
from typing import List
from enum import Enum
from datetime import datetime


class Address(BaseModel):
    addressType: str | None = Field(
        None, description="1-Correspondence, 2-Bank Address, 4-Permanent"
    )
    addressLine1: str | None = None
    addressLine2: str | None = None
    addressLine3: str | None = None
    addressLine4: str | None = None
    zipcode: str | None = None
    city: str | None = None
    statecode: str | None = None
    countrycode: str | None = None  # India - 356


class NomineeIdentificationDetails(BaseModel):
    pan: str | None = None
    aadhar: str | None = None
    savingBankAccNo: str | None = None
    dematAccId: str | None = None


class NSDLNominee(BaseModel):
    seqNo: int | None = None
    nomineeName: str | None = None
    relationWithNominee: str | None = Field(
        None,
        description="Relationship code for respective relationship eg: '00' for Spouse",
    )
    nomineeAddress: Address | None = None
    nomineeMobileNum: str | None = None
    nomineeEmailId: str | None = None
    nomineeShare: int | None = Field(
        None,
        description="Share Equally field is also set as “Y”, Share of Nominee field should be null.",
    )
    nomineeIdentificationDtls: NomineeIdentificationDetails
    minor: str | None = Field(
        None, description="Default 'N'. 'Y' indicates nominee is minor"
    )
    dob: str | None = Field(None, description="Date format is YYYYMMDD")
    guardianName: str | None = Field(
        None, description="If nominee is Minor, Guardian Name is mandatory."
    )
    guardianAddress: Address | None = None
    guardianMobileNum: str | None = None
    guardianEmailId: str | None = None
    guardianRelationship: str | None = Field(
        None,
        description="Relationship code for respective relationship eg: '00' for Spouse",
    )
    guardianIdentificationDtls: NomineeIdentificationDetails | None = None

    # @field_validator("dob")
    # @classmethod
    # def validate_dob(cls, value: str) -> str:
    #     try:
    #         datetime.strptime(value, "%Y%m%d")  # Check if it's a valid date
    #     except ValueError:
    #         raise ValueError("Invalid date format. Expected YYYYMMDD.")
    #     return value


class AdditionalBeneficiaryDetails(BaseModel):
    familyMobileFlag: str | None = Field(None, description="flag can be 'Y' or 'N'")
    familyEmailFlag: str | None = Field(None, description="flag can be 'Y' or 'N'")
    nominationOption: str | None = Field(
        None,
        description="By default 'N', In case the client wishes to nominate please set this field as 'Y'",
    )
    occupation: int | None = Field(
        None, description="Occupation number code for respective occupation"
    )
    fatherOrHusbandName: str | None = None
    dpId: str | None = None
    clientId: int | None = None
    sharePercentEqually: str | None = Field(
        None,
        description=" 'Y' indicates system will equally distribute share across all nominees, any decimal factor would be added on to the first nominee.'N' indicates manual share allocation to all nominees. Total should be 100%.",
    )
    numOfNominees: int | None = Field(
        None,
        description="Minimum is '1' and Maximum is allowed '3' and if no Nominee then '0'",
    )
    listOfNominees: List[NSDLNominee] = Field(default_factory=list)


class JointHolder(BaseModel):
    seq: int | None = Field(
        None,
        description="Sequence no. 2 will have 'Joint Holder 1' details and Sequence no. 3 will have details of 'Joint Holder 2'",
    )
    name: str | None = None
    pan: str | None = None
    panFlag: str | None = Field(
        None,
        description="Y - PAN verified and seeded with Aadhaar B - PAN verified and seeding with Aadhaar not required",
    )
    dob: str | None = Field(None, description="Date format is YYYYMMDD")
    mobileNo: str | None = None
    emailId: str | None = None
    smsfacility: str | None = Field(None, description="flag can be 'Y' or 'N'")

    # @field_validator("dob")
    # @classmethod
    # def validate_dob(cls, value: str) -> str:
    #     try:
    #         datetime.strptime(value, "%Y%m%d")  # Check if it's a valid date
    #     except ValueError:
    #         raise ValueError("Invalid date format. Expected YYYYMMDD.")
    #     return value


class PrimaryBeneficiary(BaseModel):
    name: str | None = None
    shortName: str | None = None
    pan: str | None = None
    panFlag: str | None = None
    grossAnnualIncome: str | None = None
    dob: str | None = Field(None, description="Date format is YYYYMMDD")
    gender: str | None = Field(None, description="1-Male, 2-Female, 3- Transgender")
    aadhar: str | None = None
    mobile: str | None = None
    email: str | None = None
    ddpiid: int | None = Field(None, description="")
    eStatement: str | None = None
    dematAccType: str | None = None
    dematAccSubType: str | None = None
    rbiRefNo: str | None = None
    rbiApprovalDate: str | None = None
    modeOfOperation: int | None = Field(
        None, description="1 - Jointly, 2 - Anyone of the holder or survivor"
    )
    communicationToBeSend: int | None = Field(
        None, description="1 - First holder, 2 - All joint account holders"
    )
    beneficiaryCoresAddress: Address | None = None
    beneficiaryPermAddress: Address | None = None
    signature: str | None = Field(
        None, description=" Signature should be Base64 encoded"
    )

    # @field_validator("dob", "rbiApprovalDate")
    # @classmethod
    # def validate_dob(cls, value: str) -> str:
    #     try:
    #         datetime.strptime(value, "%Y%m%d")  # Check if it's a valid date
    #     except ValueError:
    #         raise ValueError("Invalid date format. Expected YYYYMMDD.")
    #     return value


class BeneficiaryDetails(BaseModel):
    primaryBeneficiary: PrimaryBeneficiary | None = None
    numOfJointHolders: int | None = Field(
        None,
        description="Number of Joint Holders 0 if there are no Joint Holders",
    )
    listOfJointHolders: List[JointHolder] = Field(default_factory=list)
    additionalBeneDetails: AdditionalBeneficiaryDetails | None = None


class BankAddress(BaseModel):
    addressType: str | None = Field(None, description="Bank address type is '4'")
    addressLine1: str | None = None
    addressLine2: str | None = None
    addressLine3: str | None = None
    addressLine4: str | None = None
    zipcode: str | None = None


class BankDetails(BaseModel):
    accountNumber: str | None = None
    bankName: str | None = None
    ifsc: str | None = None
    micr: str | None = None
    accountType: str | None = Field(
        None, description="10 - Savings, 11 - Current"
    )  # No other type specified
    bankAddress: BankAddress | None = None


class Instr(BaseModel):
    beneficiaryDetails: BeneficiaryDetails
    bankDetails: BankDetails | None = None


class NSDLRquestModel(BaseModel):
    instr: Instr | None = None


class NSDLResponseStatus(str, Enum):
    SUCCESS = "success"
    FAILED = "failed"


class NSDLResponseModel(BaseModel):
    """
    Common Response model for NSDL Demat request.
    """

    status: NSDLResponseStatus
    message: str
    model_config = ConfigDict(extra="allow")
