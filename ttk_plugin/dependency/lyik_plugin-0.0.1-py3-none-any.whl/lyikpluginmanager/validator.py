from typing import Annotated, get_type_hints, Any, Union
from pydantic import ValidationError, BaseModel
from .annotation import InputModel, OutputModel
import inspect
from .core import PluginException
import logging

logger = logging.getLogger(__name__)


import typing
import types
from typing import get_origin, get_args

def is_valid_basic_type(value: Any, annotation: Any) -> bool:
    """
    Checks whether the given value matches the provided type annotation.

    This method is designed to safely handle complex Python typing constructs,
    including:
    - Union types (e.g., Union[str, int])
    - Optional[T] (e.g., Optional[Dict[str, Any]])
    - Python 3.10+ shorthand (e.g., str | None)
    - Standard types (int, str, dict, etc.)

    Why we need this:
    -----------------
    Directly calling isinstance(value, annotation) fails for most typing constructs
    like Union, Optional, and Dict[str, Any]. This helper unwraps and interprets the
    annotation to allow safe and accurate validation.

    Parameters:
    -----------
    value : Any
        The value to check.
    annotation : Any
        The expected type annotation.

    Returns:
    --------
    bool
        True if value matches the annotation, False otherwise.
    """
    origin = get_origin(annotation)

    # If the annotation is a Union (or Optional), check against all possible types
    if origin in (Union, types.UnionType):
        return any(is_valid_basic_type(value, arg) for arg in get_args(annotation))

    # If the annotation is a direct type, use isinstance
    if isinstance(annotation, type):
        return isinstance(value, annotation)

    # If type is Optional[T] (represented as T | None)
    if hasattr(annotation, '__args__') and type(None) in annotation.__args__:
        return value is None or is_valid_basic_type(value, annotation.__args__[0])

    # Fallback: don't match if type is too complex or unsupported
    return False



def extract_base_type(annotation: Any) -> Any:
    """
    Safely unwraps typing constructs like Union, Optional, and Generic types (List[T], Dict[K, V])
    to return the core/base type.

    Specifically handles:
    - `typing.Union[T1, T2, ...]` or `types.UnionType`
    - `Optional[T]` which is shorthand for `Union[T, None]`
    - `List[T]`, `Dict[K, V]`, `Set[T]`, `Tuple[T1, T2]`, etc.
    - Pydantic models (direct or inside collections)

    Parameters:
    ----------
    annotation : Any
        The type hint annotation from which we want to extract the base type.

    Returns:
    -------
    Any
        - If `annotation` is a simple type (e.g., `str`, `int`), returns it as is.
        - If `annotation` is `Union[T, None]`, returns `T | None`.
        - If `annotation` is a generic type like `List[T]`, returns `(list, T)`.
        - If `annotation` is a Pydantic model inside `List[T]`, returns `(list, UserModel)`.
        - If `annotation` is a direct Pydantic model, returns it unchanged.
    """
    origin = get_origin(annotation)

    # If there's no "origin," it's likely a direct type (e.g., str) or a class.
    if origin is None:
        return annotation

    # Handle both `typing.Union` (old style) and `types.UnionType` (new Python 3.10+ style)
    if origin in (Union, types.UnionType):
        args = get_args(annotation)

        # If `NoneType` is present, retain `T | None` instead of stripping it out
        non_none_types = [arg for arg in args if arg is not type(None)]

        # If `NoneType` was present, reconstruct using `|` operator
        if len(non_none_types) < len(args):
            # If there are more than one real type, return the original annotation
            #  Example: T1 | T2 | None
            if len(non_none_types) > 1:
                return annotation
            # Just one real type → return T | None
            return non_none_types[0] | None  # Equivalent to `T | None`
            
        return non_none_types[
            0
        ]  # Return first non-None type if `NoneType` wasn't present

    # Handle generics like `List[T]`, `Dict[K, V]`, etc.
    type_args = get_args(annotation)  # Extract inner types

    # Special handling for collections containing Pydantic models
    if type_args and issubclass(type_args[0], BaseModel):
        return (origin, type_args[0])  # Returns tuple (list, UserModel)

    return origin  # Returns `list`, `dict`, `set`, etc.


async def validate_plugin_inputs(func_to_call, **kwargs) -> Any:
    """
    Returns the validated kwargs of the plugin. Transforms them to a model if applicable
    """

    # STEP 1: Extract type hints (including Annotated metadata) from the function.
    type_hints = get_type_hints(func_to_call, include_extras=True)

    # STEP 2: Construct a dictionary for input validations where each key
    #         is a parameter name and each value is the expected type or Pydantic model.
    input_validations = {}
    for param, annotation in type_hints.items():
        base_type = annotation  # Default to the original annotation (could be Annotated or a raw type)

        # If the annotation is Annotated, it may contain metadata like InputModel.
        metadata = getattr(annotation, "__metadata__", None)
        if metadata:
            # Extract the primary type within Annotated[...] (e.g., Annotated[BaseType, ...]).
            base_type = annotation.__args__[0]

            # Check if any of the metadata objects is an InputModel wrapper.
            for meta in metadata:
                if isinstance(meta, InputModel):
                    # If so, override the base_type with the actual Pydantic model.
                    base_type = meta.model

        # Store the final resolved type or Pydantic model to use for validation.
        input_validations[param] = base_type

    # STEP 3: Validate input kwargs against the `input_validations` discovered above.
    validated_kwargs = {}

    for param, expected in input_validations.items():
        # if param not in kwargs:
        #     continue
        if param in kwargs:
            value = kwargs[param]
            # Attempt to unwrap potential Union/Optional types to get the base type.
            base_type = extract_base_type(expected)

            try:

                # --- 1) Single Pydantic model ---
                # Check if it's a Pydantic model class.
                if isinstance(base_type, type) and issubclass(base_type, BaseModel):
                    # If the given `value` is already an instance of that model, no extra validation is needed.
                    if isinstance(value, base_type):
                        validated_kwargs[param] = value
                    else:
                        # If not, try to construct/validate a new instance from the given value.
                        if isinstance(value, BaseModel):
                            # Convert existing model to a dict, then validate again
                            validated_kwargs[param] = base_type.model_validate(
                                value.model_dump()
                            )
                        else:
                            # Otherwise, assume `value` is a dict or a valid structure for the Pydantic model
                            validated_kwargs[param] = base_type.model_validate(value)

                # --- 2) Handle true Union[A,B,...] ---
                elif get_origin(base_type) in (Union, types.UnionType):
                    last_error: Exception | None = None
                    for candidate in get_args(base_type):
                        try:
                            # Pydantic model candidate
                            if isinstance(candidate, type) and issubclass(candidate, BaseModel):
                                if isinstance(value, candidate):
                                    validated_kwargs[param] = value
                                else:
                                    # convert from other BaseModel or raw dict
                                    raw = (
                                        value.model_dump()
                                        if isinstance(value, BaseModel)
                                        else value
                                    )
                                    validated_kwargs[param] = candidate.model_validate(raw)
                                break

                            # primitive candidate
                            if is_valid_basic_type(value, candidate):
                                validated_kwargs[param] = value
                                break

                        except ValidationError as ve:
                            last_error = ve

                    else:
                        msg = (
                            f"Expected '{param}' to match one of {get_args(base_type)}, "
                            f"but got {type(value)}"
                        )
                        detail = str(last_error) if last_error else ""
                        raise PluginException(message=msg, detailed_message=detail)

                # --- 3) Primitive or Optional[...] (unions with None) or other singletons ---
                # Handles non-Pydantic types and basic Python types (e.g., int, str, dict, list), or Optional[T]/Union types)
                # Also safely supports Optional and Union types like Optional[Dict[str, Any]] or str | int.
                elif is_valid_basic_type(value, base_type):
                    validated_kwargs[param] = value

                else:
                    raise TypeError(
                        f"Expected '{param}' to be of type {base_type}, but got {type(value)}"
                    )

            except ValidationError as e:
                # Log and raise an exception if validation fails at any point.
                readable_validation_error = get_readable_validation_error(e)
                logger.error(f"Validation failed for '{param}': {readable_validation_error}")
                raise PluginException(
                    message=f"The system has detected an invalid input for '{param}'. Please try re-entering the data. If the error persists, contact system administrator. {readable_validation_error}",
                    detailed_message=str(e),
                )

            except TypeError as e:
                # Log and raise an exception if validation fails at any point.
                logger.error(f"Validation failed for '{param}': {e}")
                raise PluginException(
                    message=f"The system has detected an invalid input for '{param}'. Please try re-entering the data. If the error persists, contact system administrator.",
                    detailed_message=str(e),
                )

    return validated_kwargs


async def validate_plugin_output(func_to_call, result) -> None:
    # STEP 1: Extract type hints (including Annotated metadata) from the function.
    type_hints = get_type_hints(func_to_call, include_extras=True)

    # STEP 2: Identify if there's an OutputModel in the return annotation.
    output_model = None
    return_annotation = type_hints.get("return", None)
    if return_annotation:
        base_type = return_annotation  # Could be Annotated or a raw type

        metadata = getattr(return_annotation, "__metadata__", None)
        if metadata:
            # Extract the primary type from Annotated.
            base_type = return_annotation.__args__[0]

            # Check if any metadata object is an OutputModel wrapper.
            for meta in metadata:
                if isinstance(meta, OutputModel):
                    # If so, override the base_type with the actual Pydantic model.
                    base_type = meta.model

        # Now we have the final output model or type.
        output_model = base_type

    # STEP 3: If we discovered an output_model, validate the function's return value.
    if output_model:
        try:
            # If it's a Pydantic model class, attempt model validation on the result.
            if isinstance(output_model, type) and issubclass(output_model, BaseModel):
                validated_output = output_model.model_validate(result)
                return validated_output

            # If it's a standard Python type (like int, str), check with isinstance.
            elif isinstance(output_model, type):
                if not isinstance(result, output_model):
                    raise TypeError(
                        f"Expected return value to be of type {output_model}, but got {type(result)}"
                    )
                return result
        except (ValidationError, TypeError) as e:
            logger.error(f"Output validation failed: {e}")
            raise PluginException(
                message=f"Validation of response failed. Contact support.", detailed_message="{e}"
            )
    # STEP 4: If there's no output model, or we've successfully validated the result,
    #         return the function's raw output.
    return result

def get_readable_validation_error(e: ValidationError) -> str:
    """
    Parse a Pydantic ValidationError and return a human-readable message.

    Args:
        e (ValidationError): The validation error to process.

    Returns:
        str: A summarised and readable error message.
    """
    missing_fields = []
    data_errors = []

    for error in e.errors():
        error_attribute_list = list(map(str, error.get("loc", [])))
        error_attribute_list = [a.capitalize().replace("_", " ") for a  in error_attribute_list]
        attribute = " -> ".join(error_attribute_list)
        error_message = error.get("msg", "Invalid input")

        if "field required" in error_message:
            missing_fields.append(attribute)
        else:
            data_errors.append(f"'{attribute}': {error_message}")

    missing_part = "Missing fields:\n" + {'\n'.join(missing_fields)} if missing_fields else ""
    data_errors_part = "\n".join(data_errors) if data_errors else ""

    return "\n".join(filter(None, [missing_part, data_errors_part]))


# async def call_plugin_with_input_and_output_validation(func_to_call, **kwargs) -> Any:
#     """
#     Asynchronously calls the plugin function (`func_to_call`) while applying
#     both input (parameter) and output (return value) validation using Pydantic.

#     Workflow:
#     1. Extract Type Hints from `func_to_call` (including Annotated metadata).
#     2. Determine Input Validation by looking for `Annotated[..., InputModel(...)]`.
#     3. Determine Output Validation by looking for `Annotated[..., OutputModel(...)]`
#        in the return type.
#     4. Validate Input Args (`kwargs`) against the discovered Pydantic models or base types.
#     5. Call the plugin function with validated inputs.
#     6. Validate Output against the discovered model/type if specified.
#     7. Return the validated output or raise an exception if validation fails.

#     Parameters:
#     ----------
#     func_to_call : Callable
#         The asynchronous function that will be invoked.
#     **kwargs : dict
#         Key-value pairs to be passed as arguments to `func_to_call`.
#         These will be validated according to the function's Annotated type hints.

#     Returns:
#     -------
#     Any
#         The result of `func_to_call`, possibly transformed into a Pydantic model
#         if output validation is applied.

#     Raises:
#     ------
#     Exception
#         If either input or output validation fails, or if the arguments do not match
#         the specified types or schemas.
#     """

#     # STEP 1: Extract type hints (including Annotated metadata) from the function.
#     type_hints = get_type_hints(func_to_call, include_extras=True)

#     # STEP 2: Construct a dictionary for input validations where each key
#     #         is a parameter name and each value is the expected type or Pydantic model.
#     input_validations = {}
#     for param, annotation in type_hints.items():
#         base_type = annotation  # Default to the original annotation (could be Annotated or a raw type)

#         # If the annotation is Annotated, it may contain metadata like InputModel.
#         metadata = getattr(annotation, "__metadata__", None)
#         if metadata:
#             # Extract the primary type within Annotated[...] (e.g., Annotated[BaseType, ...]).
#             base_type = annotation.__args__[0]

#             # Check if any of the metadata objects is an InputModel wrapper.
#             for meta in metadata:
#                 if isinstance(meta, InputModel):
#                     # If so, override the base_type with the actual Pydantic model.
#                     base_type = meta.model

#         # Store the final resolved type or Pydantic model to use for validation.
#         input_validations[param] = base_type


#     # STEP 3: Identify if there's an OutputModel in the return annotation.
#     output_model = None
#     return_annotation = type_hints.get("return", None)
#     if return_annotation:
#         base_type = return_annotation  # Could be Annotated or a raw type

#         metadata = getattr(return_annotation, "__metadata__", None)
#         if metadata:
#             # Extract the primary type from Annotated.
#             base_type = return_annotation.__args__[0]

#             # Check if any metadata object is an OutputModel wrapper.
#             for meta in metadata:
#                 if isinstance(meta, OutputModel):
#                     # If so, override the base_type with the actual Pydantic model.
#                     base_type = meta.model

#         # Now we have the final output model or type.
#         output_model = base_type


#     # STEP 4: Validate input kwargs against the `input_validations` discovered above.
#     validated_kwargs = {}

#     for param, expected_type in input_validations.items():
#         if param in kwargs:
#             value = kwargs[param]
#             # Attempt to unwrap potential Union/Optional types to get the base type.
#             base_type = extract_base_type(expected_type)

#             print(
#                 f"[DEBUG] Processing '{param}': Expected {base_type}, Got {type(value)}"
#             )

#             try:
#                 # Check if it's a Pydantic model class.
#                 if isinstance(base_type, type) and issubclass(base_type, BaseModel):
#                     # If the given `value` is already an instance of that model, no extra validation is needed.
#                     if isinstance(value, base_type):
#                         validated_kwargs[param] = value
#                     else:
#                         # If not, try to construct/validate a new instance from the given value.
#                         if isinstance(value, BaseModel):
#                             # Convert existing model to a dict, then validate again
#                             validated_kwargs[param] = base_type.model_validate(
#                                 value.model_dump()
#                             )
#                         else:
#                             # Otherwise, assume `value` is a dict or a valid structure for the Pydantic model
#                             validated_kwargs[param] = base_type.model_validate(value)

#                 # If it's not a Pydantic model, it might be a standard Python type (e.g., str, int, etc.)
#                 elif isinstance(base_type, type):
#                     if not isinstance(value, base_type):
#                         raise TypeError(
#                             f"Expected '{param}' to be of type {base_type}, but got {type(value)}"
#                         )
#                     validated_kwargs[param] = value

#                 # If validation for 'param' passed, it's stored in validated_kwargs.
#                 if param in validated_kwargs:
#                     print(f"[DEBUG] Validated '{param}': {validated_kwargs[param]}")
#                 else:
#                     print(
#                         f"[DEBUG] Skipping '{param}', validation failed or missing from kwargs."
#                     )

#             except (ValidationError, TypeError) as e:
#                 # Log and raise an exception if validation fails at any point.
#                 logger.error(f"Validation failed for '{param}': {e}")
#                 print(f"[ERROR] Validation failed for '{param}': {e}")
#                 raise Exception(f"Invalid input for '{param}': {e}")


#     # STEP 5: Call the actual plugin function with the validated inputs.
#     result = await func_to_call(**validated_kwargs)

#     # STEP 6: If we discovered an output_model, validate the function's return value.
#     if output_model:
#         try:
#             # If it's a Pydantic model class, attempt model validation on the result.
#             if isinstance(output_model, type) and issubclass(output_model, BaseModel):
#                 validated_output = output_model.model_validate(result)
        
#                 return validated_output

#             # If it's a standard Python type (like int, str), check with isinstance.
#             elif isinstance(output_model, type):
#                 if not isinstance(result, output_model):
#                     raise TypeError(
#                         f"Expected return value to be of type {output_model}, but got {type(result)}"
#                     )
#                 return result
#         except (ValidationError, TypeError) as e:
#             logger.error(f"Output validation failed: {e}")
#             print(f"[ERROR] Output validation failed: {e}")
#             raise Exception(f"Invalid output: {e}")

#     # STEP 7: If there's no output model, or we've successfully validated the result,
#     #         return the function's raw output.
#     return result
