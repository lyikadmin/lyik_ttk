from pydantic import BaseModel
from typing import List

class InputModel:
    """
    A wrapper class used to indicate that a plugin parameter must be validated
    using a specific Pydantic model.

    Example usage in a plugin signature:
        def some_plugin_fn(
            param: Annotated[dict, InputModel(SomePydanticModel)]
        ) -> ...
    """
    def __init__(self, model: BaseModel):
        self.model = model


class OutputModel:
    """
    A wrapper class used to indicate that a plugin's return value must be validated
    using a specific Pydantic model.

    Example usage in a plugin signature:
        def some_plugin_fn(...) -> Annotated[dict, OutputModel(SomePydanticModel)]:
            ...
    """
    def __init__(self, model: BaseModel):
        self.model = model

class InnerDataModel:
    """
    A wrapper class used to indicate that a plugin's data inside the return value must be validated
    using a specific Pydantic model.

    Example usage in a plugin signature:
        def some_plugin_fn(...) -> Annotated[dict, InnerDataModel(SomePydanticModel)]:
            ...
    """
    def __init__(self, model: BaseModel):
        self.model = model

class RequiredVars:
    """
    A wrapper class used to indicate that a plugin requests a list of variables from the config.

    Example usage in a plugin signature:
        def some_plugin_fn(...) -> Annotated[dict, RequiredVars(["var1", "var2"])]:
            ...
    """
    def __init__(self, vars: List[str]):
        self.vars = vars

class RequiredEnv:
    """
    A wrapper class used to indicate that a plugin requests a list of variables from the environment.
    If the variables are not found in the environment, then the server will fail to start.

    Example usage in a plugin signature:
        def some_plugin_fn(...) -> Annotated[dict, RequiredEnv(["var1", "var2"])]:
            ...
    """
    def __init__(self, vars: List[str]):
        self.vars = vars