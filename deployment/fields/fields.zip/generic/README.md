# Generic Fields
These fields are needed to be loaded first for all customers.
The fields are given a range from 1-500. Hence there can be a maximum of 500 generic fields !